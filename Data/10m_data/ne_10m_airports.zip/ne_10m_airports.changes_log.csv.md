wd_id     |  status    |  variable  |  value_old                                              |  value_new
----------|------------|------------|---------------------------------------------------------|-----------------------------------------------------------------
Q7555807  |  NEWvalue  |  name_hi   |                                                         |  शोलापुर विमानक्षेत्र
Q1658243  |  NEWvalue  |  name_bn   |                                                         |  দেবী অহল্যা বাই হোলকার বিমানবন্দর
Q1328849  |  NEWvalue  |  name_pt   |                                                         |  Aeroporto Internacional Tolmachevo
Q559454   |  NEWvalue  |  name_ar   |                                                         |  مطار زاهدان الدولي
Q559454   |  NEWvalue  |  name_fr   |                                                         |  Aéroport international de Zahedan
Q2788745  |  NEWvalue  |  name_hi   |                                                         |  बरेली विमानक्षेत्र
Q1931319  |  NEWvalue  |  name_hi   |                                                         |  इलाहाबाद विमानक्षेत्र
Q794552   |  NEWvalue  |  name_hi   |                                                         |  मिराबेल हवाई अड्डा
Q1332588  |  NEWvalue  |  name_ru   |                                                         |  Паланга
Q250026   |  NEWvalue  |  name_fr   |                                                         |  Aéroport de Yenişehir
Q385356   |  NEWvalue  |  name_bn   |                                                         |  শ্রী গুরু রামদাস জী আন্তর্জাতিক বিমানবন্দর
Q598850   |  NEWvalue  |  name_bn   |                                                         |  বিজু পট্টনায়েক আন্তর্জাতিক বিমানবন্দর
Q598850   |  MODvalue  |  name_ja   |  ビージュー・パトナーイク空港                                         |  ビジューパトナイク国際空港
Q1324587  |  NEWvalue  |  name_zh   |                                                         |  布爾加斯機場
Q1163183  |  NEWvalue  |  name_de   |                                                         |  Flughafen Charleston
Q1163183  |  NEWvalue  |  name_en   |                                                         |  Charleston International Airport
Q1163183  |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Internacional de Charleston
Q1163183  |  NEWvalue  |  name_fr   |                                                         |  aéroport international de Charleston
Q1163183  |  NEWvalue  |  name_ja   |                                                         |  チャールストン国際空港
Q1163183  |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Charleston
Q1163183  |  NEWvalue  |  name_vi   |                                                         |  Sân bay quốc tế Charleston
Q1163183  |  NEWvalue  |  name_zh   |                                                         |  查爾斯頓國際機場
Q692279   |  NEWvalue  |  name_ar   |                                                         |  مطار كلارك الدولي
Q692279   |  NEWvalue  |  name_de   |                                                         |  Flughafen Angeles City
Q692279   |  NEWvalue  |  name_en   |                                                         |  Clark International Airport
Q692279   |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Internacional de Clark
Q692279   |  NEWvalue  |  name_fr   |                                                         |  aéroport international de Diosdado Macapagal
Q692279   |  NEWvalue  |  name_id   |                                                         |  Bandar Utara Internasional Diosdado Macapagal
Q692279   |  NEWvalue  |  name_it   |                                                         |  aeroporto di Clark
Q692279   |  NEWvalue  |  name_ja   |                                                         |  クラーク国際空港
Q692279   |  NEWvalue  |  name_ko   |                                                         |  디오스다도 마카파갈 국제공항
Q692279   |  NEWvalue  |  name_nl   |                                                         |  Diosdado Macapagal International Airport
Q692279   |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Diosdado Macapagal
Q692279   |  NEWvalue  |  name_vi   |                                                         |  Sân bay quốc tế Clark
Q692279   |  NEWvalue  |  name_zh   |                                                         |  迪奧斯達多·馬卡帕加爾國際機場
Q3275688  |  MODvalue  |  name_en   |  Gerrard Smith International Airport                    |  Charles Kirkconnell International Airport
Q676576   |  NEWvalue  |  name_ko   |                                                         |  로널드 레이건 워싱턴 내셔널 공항
Q3207464  |  NEWvalue  |  name_bn   |                                                         |  হুব্বাল্লী বিমানবন্দর
Q3207464  |  NEWvalue  |  name_hi   |                                                         |  हुबली विमानक्षेत्र
Q2902692  |  NEWvalue  |  name_hi   |                                                         |  जोधपुर हवाई अड्डा
Q1595048  |  NEWvalue  |  name_bn   |                                                         |  জব্বলপুর বিমানবন্দর
Q1431949  |  NEWvalue  |  name_ko   |                                                         |  LMM
Q1432932  |  NEWvalue  |  name_de   |                                                         |  Flughafen Sumburgh
Q1432932  |  NEWvalue  |  name_en   |                                                         |  Sumburgh Airport
Q1432932  |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Sumburgh
Q1432932  |  NEWvalue  |  name_fr   |                                                         |  aéroport de Sumburgh
Q1432932  |  NEWvalue  |  name_ja   |                                                         |  サンバラ空港
Q1432932  |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Sumburgh
Q1432932  |  NEWvalue  |  name_ru   |                                                         |  Самбург
Q1432932  |  NEWvalue  |  name_sv   |                                                         |  Sumburgh Airport
Q59633    |  MODvalue  |  name_sv   |  Svalbard flygplats                                     |  Svalbard lufthavn
Q2493883  |  NEWvalue  |  name_sv   |                                                         |  General Rodolfo Sánchez Taboada International Airport
Q7286282  |  NEWvalue  |  name_hi   |                                                         |  राजकोट विमानक्षेत्र
Q2247528  |  NEWvalue  |  name_bn   |                                                         |  শ্রীনগর বিমানবন্দর
Q2247528  |  NEWvalue  |  name_hi   |                                                         |  श्रीनगर विमानक्षेत्र
Q1432990  |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Internacional de Tallahassee
Q1371432  |  NEWvalue  |  name_it   |                                                         |  Aeroporto Internazionale di U-Tapao
Q2919631  |  NEWvalue  |  name_fr   |                                                         |  Aéroport de Peace River
Q3912586  |  NEWvalue  |  name_fr   |                                                         |  Aéroport de Sydney-J.A. Douglas McCurdy
Q3497025  |  NEWvalue  |  name_fr   |                                                         |  Aéroport North Bay-Jack Garland
Q8066777  |  NEWvalue  |  name_fr   |                                                         |  Aéroport de Zaria
Q7639037  |  NEWvalue  |  name_ko   |                                                         |  순천 비행장
Q1138699  |  NEWvalue  |  name_tr   |                                                         |  Boraldai Havalimanı
Q1432089  |  NEWvalue  |  name_zh   |                                                         |  摩蘇爾國際機場
Q4079257  |  NEWvalue  |  name_en   |                                                         |  Bataysk Air Base
Q4079257  |  NEWvalue  |  name_ja   |                                                         |  バタイスク空軍基地
Q4079257  |  NEWvalue  |  name_ru   |                                                         |  Батайск
Q612731   |  NEWvalue  |  name_ar   |                                                         |  مطار بوردو ميرينياك
Q612731   |  NEWvalue  |  name_de   |                                                         |  Flughafen Bordeaux
Q612731   |  NEWvalue  |  name_en   |                                                         |  Bordeaux–Mérignac Airport
Q612731   |  NEWvalue  |  name_es   |                                                         |  Aeropuerto de Burdeos-Mérignac
Q612731   |  NEWvalue  |  name_fr   |                                                         |  aéroport de Bordeaux-Mérignac
Q612731   |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Bordeaux - Mérignac
Q612731   |  NEWvalue  |  name_it   |                                                         |  Aeroporto di Bordeaux Mérignac
Q612731   |  NEWvalue  |  name_ja   |                                                         |  ボルドー・メリニャック空港
Q612731   |  NEWvalue  |  name_nl   |                                                         |  Luchthaven Bordeaux
Q612731   |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Bordeaux-Mérignac
Q612731   |  NEWvalue  |  name_ru   |                                                         |  Аэропорт Бордо-Мериньяк
Q612731   |  NEWvalue  |  name_vi   |                                                         |  Sân bay Bordeaux - Mérignac
Q612731   |  NEWvalue  |  name_zh   |                                                         |  波爾多
Q1322497  |  NEWvalue  |  name_ar   |                                                         |  مطار ناغويا
Q1322497  |  NEWvalue  |  name_de   |                                                         |  Flughafen Nagoya
Q1322497  |  NEWvalue  |  name_en   |                                                         |  Nagoya Airfield
Q1322497  |  NEWvalue  |  name_es   |                                                         |  Nagoya Airfield
Q1322497  |  NEWvalue  |  name_fr   |                                                         |  aéroport de Nagoya
Q1322497  |  NEWvalue  |  name_id   |                                                         |  Lapangan Udara Nagoya
Q1322497  |  NEWvalue  |  name_it   |                                                         |  Nagoya Airfield
Q1322497  |  NEWvalue  |  name_ja   |                                                         |  名古屋飛行場
Q1322497  |  NEWvalue  |  name_ko   |                                                         |  나고야 비행장
Q1322497  |  NEWvalue  |  name_tr   |                                                         |  Nagoya Havalimanı
Q1322497  |  NEWvalue  |  name_vi   |                                                         |  Sân bay Nagoya
Q1322497  |  NEWvalue  |  name_zh   |                                                         |  名古屋飞行场
Q1054857  |  NEWvalue  |  name_pt   |                                                         |  Aeroporto de Sendai
Q1849321  |  NEWvalue  |  name_hi   |                                                         |  आगरा विमानक्षेत्र
Q1658031  |  NEWvalue  |  name_bn   |                                                         |  বাদশাহ আব্দুল আজিজ বিমান ঘাটি
Q1327938  |  NEWvalue  |  name_fr   |                                                         |  Aéroport international de Funafuti
Q1657780  |  NEWvalue  |  name_bn   |                                                         |  ডাঃ বাবাসাহেব আম্বেদকর আন্তর্জাতিক বিমানবন্দর
Q1054212  |  MODvalue  |  name_fr   |  aéroport international de Villanova d'Albenga          |  aéroport d'Albenga
Q721494   |  NEWvalue  |  name_hi   |                                                         |  क्वीन एलिया हवाई अड्डा
Q186614   |  NEWvalue  |  name_hi   |                                                         |  दोमोदेदोव हवाई अड्डा
Q1431564  |  MODvalue  |  name_zh   |  伊尔库茨克机场                                                |  伊爾庫茨克國際機場
Q1431925  |  NEWvalue  |  name_ru   |                                                         |  Ломе — Токуэн
Q1345361  |  NEWvalue  |  name_tr   |                                                         |  Cork Havalimanı
Q1049719  |  NEWvalue  |  name_ar   |                                                         |  مطار فا الدولي
Q1049719  |  NEWvalue  |  name_de   |                                                         |  Flughafen Tahiti
Q1049719  |  NEWvalue  |  name_en   |                                                         |  Faa'a International Airport
Q1049719  |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Internacional Faa'a
Q1049719  |  NEWvalue  |  name_fr   |                                                         |  aéroport international Tahiti-Faaa
Q1049719  |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Internasional Faa'a
Q1049719  |  NEWvalue  |  name_it   |                                                         |  Aeroporto Internazionale Faa'a
Q1049719  |  NEWvalue  |  name_ja   |                                                         |  パペーテ・タヒチ国際空港
Q1049719  |  NEWvalue  |  name_ko   |                                                         |  파 국제공항
Q1049719  |  NEWvalue  |  name_nl   |                                                         |  Faa'a International Airport
Q1049719  |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Faa'a
Q1049719  |  NEWvalue  |  name_pt   |                                                         |  Aeroporto Internacional de Faa'a
Q1049719  |  NEWvalue  |  name_ru   |                                                         |  Фааа
Q1049719  |  NEWvalue  |  name_vi   |                                                         |  Sân bay quốc tế Faa'a
Q1049719  |  NEWvalue  |  name_zh   |                                                         |  法阿國際機場
Q597139   |  NEWvalue  |  name_ko   |                                                         |  리노-타호 국제공항
Q1141214  |  NEWvalue  |  name_hi   |                                                         |  कार्थेज हवाई अड्डा
Q837745   |  NEWvalue  |  name_bn   |                                                         |  চেঙ্গিজ খান আন্তর্জাতিক বিমানবন্দর
Q1130612  |  NEWvalue  |  name_hu   |                                                         |  Gran Canaria repülőtér
Q1197691  |  NEWvalue  |  name_tr   |                                                         |  Hangzhou Xiaoshan Uluslararası Havalimanı
Q643783   |  NEWvalue  |  name_el   |                                                         |  Διεθνές Αεροδρόμιο της Πρίστινα
Q1156786  |  NEWvalue  |  name_tr   |                                                         |  Harbin Taiping Uluslararası Havalimanı
Q1466205  |  NEWvalue  |  name_bn   |                                                         |  তিরুবনন্তপুরম আন্তর্জাতিক বিমানবন্দর
Q2358345  |  NEWvalue  |  name_ar   |                                                         |  مطار بندر عباس الدولي
Q1061846  |  NEWvalue  |  name_pt   |                                                         |  Aeroporto Internacional Ngurah Rai
Q1431204  |  NEWvalue  |  name_de   |                                                         |  Flughafen Des Moines
Q1431204  |  NEWvalue  |  name_en   |                                                         |  Des Moines International Airport
Q1431204  |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Internacional de Des Moines
Q1431204  |  NEWvalue  |  name_fr   |                                                         |  aéroport de Des Moines
Q1431204  |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Internasional Des Moines
Q1431204  |  NEWvalue  |  name_ja   |                                                         |  デモイン国際空港
Q1431204  |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Des Moines
Q1431204  |  NEWvalue  |  name_pt   |                                                         |  Aeroporto Internacional de Des Moines
Q1431204  |  NEWvalue  |  name_vi   |                                                         |  Sân bay quốc tế Des Moines
Q1431204  |  NEWvalue  |  name_zh   |                                                         |  得梅因
Q586065   |  NEWvalue  |  name_hi   |                                                         |  अन्टीबी हवाई अड्डा
Q27596    |  DELvalue  |  name_de   |  Bangoka                                                |
Q2673008  |  MODvalue  |  name_hi   |  लोकप्रिय गोपीनाथ बारदोलोइ अंतर्राष्ट्रीय विमानक्षेत्र  |  लोकप्रिय गोपीनाथ बारदोलोइ अन्तरराष्ट्रीय विमानक्षेत्र
Q1432178  |  NEWvalue  |  name_tr   |                                                         |  Strigino Havalimanı
Q1331032  |  NEWvalue  |  name_sv   |                                                         |  General José María Yáñez International Airport
Q1431468  |  NEWvalue  |  name_sv   |                                                         |  General Ignacio Pesqueira García International Airport
Q1025454  |  NEWvalue  |  name_pt   |                                                         |  Aeroporto Internacional de Jackson-Medgar Wiley Evers
Q1305028  |  NEWvalue  |  name_tr   |                                                         |  Kuching Uluslararası Havalimanı
Q319654   |  NEWvalue  |  name_hi   |                                                         |  ला गुर्डिया हवाई अड्डा
Q1499872  |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Will Rogers World
Q1499872  |  NEWvalue  |  name_hi   |                                                         |  ओकेसी हवाई अड्डा
Q1188577  |  NEWvalue  |  name_fr   |                                                         |  aéroport de Port Hedland
Q1432789  |  NEWvalue  |  name_de   |                                                         |  Flughafen Savannah/Hilton Head
Q1432789  |  NEWvalue  |  name_en   |                                                         |  Savannah/Hilton Head International Airport
Q1432789  |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Internacional de Savannah/Hilton Head
Q1432789  |  NEWvalue  |  name_ja   |                                                         |  Savannah/Hilton Head国際空港
Q1432789  |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Savannah/Hilton Head
Q1432789  |  NEWvalue  |  name_pt   |                                                         |  Aeroporto Internacional de Savannah/Hilton Head
Q1432789  |  NEWvalue  |  name_zh   |                                                         |  薩凡納
Q1431111  |  NEWvalue  |  name_de   |                                                         |  Flughafen Cibao
Q1431111  |  NEWvalue  |  name_en   |                                                         |  Cibao International Airport
Q1431111  |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Internacional del Cibao
Q1431111  |  NEWvalue  |  name_fr   |                                                         |  aéroport international du Cibao
Q1431111  |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Internasional Cibao
Q1431111  |  NEWvalue  |  name_it   |                                                         |  Aeroporto Internazionale del Cibao
Q1431111  |  NEWvalue  |  name_ja   |                                                         |  サンティアゴ・デ・ロス・カバリェロス
Q1431111  |  NEWvalue  |  name_nl   |                                                         |  Cibao International Airport
Q1431111  |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Cibao
Q1431111  |  NEWvalue  |  name_pt   |                                                         |  Aeroporto Internacional do Cilbao
Q1431111  |  NEWvalue  |  name_sv   |                                                         |  Cibao International Airport
Q1431111  |  NEWvalue  |  name_zh   |                                                         |  聖地牙哥
Q721618   |  NEWvalue  |  name_ar   |                                                         |  مطار تبريز الدولي
Q721618   |  MODvalue  |  name_pl   |  Port lotniczy Tebriz                                   |  port lotniczy Tebriz
Q3912553  |  NEWvalue  |  name_fr   |                                                         |  Aéroport de Sault-Sainte-Marie
Q371955   |  NEWvalue  |  name_fr   |                                                         |  Aéroport de Dawson Creek
Q1200033  |  NEWvalue  |  name_fr   |                                                         |  Aéroport international de Zamboanga
Q483223   |  NEWvalue  |  name_de   |                                                         |  Flughafen Gimhae
Q483223   |  NEWvalue  |  name_en   |                                                         |  Gimhae International Airport
Q483223   |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Internacional de Gimhae
Q483223   |  NEWvalue  |  name_fr   |                                                         |  aéroport international de Gimhae
Q483223   |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Internasional Gimhae
Q483223   |  NEWvalue  |  name_it   |                                                         |  aeroporto Internazionale di Gimhae
Q483223   |  NEWvalue  |  name_ja   |                                                         |  金海国際空港
Q483223   |  NEWvalue  |  name_ko   |                                                         |  김해국제공항
Q483223   |  NEWvalue  |  name_nl   |                                                         |  Luchthaven Gimhae
Q483223   |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Pusan-Kimhae
Q483223   |  NEWvalue  |  name_pt   |                                                         |  Aeroporto Internacional de Gimhae
Q483223   |  NEWvalue  |  name_ru   |                                                         |  Кимхэ
Q483223   |  NEWvalue  |  name_sv   |                                                         |  Gimhae International Airport
Q483223   |  NEWvalue  |  name_tr   |                                                         |  Gimhae Uluslararası Havalimanı
Q483223   |  NEWvalue  |  name_vi   |                                                         |  Sân bay quốc tế Gimhae
Q483223   |  NEWvalue  |  name_zh   |                                                         |  金海国际机场
Q729886   |  NEWvalue  |  name_ar   |                                                         |  مطار تروندهايم، فارنيس
Q1431328  |  NEWvalue  |  name_ko   |                                                         |  포스두이구아수 국제공항
Q816717   |  MODvalue  |  name_en   |  Benazir Bhutto International Airport                   |  Islamabad International AirPort
Q14300    |  NEWvalue  |  name_sv   |                                                         |  Canberra International Airport
Q1432440  |  NEWvalue  |  name_hi   |                                                         |  कोलंबस हवाई अड्डा
Q1368739  |  NEWvalue  |  name_fr   |                                                         |  Aérodrome de Hamilton
Q1144167  |  NEWvalue  |  name_tr   |                                                         |  Shenyang Taoxian Uluslararası Havalimanı
Q158732   |  MODvalue  |  name_nl   |  Luchthaven Stuttgart                                   |  Flughafen Stuttgart
Q1431631  |  NEWvalue  |  name_ko   |                                                         |  주안다 국제공항
Q1547557  |  NEWvalue  |  name_ar   |                                                         |  مطار ماريسكال سوكري الدولي
Q1547557  |  NEWvalue  |  name_de   |                                                         |  Aeropuerto Internacional Mariscal Sucre
Q1547557  |  NEWvalue  |  name_en   |                                                         |  Mariscal Sucre International Airport
Q1547557  |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Internacional Mariscal Sucre
Q1547557  |  NEWvalue  |  name_fr   |                                                         |  aéroport international Mariscal Sucre
Q1547557  |  NEWvalue  |  name_hu   |                                                         |  Mariscal Sucre nemzetközi repülőtér
Q1547557  |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Internasional Mariscal Sucre
Q1547557  |  NEWvalue  |  name_it   |                                                         |  Aeroporto Internazionale Mariscal Sucre
Q1547557  |  NEWvalue  |  name_ja   |                                                         |  新キト国際空港
Q1547557  |  NEWvalue  |  name_ko   |                                                         |  마리스칼 수크레 국제공항
Q1547557  |  NEWvalue  |  name_nl   |                                                         |  Aeropuerto Internacional Mariscal Sucre
Q1547557  |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Quito
Q1547557  |  NEWvalue  |  name_pt   |                                                         |  Novo Aeroporto Internacional Mariscal Sucre
Q1547557  |  NEWvalue  |  name_sv   |                                                         |  Mariscal Sucre International Airport
Q1547557  |  NEWvalue  |  name_vi   |                                                         |  Sân bay quốc tế Mariscal Sucre
Q1547557  |  NEWvalue  |  name_zh   |                                                         |  蘇克雷元帥國際機場
Q61052    |  NEWvalue  |  name_ar   |                                                         |  مطار جناح الدولي
Q61052    |  NEWvalue  |  name_bn   |                                                         |  জিন্নাহ আন্তর্জাতিক বিমানবন্দর
Q61052    |  NEWvalue  |  name_de   |                                                         |  Karachi/Jinnah International Airport
Q61052    |  NEWvalue  |  name_en   |                                                         |  Jinnah International Airport
Q61052    |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Internacional Jinnah
Q61052    |  NEWvalue  |  name_fr   |                                                         |  aéroport international Jinnah
Q61052    |  NEWvalue  |  name_hi   |                                                         |  जिन्ना अंतरराष्ट्रीय हवाई अड्डे के
Q61052    |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Internasional Jinnah
Q61052    |  NEWvalue  |  name_it   |                                                         |  Aeroporto Internazionale Jinnah
Q61052    |  NEWvalue  |  name_ja   |                                                         |  ジンナー国際空港
Q61052    |  NEWvalue  |  name_ko   |                                                         |  진나 국제공항
Q61052    |  NEWvalue  |  name_nl   |                                                         |  Jinnah International Airport
Q61052    |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Karaczi
Q61052    |  NEWvalue  |  name_pt   |                                                         |  Aeroporto Internacional Jinnah
Q61052    |  NEWvalue  |  name_ru   |                                                         |  Джинна
Q61052    |  NEWvalue  |  name_vi   |                                                         |  Sân bay quốc tế Jinnah
Q61052    |  NEWvalue  |  name_zh   |                                                         |  真纳国际机场
Q141677   |  NEWvalue  |  name_tr   |                                                         |  Xi'an Xianyang Uluslararası Havalimanı
Q1151889  |  NEWvalue  |  name_ar   |                                                         |  مطار أصفهان الدولي
Q1151889  |  NEWvalue  |  name_de   |                                                         |  Isfahan Internationaler Flughafen
Q1151889  |  MODvalue  |  name_pl   |  Port lotniczy Isfahan                                  |  port lotniczy Isfahan
Q1430720  |  NEWvalue  |  name_sv   |                                                         |  General Juan N. Álvarez International Airport
Q177689   |  NEWvalue  |  name_hi   |                                                         |  कोटोका हवाई अड्डा
Q127955   |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Nikola Tesla Beograd
Q1148514  |  NEWvalue  |  name_bn   |                                                         |  ব্রুনাই আন্তর্জাতিক বিমানবন্দর
Q1100795  |  NEWvalue  |  name_hi   |                                                         |  हाप्किंग हवाई अड्डा
Q30603    |  MODvalue  |  name_es   |  Aeropuerto Internacional Zia                           |  Aeropuerto Internacional Hazrat Shahjalal
Q1266839  |  NEWvalue  |  name_hi   |                                                         |  लुईस बोधा हवाई अड्डा
Q645492   |  NEWvalue  |  name_hi   |                                                         |  न्जीली हवाई अड्डा
Q645492   |  NEWvalue  |  name_ko   |                                                         |  은질리 국제공항
Q491767   |  NEWvalue  |  name_hi   |                                                         |  सुनान हवाई अड्डा
Q765608   |  NEWvalue  |  name_hi   |                                                         |  ला अरोरा हवाई अड्डा
Q1043631  |  NEWvalue  |  name_hi   |                                                         |  मुर्तला मुहम्मद हवाई अड्डा
Q530773   |  NEWvalue  |  name_hi   |                                                         |  अगस्टो सेन्डिनो हवाई अड्डा
Q1152024  |  MODvalue  |  name_pl   |  Port lotniczy Meszhed                                  |  port lotniczy Meszhed
Q1432118  |  NEWvalue  |  name_ru   |                                                         |  Мерида
Q672289   |  NEWvalue  |  name_ar   |                                                         |  مطار مالطا الدولي
Q672289   |  NEWvalue  |  name_de   |                                                         |  Flughafen Malta
Q672289   |  NEWvalue  |  name_en   |                                                         |  Malta International Airport
Q672289   |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Internacional de Malta
Q672289   |  NEWvalue  |  name_fr   |                                                         |  aéroport international de Malte
Q672289   |  NEWvalue  |  name_hu   |                                                         |  Máltai nemzetközi repülőtér
Q672289   |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Internasional Malta
Q672289   |  NEWvalue  |  name_it   |                                                         |  Aeroporto Internazionale di Luca
Q672289   |  NEWvalue  |  name_ja   |                                                         |  マルタ国際空港
Q672289   |  NEWvalue  |  name_nl   |                                                         |  Luchthaven Malta
Q672289   |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Malta
Q672289   |  NEWvalue  |  name_pt   |                                                         |  Aeroporto Internacional de Malta
Q672289   |  NEWvalue  |  name_ru   |                                                         |  Мальта
Q672289   |  NEWvalue  |  name_sv   |                                                         |  Maltas internationella flygplats
Q672289   |  NEWvalue  |  name_vi   |                                                         |  Sân bay quốc tế Malta
Q672289   |  NEWvalue  |  name_zh   |                                                         |  馬耳他國際機場
Q1461076  |  NEWvalue  |  name_ko   |                                                         |  루이 암스트롱 뉴올리언스 국제공항
Q1432022  |  NEWvalue  |  name_ru   |                                                         |  Масатлан
Q1415006  |  MODvalue  |  name_zh   |  拿騷                                                     |  林丁平德林国际机场
Q905933   |  NEWvalue  |  name_ar   |                                                         |  مطار ديوري حماني
Q905933   |  NEWvalue  |  name_de   |                                                         |  Flughafen Niamey
Q905933   |  NEWvalue  |  name_en   |                                                         |  Diori Hamani International Airport
Q905933   |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Internacional Diori Hamani
Q905933   |  NEWvalue  |  name_fr   |                                                         |  aéroport international Diori Hamani
Q905933   |  NEWvalue  |  name_hu   |                                                         |  Diori Hamani nemzetközi repülőtér
Q905933   |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Internasional Diori Hamani
Q905933   |  NEWvalue  |  name_it   |                                                         |  Aeroporto di Niamey-Diori Hamani
Q905933   |  NEWvalue  |  name_ja   |                                                         |  ディオリ・アマニ国際空港
Q905933   |  NEWvalue  |  name_nl   |                                                         |  Luchthaven Diori Hamani
Q905933   |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Niamey
Q905933   |  NEWvalue  |  name_pt   |                                                         |  Niamey
Q905933   |  NEWvalue  |  name_ru   |                                                         |  Международный аэропорт имени Амани Диори
Q905933   |  NEWvalue  |  name_sv   |                                                         |  Niamey
Q905933   |  NEWvalue  |  name_vi   |                                                         |  Sân bay quốc tế Diori Hamani
Q905933   |  NEWvalue  |  name_zh   |                                                         |  迪奥里·哈马尼国际机场
Q1048704  |  NEWvalue  |  name_ar   |                                                         |  مطار ماكتان سيبو الدولي
Q1048704  |  NEWvalue  |  name_de   |                                                         |  Flughafen Mactan-Cebu
Q1048704  |  NEWvalue  |  name_en   |                                                         |  Mactan–Cebu International Airport
Q1048704  |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Internacional de Mactán-Cebú
Q1048704  |  NEWvalue  |  name_fr   |                                                         |  aéroport international de Mactan-Cebu
Q1048704  |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Internasional Cebu-Mactan
Q1048704  |  NEWvalue  |  name_it   |                                                         |  aeroporto Internazionale di Mactan-Cebu
Q1048704  |  NEWvalue  |  name_ja   |                                                         |  マクタン・セブ国際空港
Q1048704  |  NEWvalue  |  name_ko   |                                                         |  막탄 세부 국제공항
Q1048704  |  NEWvalue  |  name_nl   |                                                         |  Mactan-Cebu International Airport
Q1048704  |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Mactan-Cebu
Q1048704  |  NEWvalue  |  name_sv   |                                                         |  Mactan-Cebu International Airport
Q1048704  |  NEWvalue  |  name_vi   |                                                         |  Sân bay quốc tế Mactan-Cebu
Q1048704  |  NEWvalue  |  name_zh   |                                                         |  麥克坦－宿霧國際機場
Q1347672  |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Eppley
Q1432442  |  NEWvalue  |  name_de   |                                                         |  Flughafen Port Elizabeth
Q1432442  |  NEWvalue  |  name_en   |                                                         |  Port Elizabeth Airport
Q1432442  |  NEWvalue  |  name_es   |                                                         |  Aeropuerto de Port Elizabeth
Q1432442  |  NEWvalue  |  name_fr   |                                                         |  Aéroport de Port Elizabeth
Q1432442  |  NEWvalue  |  name_ja   |                                                         |  ポートエリザベス国際空港
Q1432442  |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Port Elizabeth
Q1432442  |  NEWvalue  |  name_vi   |                                                         |  Sân bay Port Elizabeth
Q1432442  |  NEWvalue  |  name_zh   |                                                         |  伊麗莎白港機場
Q1432525  |  NEWvalue  |  name_bn   |                                                         |  পুনে বিমানবন্দর
Q127951   |  NEWvalue  |  name_ar   |                                                         |  مطار صوفيا
Q127951   |  NEWvalue  |  name_bn   |                                                         |  সফিয়া বিমানবন্দর
Q127951   |  NEWvalue  |  name_de   |                                                         |  Flughafen Sofia
Q127951   |  NEWvalue  |  name_en   |                                                         |  Sofia Airport
Q127951   |  NEWvalue  |  name_es   |                                                         |  Aeropuerto de Sofía
Q127951   |  NEWvalue  |  name_fr   |                                                         |  aéroport de Sofia
Q127951   |  NEWvalue  |  name_hu   |                                                         |  Szófiai repülőtér
Q127951   |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Sofia
Q127951   |  NEWvalue  |  name_it   |                                                         |  Aeroporto di Sofia
Q127951   |  NEWvalue  |  name_ja   |                                                         |  ソフィア空港
Q127951   |  NEWvalue  |  name_nl   |                                                         |  Luchthaven Sofia
Q127951   |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Sofia
Q127951   |  NEWvalue  |  name_pt   |                                                         |  Aeroporto de Sófia
Q127951   |  NEWvalue  |  name_ru   |                                                         |  София
Q127951   |  NEWvalue  |  name_sv   |                                                         |  Vrazjdebna
Q127951   |  NEWvalue  |  name_tr   |                                                         |  Sofya Havalimanı
Q127951   |  NEWvalue  |  name_vi   |                                                         |  Sân bay Sofia
Q127951   |  NEWvalue  |  name_zh   |                                                         |  索菲亞機場
Q1151896  |  MODvalue  |  name_pl   |  Port lotniczy Sziraz                                   |  port lotniczy Sziraz
Q513684   |  NEWvalue  |  name_hi   |                                                         |  मेहराबाद हवाई अड्डा
Q217226   |  MODvalue  |  name_en   |  Tirana International Airport                           |  Tirana International Airport Nënë Tereza
Q1323755  |  NEWvalue  |  name_de   |                                                         |  Flughafen Winnipeg
Q1323755  |  NEWvalue  |  name_en   |                                                         |  Winnipeg James Armstrong Richardson International Airport
Q1323755  |  NEWvalue  |  name_es   |                                                         |  Aeropuerto Internacional James Armstrong Richardson
Q1323755  |  NEWvalue  |  name_fr   |                                                         |  aéroport international James Armstrong Richardson de Winnipeg
Q1323755  |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Internasional Winnipeg
Q1323755  |  NEWvalue  |  name_it   |                                                         |  Aeroporto Internazionale di Winnipeg-James Armstrong Richardson
Q1323755  |  NEWvalue  |  name_ja   |                                                         |  ウィニペグ・ジェームス・アームストロング・リチャードソン国際空港
Q1323755  |  NEWvalue  |  name_nl   |                                                         |  Winnipeg James Armstrong Richardson International Airport
Q1323755  |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Winnipeg
Q1323755  |  NEWvalue  |  name_pt   |                                                         |  Aeroporto Internacional de Winnipeg James Armstrong Richardson
Q1323755  |  NEWvalue  |  name_sv   |                                                         |  Winnipeg J. A. Richardson International Airport
Q1323755  |  NEWvalue  |  name_vi   |                                                         |  Sân bay quốc tế Winnipeg James Armstrong Richardson
Q1323755  |  NEWvalue  |  name_zh   |                                                         |  温尼伯詹姆斯·阿姆斯特朗·理查森国际机场
Q843204   |  NEWvalue  |  name_ar   |                                                         |  مطار ريكيافيك
Q843204   |  NEWvalue  |  name_de   |                                                         |  Flughafen Reykjavík
Q843204   |  NEWvalue  |  name_en   |                                                         |  Reykjavík Airport
Q843204   |  NEWvalue  |  name_es   |                                                         |  Aeropuerto de Reikiavik
Q843204   |  NEWvalue  |  name_fr   |                                                         |  aéroport de Reykjavik
Q843204   |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Reykjavik
Q843204   |  NEWvalue  |  name_it   |                                                         |  Aeroporto di Reykjavík
Q843204   |  NEWvalue  |  name_ja   |                                                         |  レイキャヴィーク空港
Q843204   |  NEWvalue  |  name_nl   |                                                         |  Luchthaven van Reykjavik
Q843204   |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Reykjavík
Q843204   |  NEWvalue  |  name_pt   |                                                         |  Aeroporto de Reykjavík
Q843204   |  NEWvalue  |  name_ru   |                                                         |  Рейкьявик
Q843204   |  NEWvalue  |  name_sv   |                                                         |  Reykjaviks flygplats
Q843204   |  NEWvalue  |  name_tr   |                                                         |  Reykjavík Havalimanı
Q843204   |  NEWvalue  |  name_vi   |                                                         |  Sân bay Reykjavík
Q1433005  |  NEWvalue  |  name_tr   |                                                         |  Talagi Havalimanı
Q223416   |  NEWvalue  |  name_hi   |                                                         |  और्ली हवाई अड्डा
Q2902013  |  NEWvalue  |  name_ko   |                                                         |  삿포로 비행장
Q1192811  |  NEWvalue  |  name_pt   |                                                         |  Aeroporto Internacional Francisco Bangoy
Q206277   |  MODvalue  |  name_sv   |  Kastrups flygplats                                     |  Köpenhamns flygplats
Q500945   |  NEWvalue  |  name_hi   |                                                         |  फेरीहेगी हवाई अड्डा
Q1431012  |  NEWvalue  |  name_ar   |                                                         |  مطار بروكسل شارلروا الجنوب
Q1431012  |  NEWvalue  |  name_de   |                                                         |  Flughafen Brüssel-Charleroi
Q1431012  |  NEWvalue  |  name_en   |                                                         |  Brussels South Charleroi Airport
Q1431012  |  NEWvalue  |  name_es   |                                                         |  Aeropuerto de Bruselas Sur
Q1431012  |  NEWvalue  |  name_fr   |                                                         |  aéroport de Charleroi Bruxelles-Sud
Q1431012  |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Charleroi Brussel Selatan
Q1431012  |  NEWvalue  |  name_it   |                                                         |  Aeroporto di Charleroi-Bruxelles Sud
Q1431012  |  NEWvalue  |  name_ja   |                                                         |  ブリュッセル・サウスシャルルロワ空港
Q1431012  |  NEWvalue  |  name_nl   |                                                         |  Brussels South Charleroi Airport
Q1431012  |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Bruksela-Charleroi
Q1431012  |  NEWvalue  |  name_ru   |                                                         |  Брюссель-Шарлеруа
Q1431012  |  NEWvalue  |  name_sv   |                                                         |  Brussels South Charleroi Airport
Q1431012  |  NEWvalue  |  name_zh   |                                                         |  沙勒罗瓦－布鲁塞尔南机场
Q9694     |  NEWvalue  |  name_ar   |                                                         |  مطار سخيبول أمستردام
Q9694     |  NEWvalue  |  name_de   |                                                         |  Flughafen Schiphol
Q9694     |  NEWvalue  |  name_en   |                                                         |  Amsterdam Airport Schiphol
Q9694     |  NEWvalue  |  name_es   |                                                         |  Aeropuerto de Ámsterdam-Schiphol
Q9694     |  NEWvalue  |  name_fr   |                                                         |  aéroport d'Amsterdam-Schiphol
Q9694     |  NEWvalue  |  name_el   |                                                         |  Διεθνές Αεροδρόμιο Σκίπχολ
Q9694     |  NEWvalue  |  name_hi   |                                                         |  शिफोल हवाई अड्डा
Q9694     |  NEWvalue  |  name_hu   |                                                         |  Schiphol repülőtér
Q9694     |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Internasional Schiphol
Q9694     |  NEWvalue  |  name_it   |                                                         |  aeroporto di Amsterdam-Schiphol
Q9694     |  NEWvalue  |  name_ja   |                                                         |  スキポール空港
Q9694     |  NEWvalue  |  name_ko   |                                                         |  스히폴 국제공항
Q9694     |  NEWvalue  |  name_nl   |                                                         |  Luchthaven Schiphol
Q9694     |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Amsterdam-Schiphol
Q9694     |  NEWvalue  |  name_pt   |                                                         |  Aeroporto de Amsterdão Schiphol
Q9694     |  NEWvalue  |  name_ru   |                                                         |  Схипхол
Q9694     |  NEWvalue  |  name_sv   |                                                         |  Amsterdam-Schiphol-flygplatsen
Q9694     |  NEWvalue  |  name_tr   |                                                         |  Amsterdam Schiphol Havalimanı
Q9694     |  NEWvalue  |  name_vi   |                                                         |  Sân bay Amsterdam Schiphol
Q9694     |  NEWvalue  |  name_zh   |                                                         |  阿姆斯特丹史基浦機場
Q94895    |  NEWvalue  |  name_ko   |                                                         |  볼티모어 워싱턴 서굿 마셜 국제공항
Q854130   |  NEWvalue  |  name_hi   |                                                         |  डी० एफ मलान हवाई अड्डा
Q459096   |  NEWvalue  |  name_hi   |                                                         |  डलास हवाई अड्डा
Q384788   |  NEWvalue  |  name_hi   |                                                         |  मिनिस्ट्रो पिस्तारिनी हवाई अड्डा
Q821750   |  NEWvalue  |  name_hi   |                                                         |  जान स्मट्स हवाई अड्डा
Q17581    |  NEWvalue  |  name_hi   |                                                         |  किंग्स्फोर्ड हवाई अड्डा
Q215327   |  MODvalue  |  name_zh   |  赫尔辛基－万塔机场                                              |  赫尔辛基-万塔机场
Q9688     |  NEWvalue  |  name_hi   |                                                         |  टेगेल हवाई अड्डा
Q32999    |  MODvalue  |  name_sv   |  Flughafen Wien-Schwechat                               |  Wien-Schwechats flygplats
Q46033    |  NEWvalue  |  name_ar   |                                                         |  مطار فرانكفورت
Q46033    |  NEWvalue  |  name_bn   |                                                         |  ফ্রাঙ্কফুর্ট বিমানবন্দর
Q46033    |  NEWvalue  |  name_de   |                                                         |  Flughafen Frankfurt am Main
Q46033    |  NEWvalue  |  name_en   |                                                         |  Frankfurt Airport
Q46033    |  NEWvalue  |  name_es   |                                                         |  aeropuerto de Frankfurt
Q46033    |  NEWvalue  |  name_fr   |                                                         |  aéroport international de Francfort / Rhein-Main
Q46033    |  NEWvalue  |  name_el   |                                                         |  Διεθνές Αεροδρόμιο Φρανκφούρτης
Q46033    |  NEWvalue  |  name_hi   |                                                         |  फ़्रैंकफ़र्ट विमानक्षेत्र
Q46033    |  NEWvalue  |  name_hu   |                                                         |  Frankfurti repülőtér
Q46033    |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Internasional Frankfurt
Q46033    |  NEWvalue  |  name_it   |                                                         |  aeroporto di Francoforte sul Meno
Q46033    |  NEWvalue  |  name_ja   |                                                         |  フランクフルト空港
Q46033    |  NEWvalue  |  name_ko   |                                                         |  프랑크푸르트 공항
Q46033    |  NEWvalue  |  name_nl   |                                                         |  Luchthaven Frankfurt am Main
Q46033    |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Frankfurt
Q46033    |  NEWvalue  |  name_pt   |                                                         |  Aeroporto de Frankfurt
Q46033    |  NEWvalue  |  name_ru   |                                                         |  Франкфурт-на-Майне
Q46033    |  NEWvalue  |  name_sv   |                                                         |  Frankfurt am Mains flygplats
Q46033    |  NEWvalue  |  name_tr   |                                                         |  Frankfurt Havalimanı
Q46033    |  NEWvalue  |  name_vi   |                                                         |  Sân bay quốc tế Frankfurt
Q46033    |  NEWvalue  |  name_zh   |                                                         |  法兰克福机场
Q482493   |  NEWvalue  |  name_hi   |                                                         |  किम्पो हवाई अड्डा
Q210559   |  NEWvalue  |  name_ar   |                                                         |  مطار أوسلو-غاردرموين
Q210559   |  NEWvalue  |  name_de   |                                                         |  Flughafen Oslo-Gardermoen
Q210559   |  NEWvalue  |  name_en   |                                                         |  Oslo Airport
Q210559   |  NEWvalue  |  name_es   |                                                         |  Aeropuerto de Oslo-Gardermoen
Q210559   |  NEWvalue  |  name_fr   |                                                         |  aéroport international d'Oslo-Gardermoen
Q210559   |  NEWvalue  |  name_hu   |                                                         |  Oslo–Gardermoeni repülőtér
Q210559   |  NEWvalue  |  name_id   |                                                         |  Bandar Udara Gardermoen Oslo
Q210559   |  NEWvalue  |  name_it   |                                                         |  Aeroporto di Oslo-Gardermoen
Q210559   |  NEWvalue  |  name_ja   |                                                         |  オスロ空港
Q210559   |  NEWvalue  |  name_ko   |                                                         |  오슬로 가르데르모엔 공항
Q210559   |  NEWvalue  |  name_nl   |                                                         |  Luchthaven Oslo Gardermoen
Q210559   |  NEWvalue  |  name_pl   |                                                         |  Port lotniczy Oslo-Gardermoen
Q210559   |  NEWvalue  |  name_pt   |                                                         |  Aeroporto de Oslo Gardermoen
Q210559   |  NEWvalue  |  name_ru   |                                                         |  Гардермуэн
Q210559   |  NEWvalue  |  name_sv   |                                                         |  Oslo flygplats
Q210559   |  NEWvalue  |  name_tr   |                                                         |  Oslo-Gardermoen Havalimanı
Q210559   |  NEWvalue  |  name_vi   |                                                         |  Sân bay Oslo
Q210559   |  NEWvalue  |  name_zh   |                                                         |  奥斯陆加勒穆恩机场
Q749497   |  NEWvalue  |  name_hi   |                                                         |  सुकानो हात्ता हवाई अड्डा
