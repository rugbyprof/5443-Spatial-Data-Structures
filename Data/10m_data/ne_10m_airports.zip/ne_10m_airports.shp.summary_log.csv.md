shapefilename                       |  var                     |  value
------------------------------------|--------------------------|-------
./10m_cultural/ne_10m_airports.shp  |  New_name                |  429
./10m_cultural/ne_10m_airports.shp  |  Deleted_name            |  1
./10m_cultural/ne_10m_airports.shp  |  Modified_name           |  18
./10m_cultural/ne_10m_airports.shp  |  Empty_name              |  7697
./10m_cultural/ne_10m_airports.shp  |  Same_name               |  10545
./10m_cultural/ne_10m_airports.shp  |  Wikidataid_redirected   |  0
./10m_cultural/ne_10m_airports.shp  |  Wikidataid_notfound     |  0
./10m_cultural/ne_10m_airports.shp  |  Wikidataid_null         |  1
./10m_cultural/ne_10m_airports.shp  |  Wikidataid_notnull      |  890
./10m_cultural/ne_10m_airports.shp  |  Wikidataid_badformated  |  0
