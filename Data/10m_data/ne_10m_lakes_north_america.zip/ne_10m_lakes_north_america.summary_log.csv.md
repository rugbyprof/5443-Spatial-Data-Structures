shapefilename                                  |  var                     |  value
-----------------------------------------------|--------------------------|-------
./10m_physical/ne_10m_lakes_north_america.shp  |  New_name                |  12
./10m_physical/ne_10m_lakes_north_america.shp  |  Deleted_name            |  0
./10m_physical/ne_10m_lakes_north_america.shp  |  Modified_name           |  3
./10m_physical/ne_10m_lakes_north_america.shp  |  Empty_name              |  7894
./10m_physical/ne_10m_lakes_north_america.shp  |  Same_name               |  1604
./10m_physical/ne_10m_lakes_north_america.shp  |  Wikidataid_redirected   |  1
./10m_physical/ne_10m_lakes_north_america.shp  |  Wikidataid_notfound     |  0
./10m_physical/ne_10m_lakes_north_america.shp  |  Wikidataid_null         |  747
./10m_physical/ne_10m_lakes_north_america.shp  |  Wikidataid_notnull      |  453
./10m_physical/ne_10m_lakes_north_america.shp  |  Wikidataid_badformated  |  0
