shapefilename                               |  var                     |  value
--------------------------------------------|--------------------------|-------
./10m_cultural/ne_10m_populated_places.shp  |  New_name                |  72711
./10m_cultural/ne_10m_populated_places.shp  |  Deleted_name            |  28
./10m_cultural/ne_10m_populated_places.shp  |  Modified_name           |  492
./10m_cultural/ne_10m_populated_places.shp  |  Empty_name              |  32602
./10m_cultural/ne_10m_populated_places.shp  |  Same_name               |  44653
./10m_cultural/ne_10m_populated_places.shp  |  Wikidataid_redirected   |  3
./10m_cultural/ne_10m_populated_places.shp  |  Wikidataid_notfound     |  0
./10m_cultural/ne_10m_populated_places.shp  |  Wikidataid_null         |  177
./10m_cultural/ne_10m_populated_places.shp  |  Wikidataid_notnull      |  7166
./10m_cultural/ne_10m_populated_places.shp  |  Wikidataid_badformated  |  0
