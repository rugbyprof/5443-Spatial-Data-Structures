wd_id      |  status    |  variable    |  value_old                                 |  value_new
-----------|------------|--------------|--------------------------------------------|------------------------------------
Q847785    |  MODvalue  |  name_de     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_en     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_nl     |  Colorado River                            |  Colorado
Q1092055   |  MODvalue  |  name_de     |  Cimarron River                            |  Cimarron
Q1092055   |  MODvalue  |  name_en     |  Cimarron River                            |  Cimarron
Q1092055   |  MODvalue  |  name_nl     |  Cimarron River                            |  Cimarron
Q2993598   |  MODvalue  |  name_de     |  Washita River                             |  Washita
Q2993598   |  MODvalue  |  name_en     |  Washita River                             |  Washita
Q2993598   |  MODvalue  |  name_pl     |  Washita River                             |  Washita
Q2993598   |  MODvalue  |  name_de     |  Washita River                             |  Washita
Q2993598   |  MODvalue  |  name_en     |  Washita River                             |  Washita
Q2993598   |  MODvalue  |  name_pl     |  Washita River                             |  Washita
Q5159475   |  MODvalue  |  name_en     |  Conecuh River                             |  Conecuh
Q7157190   |  MODvalue  |  name_en     |  Pea River                                 |  Pea
Q4272077   |  MODvalue  |  name_en     |  Choctawhatchee River                      |  Choctawhatchee
Q3348721   |  MODvalue  |  name_en     |  Ochlockonee River                         |  Ochlockonee
Q6651678   |  MODvalue  |  name_en     |  Little River                              |  Little
Q2386134   |  MODvalue  |  name_en     |  Satilla River                             |  Satilla
Q2830643   |  MODvalue  |  name_en     |  Alapaha River                             |  Alapaha
Q130012    |  MODvalue  |  name_en     |  Ogeechee River                            |  Ogeechee
Q1050460   |  MODvalue  |  name_de     |  Catawba River                             |  Catawba
Q1050460   |  MODvalue  |  name_en     |  Catawba River                             |  Catawba
Q1050460   |  MODvalue  |  name_nl     |  Catawba River                             |  Catawba
Q6708487   |  MODvalue  |  name_en     |  Lynches River                             |  Lynches
Q6708487   |  MODvalue  |  name_nl     |  Lynches River                             |  Lynches
Q6651298   |  MODvalue  |  name_en     |  Little Pee Dee River                      |  Little Pee Dee
Q6651298   |  MODvalue  |  name_nl     |  Little Pee Dee River                      |  Little Pee Dee
Q1034421   |  MODvalue  |  name_de     |  Cape Fear River                           |  Cape Fear
Q1034421   |  MODvalue  |  name_en     |  Cape Fear River                           |  Cape Fear
Q1034421   |  MODvalue  |  name_nl     |  Cape Fear River                           |  Cape Fear
Q2913438   |  MODvalue  |  name_de     |  Eno River                                 |  Eno
Q2913438   |  MODvalue  |  name_en     |  Eno River                                 |  Eno
Q5250264   |  MODvalue  |  name_en     |  Deep River                                |  Deep
Q5250264   |  MODvalue  |  name_nl     |  Deep River                                |  Deep
Q1159151   |  MODvalue  |  name_de     |  Dan River                                 |  Dan
Q1159151   |  MODvalue  |  name_en     |  Dan River                                 |  Dan
Q1159151   |  MODvalue  |  name_fr     |  Dan River                                 |  Dan
Q1159151   |  MODvalue  |  name_hu     |  Dan River                                 |  Dan
Q1159151   |  MODvalue  |  name_nl     |  Dan River                                 |  Dan
Q841725    |  MODvalue  |  name_de     |  Tar River                                 |  Tar
Q841725    |  MODvalue  |  name_en     |  Tar River                                 |  Tar
Q841725    |  MODvalue  |  name_fr     |  Tar River                                 |  Tar
Q841725    |  MODvalue  |  name_nl     |  Tar River                                 |  Tar
Q6809486   |  MODvalue  |  name_de     |  Meherrin River                            |  Meherrin
Q6809486   |  MODvalue  |  name_en     |  Meherrin River                            |  Meherrin
Q6809486   |  MODvalue  |  name_nl     |  Meherrin River                            |  Meherrin
Q7063766   |  MODvalue  |  name_en     |  Nottoway River                            |  Nottoway
Q7063766   |  MODvalue  |  name_nl     |  Nottoway River                            |  Nottoway
Q4431935   |  MODvalue  |  name_en     |  South River                               |  South
Q4431935   |  MODvalue  |  name_nl     |  South River                               |  South
Q1428859   |  MODvalue  |  name_de     |  Flint River                               |  Flint
Q1428859   |  MODvalue  |  name_en     |  Flint River                               |  Flint
Q1428859   |  MODvalue  |  name_it     |  Flint River                               |  Flint
Q1424101   |  MODvalue  |  name_de     |  Tallapoosa River                          |  Tallapoosa
Q1424101   |  MODvalue  |  name_en     |  Tallapoosa River                          |  Tallapoosa
Q968071    |  MODvalue  |  name_de     |  Etowah River                              |  Etowah
Q968071    |  MODvalue  |  name_en     |  Etowah River                              |  Etowah
Q5158226   |  MODvalue  |  name_en     |  Conasauga River                           |  Conasauga
Q7193324   |  MODvalue  |  name_en     |  Pigeon River                              |  Pigeon
Q7193324   |  MODvalue  |  name_nl     |  Pigeon River                              |  Pigeon
Q478303    |  MODvalue  |  name_de     |  French Broad River                        |  French Broad
Q478303    |  MODvalue  |  name_en     |  French Broad River                        |  French Broad
Q478303    |  MODvalue  |  name_nl     |  French Broad River                        |  French Broad
Q1775363   |  MODvalue  |  name_de     |  Nolichucky River                          |  Nolichucky
Q1775363   |  MODvalue  |  name_en     |  Nolichucky River                          |  Nolichucky
Q1775363   |  MODvalue  |  name_nl     |  Nolichucky River                          |  Nolichucky
Q2933076   |  MODvalue  |  name_en     |  Cahaba River                              |  Cahaba
Q6933808   |  MODvalue  |  name_en     |  Mulberry Fork of the Black Warrior River  |  Mulberry Fork of the Black Warrior
Q1810486   |  MODvalue  |  name_de     |  Leaf River                                |  Leaf
Q1810486   |  MODvalue  |  name_en     |  Leaf River                                |  Leaf
Q1201857   |  MODvalue  |  name_de     |  Yazoo River                               |  Yazoo
Q1201857   |  MODvalue  |  name_en     |  Yazoo River                               |  Yazoo
Q1201857   |  MODvalue  |  name_nl     |  Yazoo River                               |  Yazoo
Q8054249   |  MODvalue  |  name_en     |  Yockanookany River                        |  Yockanookany
Q1042217   |  MODvalue  |  name_en     |  Big Black River                           |  Big Black
Q2599098   |  MODvalue  |  name_de     |  Yalobusha River                           |  Yalobusha
Q2599098   |  MODvalue  |  name_en     |  Yalobusha River                           |  Yalobusha
Q2599098   |  MODvalue  |  name_fr     |  Yalobusha River                           |  Yalobusha
Q2599098   |  MODvalue  |  name_nl     |  Yalobusha River                           |  Yalobusha
Q5681137   |  MODvalue  |  name_en     |  Hatchie River                             |  Hatchie
Q5364109   |  MODvalue  |  name_en     |  Elk River                                 |  Elk
Q5364109   |  MODvalue  |  name_pl     |  Elk River                                 |  Elk
Q652618    |  MODvalue  |  name_de     |  Duck River                                |  Duck
Q652618    |  MODvalue  |  name_en     |  Duck River                                |  Duck
Q652618    |  MODvalue  |  name_pl     |  Duck River                                |  Duck
Q38930502  |  REDIRECT  |  wikidataid  |  Q38930502                                 |  Q34781055
Q206710    |  MODvalue  |  name_de     |  Powell River                              |  Powell
Q206710    |  MODvalue  |  name_en     |  Powell River                              |  Powell
Q2054792   |  MODvalue  |  name_en     |  Pamunkey River                            |  Pamunkey
Q2054792   |  MODvalue  |  name_fr     |  Pamunkey River                            |  Pamunkey
Q2054792   |  MODvalue  |  name_it     |  Pamunkey River                            |  Pamunkey
Q1333499   |  MODvalue  |  name_de     |  Rappahannock River                        |  Rappahannock
Q1333499   |  MODvalue  |  name_en     |  Rappahannock River                        |  Rappahannock
Q1333499   |  MODvalue  |  name_pl     |  Rappahannock River                        |  Rappahannock
Q1470734   |  MODvalue  |  name_de     |  Youghiogheny River                        |  Youghiogheny
Q1470734   |  MODvalue  |  name_en     |  Youghiogheny River                        |  Youghiogheny
Q1470734   |  MODvalue  |  name_fr     |  Youghiogheny River                        |  Youghiogheny
Q1470734   |  MODvalue  |  name_nl     |  Youghiogheny River                        |  Youghiogheny
Q1124709   |  MODvalue  |  name_de     |  Conemaugh River                           |  Conemaugh
Q1124709   |  MODvalue  |  name_en     |  Conemaugh River                           |  Conemaugh
Q1124709   |  MODvalue  |  name_nl     |  Conemaugh River                           |  Conemaugh
Q1931858   |  MODvalue  |  name_de     |  Middle Fork Holston River                 |  Middle Fork Holston
Q1101503   |  MODvalue  |  name_de     |  Clinch River                              |  Clinch
Q1101503   |  MODvalue  |  name_en     |  Clinch River                              |  Clinch
Q1101503   |  MODvalue  |  name_nl     |  Clinch River                              |  Clinch
Q7568327   |  MODvalue  |  name_en     |  South River                               |  South
Q7056518   |  MODvalue  |  name_en     |  North River                               |  North
Q5019586   |  MODvalue  |  name_en     |  Calfpasture River                         |  Calfpasture
Q5019586   |  MODvalue  |  name_nl     |  Calfpasture River                         |  Calfpasture
Q6117354   |  MODvalue  |  name_en     |  Jackson River                             |  Jackson
Q6117354   |  MODvalue  |  name_nl     |  Jackson River                             |  Jackson
Q1544689   |  MODvalue  |  name_de     |  Greenbrier River                          |  Greenbrier
Q1544689   |  MODvalue  |  name_en     |  Greenbrier River                          |  Greenbrier
Q1544689   |  MODvalue  |  name_fr     |  Greenbrier River                          |  Greenbrier
Q1544689   |  MODvalue  |  name_nl     |  Greenbrier River                          |  Greenbrier
Q5364110   |  MODvalue  |  name_de     |  Elk River                                 |  Elk
Q5364110   |  MODvalue  |  name_en     |  Elk River                                 |  Elk
Q671902    |  MODvalue  |  name_de     |  Little Kanawha River                      |  Little Kanawha
Q671902    |  MODvalue  |  name_en     |  Little Kanawha River                      |  Little Kanawha
Q671902    |  MODvalue  |  name_sv     |  Little Kanawha River                      |  Little Kanawha
Q2340104   |  MODvalue  |  name_de     |  Guyandotte River                          |  Guyandotte
Q2340104   |  MODvalue  |  name_en     |  Guyandotte River                          |  Guyandotte
Q2340104   |  MODvalue  |  name_pl     |  Guyandotte River                          |  Guyandotte
Q606566    |  MODvalue  |  name_en     |  Licking River                             |  Licking
Q606566    |  MODvalue  |  name_pl     |  Licking River                             |  Licking
Q1544647   |  MODvalue  |  name_de     |  Green River                               |  Green
Q1544647   |  MODvalue  |  name_en     |  Green River                               |  Green
Q1544647   |  MODvalue  |  name_pl     |  Green River                               |  Green
Q745070    |  MODvalue  |  name_en     |  Salt River                                |  Salt
Q745070    |  MODvalue  |  name_pl     |  Salt River                                |  Salt
Q4905160   |  MODvalue  |  name_en     |  Big Blue River                            |  Big Blue
Q4905160   |  MODvalue  |  name_nl     |  Big Blue River                            |  Big Blue
Q2126786   |  MODvalue  |  name_de     |  White River                               |  White
Q2126786   |  MODvalue  |  name_en     |  White River                               |  White
Q2126786   |  MODvalue  |  name_fr     |  White River                               |  White
Q2126786   |  MODvalue  |  name_nl     |  White River                               |  White
Q2126786   |  MODvalue  |  name_pl     |  White River                               |  White
Q246570    |  MODvalue  |  name_de     |  Great Miami River                         |  Great Miami
Q246570    |  MODvalue  |  name_en     |  Great Miami River                         |  Great Miami
Q246570    |  MODvalue  |  name_nl     |  Great Miami River                         |  Great Miami
Q246570    |  MODvalue  |  name_sv     |  Great Miami River                         |  Great Miami
Q5015966   |  MODvalue  |  name_en     |  Cache River                               |  Cache
Q1108022   |  MODvalue  |  name_de     |  Saint Francis River                       |  Saint Francis
Q1108022   |  MODvalue  |  name_en     |  St. Francis River                         |  St. Francis
Q1108022   |  MODvalue  |  name_nl     |  St. Francis River                         |  St. Francis
Q1108022   |  MODvalue  |  name_pl     |  Saint Francis River                       |  Saint Francis
Q1108022   |  MODvalue  |  name_de     |  Saint Francis River                       |  Saint Francis
Q1108022   |  MODvalue  |  name_en     |  St. Francis River                         |  St. Francis
Q1108022   |  MODvalue  |  name_nl     |  St. Francis River                         |  St. Francis
Q1108022   |  MODvalue  |  name_pl     |  Saint Francis River                       |  Saint Francis
Q1921090   |  MODvalue  |  name_de     |  Meramec River                             |  Meramec
Q1921090   |  MODvalue  |  name_en     |  Meramec River                             |  Meramec
Q1921090   |  MODvalue  |  name_nl     |  Meramec River                             |  Meramec
Q6652407   |  MODvalue  |  name_de     |  Little Wabash River                       |  Little Wabash
Q6652407   |  MODvalue  |  name_en     |  Little Wabash River                       |  Little Wabash
Q1334957   |  MODvalue  |  name_de     |  Embarras River                            |  Embarras
Q1334957   |  MODvalue  |  name_en     |  Embarras River                            |  Embarras
Q1807373   |  MODvalue  |  name_de     |  Sangamon River                            |  Sangamon
Q1807373   |  MODvalue  |  name_en     |  Sangamon River                            |  Sangamon
Q1807373   |  MODvalue  |  name_nl     |  Sangamon River                            |  Sangamon
Q3966983   |  MODvalue  |  name_en     |  Spoon River                               |  Spoon
Q3966983   |  MODvalue  |  name_nl     |  Spoon River                               |  Spoon
Q3695896   |  MODvalue  |  name_en     |  Chariton River                            |  Chariton
Q750839    |  MODvalue  |  name_de     |  Platte River                              |  Platte
Q750839    |  MODvalue  |  name_en     |  Platte River                              |  Platte
Q5595036   |  MODvalue  |  name_de     |  Grand River                               |  Grand
Q5595036   |  MODvalue  |  name_en     |  Grand River                               |  Grand
Q7795771   |  MODvalue  |  name_de     |  Thompson River                            |  Thompson
Q7795771   |  MODvalue  |  name_en     |  Thompson River                            |  Thompson
Q1681774   |  MODvalue  |  name_de     |  Turkey River                              |  Turkey
Q1681774   |  MODvalue  |  name_en     |  Turkey River                              |  Turkey
Q2548910   |  MODvalue  |  name_de     |  Wapsipinicon River                        |  Wapsipinicon
Q2548910   |  MODvalue  |  name_en     |  Wapsipinicon River                        |  Wapsipinicon
Q2548910   |  MODvalue  |  name_nl     |  Wapsipinicon River                        |  Wapsipinicon
Q492787    |  MODvalue  |  name_de     |  Des Moines River                          |  Des Moines
Q492787    |  MODvalue  |  name_en     |  Des Moines River                          |  Des Moines
Q492787    |  MODvalue  |  name_nl     |  Des Moines River                          |  Des Moines
Q492787    |  MODvalue  |  name_pl     |  Des Moines River                          |  Des Moines
Q492787    |  MODvalue  |  name_sv     |  Des Moines River                          |  Des Moines
Q492787    |  MODvalue  |  name_de     |  Des Moines River                          |  Des Moines
Q492787    |  MODvalue  |  name_en     |  Des Moines River                          |  Des Moines
Q492787    |  MODvalue  |  name_nl     |  Des Moines River                          |  Des Moines
Q492787    |  MODvalue  |  name_pl     |  Des Moines River                          |  Des Moines
Q492787    |  MODvalue  |  name_sv     |  Des Moines River                          |  Des Moines
Q2712738   |  MODvalue  |  name_de     |  Boyer River                               |  Boyer
Q2712738   |  MODvalue  |  name_en     |  Boyer River                               |  Boyer
Q2712738   |  MODvalue  |  name_de     |  Boyer River                               |  Boyer
Q2712738   |  MODvalue  |  name_en     |  Boyer River                               |  Boyer
Q1646498   |  MODvalue  |  name_de     |  Little Sioux River                        |  Little Sioux
Q1646498   |  MODvalue  |  name_en     |  Little Sioux River                        |  Little Sioux
Q1430371   |  MODvalue  |  name_de     |  Floyd River                               |  Floyd
Q1430371   |  MODvalue  |  name_en     |  Floyd River                               |  Floyd
Q1430371   |  MODvalue  |  name_fr     |  Floyd River                               |  Floyd
Q1430371   |  MODvalue  |  name_nl     |  Floyd River                               |  Floyd
Q3569503   |  MODvalue  |  name_en     |  Withlacoochee River                       |  Withlacoochee
Q3373802   |  MODvalue  |  name_en     |  Peace River                               |  Peace
Q3373802   |  MODvalue  |  name_fr     |  Peace River                               |  Peace
Q3373802   |  MODvalue  |  name_nl     |  Peace River                               |  Peace
Q1552614   |  MODvalue  |  name_de     |  Guadalupe River                           |  Guadalupe
Q1552614   |  MODvalue  |  name_en     |  Guadalupe River                           |  Guadalupe
Q1552614   |  MODvalue  |  name_fr     |  Guadalupe River                           |  Guadalupe
Q1468723   |  MODvalue  |  name_de     |  Nueces River                              |  Nueces
Q1468723   |  MODvalue  |  name_en     |  Nueces River                              |  Nueces
Q1468723   |  MODvalue  |  name_nl     |  Nueces River                              |  Nueces
Q1552614   |  MODvalue  |  name_de     |  Guadalupe River                           |  Guadalupe
Q1552614   |  MODvalue  |  name_en     |  Guadalupe River                           |  Guadalupe
Q1552614   |  MODvalue  |  name_fr     |  Guadalupe River                           |  Guadalupe
Q1468723   |  MODvalue  |  name_de     |  Nueces River                              |  Nueces
Q1468723   |  MODvalue  |  name_en     |  Nueces River                              |  Nueces
Q1468723   |  MODvalue  |  name_nl     |  Nueces River                              |  Nueces
Q1969490   |  MODvalue  |  name_de     |  Trinity River                             |  Trinity
Q1969490   |  MODvalue  |  name_en     |  Trinity River                             |  Trinity
Q1969490   |  MODvalue  |  name_nl     |  Trinity River                             |  Trinity
Q1969490   |  MODvalue  |  name_pl     |  Trinity River                             |  Trinity
Q2041614   |  MODvalue  |  name_de     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_en     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_nl     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_pl     |  Ouachita River                            |  Ouachita
Q2618310   |  MODvalue  |  name_en     |  Saline River                              |  Saline
Q964437    |  MODvalue  |  name_de     |  Neches River                              |  Neches
Q964437    |  MODvalue  |  name_en     |  Neches River                              |  Neches
Q964437    |  MODvalue  |  name_nl     |  Neches River                              |  Neches
Q3433661   |  MODvalue  |  name_en     |  Calcasieu River                           |  Calcasieu
Q4762748   |  MODvalue  |  name_en     |  Angelina River                            |  Angelina
Q24761469  |  MODvalue  |  name_en     |  Petit Jean River                          |  Petit Jean
Q2041614   |  MODvalue  |  name_de     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_en     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_nl     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_pl     |  Ouachita River                            |  Ouachita
Q6651668   |  MODvalue  |  name_en     |  Little River                              |  Little
Q9372502   |  MODvalue  |  name_en     |  Wichita River                             |  Wichita
Q9372502   |  MODvalue  |  name_nl     |  Wichita River                             |  Wichita
Q9372502   |  MODvalue  |  name_en     |  Wichita River                             |  Wichita
Q9372502   |  MODvalue  |  name_nl     |  Wichita River                             |  Wichita
Q3256709   |  MODvalue  |  name_en     |  Little Osage River                        |  Little Osage
Q943521    |  MODvalue  |  name_en     |  Verdigris River                           |  Verdigris
Q943521    |  MODvalue  |  name_nl     |  Verdigris River                           |  Verdigris
Q2215316   |  MODvalue  |  name_de     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_en     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_fr     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_it     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_nl     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q1916292   |  MODvalue  |  name_de     |  Medicine Lodge River                      |  Medicine Lodge
Q1916292   |  MODvalue  |  name_en     |  Medicine Lodge River                      |  Medicine Lodge
Q1916292   |  MODvalue  |  name_fr     |  Medicine Lodge River                      |  Medicine Lodge
Q1916292   |  MODvalue  |  name_nl     |  Medicine Lodge River                      |  Medicine Lodge
Q4515856   |  MODvalue  |  name_en     |  Chikaskia River                           |  Chikaskia
Q2618310   |  MODvalue  |  name_en     |  Saline River                              |  Saline
Q177627    |  MODvalue  |  name_de     |  Smoky Hill River                          |  Smoky Hill
Q177627    |  MODvalue  |  name_en     |  Smoky Hill River                          |  Smoky Hill
Q6649195   |  MODvalue  |  name_en     |  Little Blue River                         |  Little Blue
Q4905162   |  MODvalue  |  name_en     |  Big Blue River                            |  Big Blue
Q2328855   |  MODvalue  |  name_en     |  Nazas River                               |  Nazas
Q7414617   |  MODvalue  |  name_en     |  San Juan River                            |  San Juan
Q948470    |  MODvalue  |  name_en     |  Baluarte River                            |  Baluarte
Q3458794   |  MODvalue  |  name_en     |  Sinaloa River                             |  Sinaloa
Q4107580   |  MODvalue  |  name_en     |  Verde River                               |  Verde
Q2451378   |  MODvalue  |  name_en     |  San Pedro River                           |  San Pedro
Q2451378   |  MODvalue  |  name_hu     |  San Pedro River                           |  San Pedro
Q2451378   |  MODvalue  |  name_nl     |  San Pedro River                           |  San Pedro
Q16899736  |  MODvalue  |  name_en     |  San Simon River                           |  San Simon
Q2451378   |  MODvalue  |  name_en     |  San Pedro River                           |  San Pedro
Q2451378   |  MODvalue  |  name_hu     |  San Pedro River                           |  San Pedro
Q2451378   |  MODvalue  |  name_nl     |  San Pedro River                           |  San Pedro
Q2343949   |  MODvalue  |  name_en     |  Santa Cruz River                          |  Santa Cruz
Q4736170   |  MODvalue  |  name_en     |  Altar River                               |  Altar
Q8665483   |  MODvalue  |  name_en     |  Black River                               |  Black
Q8665483   |  MODvalue  |  name_fr     |  Black River                               |  Black
Q4107580   |  MODvalue  |  name_en     |  Verde River                               |  Verde
Q866712    |  MODvalue  |  name_de     |  Laramie River                             |  Laramie
Q866712    |  MODvalue  |  name_en     |  Laramie River                             |  Laramie
Q866712    |  MODvalue  |  name_fr     |  Laramie River                             |  Laramie
Q866712    |  MODvalue  |  name_nl     |  Laramie River                             |  Laramie
Q866712    |  MODvalue  |  name_sv     |  Laramie River                             |  Laramie
Q1124558   |  MODvalue  |  name_de     |  Niobrara River                            |  Niobrara
Q1124558   |  MODvalue  |  name_en     |  Niobrara River                            |  Niobrara
Q1124558   |  MODvalue  |  name_nl     |  Niobrara River                            |  Niobrara
Q2126786   |  MODvalue  |  name_de     |  White River                               |  White
Q2126786   |  MODvalue  |  name_en     |  White River                               |  White
Q2126786   |  MODvalue  |  name_fr     |  White River                               |  White
Q2126786   |  MODvalue  |  name_nl     |  White River                               |  White
Q2126786   |  MODvalue  |  name_pl     |  White River                               |  White
Q2126786   |  MODvalue  |  name_de     |  White River                               |  White
Q2126786   |  MODvalue  |  name_en     |  White River                               |  White
Q2126786   |  MODvalue  |  name_fr     |  White River                               |  White
Q2126786   |  MODvalue  |  name_nl     |  White River                               |  White
Q2126786   |  MODvalue  |  name_pl     |  White River                               |  White
Q1124558   |  MODvalue  |  name_de     |  Niobrara River                            |  Niobrara
Q1124558   |  MODvalue  |  name_en     |  Niobrara River                            |  Niobrara
Q1124558   |  MODvalue  |  name_nl     |  Niobrara River                            |  Niobrara
Q927116    |  MODvalue  |  name_de     |  Little Missouri River                     |  Little Missouri
Q927116    |  MODvalue  |  name_en     |  Little Missouri River                     |  Little Missouri
Q927116    |  MODvalue  |  name_nl     |  Little Missouri River                     |  Little Missouri
Q1367713   |  MODvalue  |  name_de     |  Moreau River                              |  Moreau
Q1367713   |  MODvalue  |  name_en     |  Moreau River                              |  Moreau
Q1367713   |  MODvalue  |  name_fr     |  Moreau River                              |  Moreau
Q1367713   |  MODvalue  |  name_nl     |  Moreau River                              |  Moreau
Q7567278   |  MODvalue  |  name_en     |  South Fork of the Grand River             |  South Fork of the Grand
Q7055396   |  MODvalue  |  name_en     |  North Fork of the Grand River             |  North Fork of the Grand
Q1033473   |  MODvalue  |  name_de     |  Cannonball River                          |  Cannonball
Q1033473   |  MODvalue  |  name_en     |  Cannonball River                          |  Cannonball
Q1033473   |  MODvalue  |  name_nl     |  Cannonball River                          |  Cannonball
Q1033473   |  MODvalue  |  name_sv     |  Cannonball River                          |  Cannonball
Q1592419   |  MODvalue  |  name_de     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_en     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_fr     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_nl     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_sv     |  Heart River                               |  Heart
Q815836    |  MODvalue  |  name_de     |  Belle Fourche River                       |  Belle Fourche
Q815836    |  MODvalue  |  name_en     |  Belle Fourche River                       |  Belle Fourche
Q815836    |  MODvalue  |  name_nl     |  Belle Fourche River                       |  Belle Fourche
Q815836    |  MODvalue  |  name_pl     |  Belle Fourche River                       |  Belle Fourche
Q815836    |  MODvalue  |  name_sv     |  Belle Fourche River                       |  Belle Fourche
Q927116    |  MODvalue  |  name_de     |  Little Missouri River                     |  Little Missouri
Q927116    |  MODvalue  |  name_en     |  Little Missouri River                     |  Little Missouri
Q927116    |  MODvalue  |  name_nl     |  Little Missouri River                     |  Little Missouri
Q7414617   |  MODvalue  |  name_en     |  San Juan River                            |  San Juan
Q7414617   |  MODvalue  |  name_en     |  San Juan River                            |  San Juan
Q5055533   |  MODvalue  |  name_en     |  Cazones River                             |  Cazones
Q6115751   |  MODvalue  |  name_en     |  Tecolutla River                           |  Tecolutla
Q2152125   |  MODvalue  |  name_en     |  Jamapa River                              |  Jamapa
Q476664    |  MODvalue  |  name_en     |  Sarabia River                             |  Sarabia
Q827561    |  MODvalue  |  name_en     |  Ameca River                               |  Ameca
Q1129218   |  MODvalue  |  name_en     |  Balsas River                              |  Balsas
Q847785    |  MODvalue  |  name_de     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_en     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_nl     |  Colorado River                            |  Colorado
Q2330973   |  MODvalue  |  name_en     |  Tehuantepec River                         |  Tehuantepec
Q2330973   |  MODvalue  |  name_nl     |  Tehuantepec River                         |  Tehuantepec
Q5351071   |  MODvalue  |  name_en     |  El Corte River                            |  El Corte
Q1590346   |  MODvalue  |  name_en     |  Pasión River                              |  Pasión
Q1590346   |  MODvalue  |  name_nl     |  Pasión River                              |  Pasión
Q2332765   |  MODvalue  |  name_en     |  San Pedro River                           |  San Pedro
Q4384912   |  MODvalue  |  name_en     |  Puerco River                              |  Puerco
Q2615286   |  MODvalue  |  name_en     |  Animas River                              |  Animas
Q1236386   |  MODvalue  |  name_de     |  Dolores River                             |  Dolores
Q1236386   |  MODvalue  |  name_en     |  Dolores River                             |  Dolores
Q4453762   |  MODvalue  |  name_en     |  Taylor River                              |  Taylor
Q3567786   |  MODvalue  |  name_en     |  White River                               |  White
Q3567786   |  MODvalue  |  name_fr     |  White River                               |  White
Q2599279   |  MODvalue  |  name_de     |  Yampa River                               |  Yampa
Q2599279   |  MODvalue  |  name_en     |  Yampa River                               |  Yampa
Q2599279   |  MODvalue  |  name_fr     |  Yampa River                               |  Yampa
Q2599279   |  MODvalue  |  name_nl     |  Yampa River                               |  Yampa
Q1865825   |  MODvalue  |  name_de     |  Little Snake River                        |  Little Snake
Q1865825   |  MODvalue  |  name_en     |  Little Snake River                        |  Little Snake
Q1787489   |  MODvalue  |  name_de     |  Tongue River                              |  Tongue
Q1787489   |  MODvalue  |  name_en     |  Tongue River                              |  Tongue
Q1787489   |  MODvalue  |  name_nl     |  Tongue River                              |  Tongue
Q1787489   |  MODvalue  |  name_pl     |  Tongue River                              |  Tongue
Q1787489   |  MODvalue  |  name_sv     |  Tongue River                              |  Tongue
Q1444096   |  MODvalue  |  name_de     |  Sweetwater River                          |  Sweetwater
Q1444096   |  MODvalue  |  name_en     |  Sweetwater River                          |  Sweetwater
Q1444096   |  MODvalue  |  name_nl     |  Sweetwater River                          |  Sweetwater
Q1444096   |  MODvalue  |  name_pl     |  Sweetwater River                          |  Sweetwater
Q1444096   |  MODvalue  |  name_sv     |  Sweetwater River                          |  Sweetwater
Q1444096   |  NEWvalue  |  name_zh     |                                            |  甘霖河
Q4148407   |  MODvalue  |  name_en     |  Greybull River                            |  Greybull
Q14687265  |  MODvalue  |  name_en     |  Pahsimeroi River                          |  Pahsimeroi
Q1262279   |  MODvalue  |  name_de     |  Sevier River                              |  Sevier
Q1262279   |  MODvalue  |  name_en     |  Sevier River                              |  Sevier
Q1262279   |  MODvalue  |  name_nl     |  Sevier River                              |  Sevier
Q1130341   |  MODvalue  |  name_de     |  Fremont River                             |  Fremont
Q1130341   |  MODvalue  |  name_en     |  Fremont River                             |  Fremont
Q1130341   |  MODvalue  |  name_nl     |  Fremont River                             |  Fremont
Q14711868  |  MODvalue  |  name_en     |  San Pitch River                           |  San Pitch
Q1676970   |  MODvalue  |  name_de     |  Virgin River                              |  Virgin
Q1676970   |  MODvalue  |  name_en     |  Virgin River                              |  Virgin
Q1676970   |  MODvalue  |  name_it     |  Virgin River                              |  Virgin
Q1676970   |  MODvalue  |  name_nl     |  Virgin River                              |  Virgin
Q2126786   |  MODvalue  |  name_de     |  White River                               |  White
Q2126786   |  MODvalue  |  name_en     |  White River                               |  White
Q2126786   |  MODvalue  |  name_fr     |  White River                               |  White
Q2126786   |  MODvalue  |  name_nl     |  White River                               |  White
Q2126786   |  MODvalue  |  name_pl     |  White River                               |  White
Q891080    |  MODvalue  |  name_de     |  Boise River                               |  Boise
Q891080    |  MODvalue  |  name_en     |  Boise River                               |  Boise
Q891080    |  MODvalue  |  name_nl     |  Boise River                               |  Boise
Q4086416   |  MODvalue  |  name_en     |  Big Wood River                            |  Big Wood
Q4905972   |  MODvalue  |  name_en     |  Big Lost River                            |  Big Lost
Q2926582   |  MODvalue  |  name_en     |  Bruneau River                             |  Bruneau
Q2042749   |  MODvalue  |  name_de     |  Owyhee River                              |  Owyhee
Q2042749   |  MODvalue  |  name_en     |  Owyhee River                              |  Owyhee
Q2042749   |  MODvalue  |  name_nl     |  Owyhee River                              |  Owyhee
Q7272287   |  MODvalue  |  name_en     |  Quinn River                               |  Quinn
Q594295    |  MODvalue  |  name_de     |  Malheur River                             |  Malheur
Q594295    |  MODvalue  |  name_en     |  Malheur River                             |  Malheur
Q1126662   |  MODvalue  |  name_de     |  Kern River                                |  Kern
Q1126662   |  MODvalue  |  name_en     |  Kern River                                |  Kern
Q1126662   |  MODvalue  |  name_fr     |  Kern River                                |  Kern
Q1126662   |  MODvalue  |  name_nl     |  Kern River                                |  Kern
Q1264687   |  MODvalue  |  name_de     |  Kings River                               |  Kings
Q1264687   |  MODvalue  |  name_en     |  Kings River                               |  Kings
Q1264687   |  MODvalue  |  name_nl     |  Kings River                               |  Kings
Q1807419   |  MODvalue  |  name_de     |  Tuolumne River                            |  Tuolumne
Q1807419   |  MODvalue  |  name_en     |  Tuolumne River                            |  Tuolumne
Q1470035   |  MODvalue  |  name_de     |  Merced River                              |  Merced
Q1470035   |  MODvalue  |  name_en     |  Merced River                              |  Merced
Q1470035   |  MODvalue  |  name_nl     |  Merced River                              |  Merced
Q1470035   |  NEWvalue  |  name_pl     |                                            |  Merced
Q2319307   |  MODvalue  |  name_en     |  Owens River                               |  Owens
Q2319307   |  NEWvalue  |  name_it     |                                            |  Owens
Q2319307   |  MODvalue  |  name_nl     |  Owens River                               |  Owens
Q7055372   |  MODvalue  |  name_en     |  North Fork American River                 |  North Fork American
Q14683517  |  MODvalue  |  name_en     |  North Yuba River                          |  North Yuba
Q14683506  |  NEWvalue  |  name_de     |                                            |  North Fork Eel
Q14683506  |  MODvalue  |  name_en     |  North Fork Eel River                      |  North Fork Eel
Q2030974   |  MODvalue  |  name_de     |  Russian River                             |  Russian
Q2030974   |  MODvalue  |  name_en     |  Russian River                             |  Russian
Q2030974   |  MODvalue  |  name_fr     |  Russian River                             |  Russian
Q2030974   |  MODvalue  |  name_nl     |  Russian River                             |  Russian
Q2030974   |  MODvalue  |  name_pl     |  Russian River                             |  Russian
Q1969490   |  MODvalue  |  name_de     |  Trinity River                             |  Trinity
Q1969490   |  MODvalue  |  name_en     |  Trinity River                             |  Trinity
Q1969490   |  MODvalue  |  name_nl     |  Trinity River                             |  Trinity
Q1969490   |  MODvalue  |  name_pl     |  Trinity River                             |  Trinity
Q3506776   |  MODvalue  |  name_en     |  Sycan River                               |  Sycan
Q2581283   |  MODvalue  |  name_de     |  Williamson River                          |  Williamson
Q2581283   |  MODvalue  |  name_en     |  Williamson River                          |  Williamson
Q2581283   |  MODvalue  |  name_nl     |  Williamson River                          |  Williamson
Q535450    |  MODvalue  |  name_de     |  Crooked River                             |  Crooked
Q535450    |  MODvalue  |  name_en     |  Crooked River                             |  Crooked
Q535450    |  MODvalue  |  name_nl     |  Crooked River                             |  Crooked
Q7304926   |  MODvalue  |  name_en     |  Red Rock River                            |  Red Rock
Q7304926   |  MODvalue  |  name_nl     |  Red Rock River                            |  Red Rock
Q1099574   |  MODvalue  |  name_de     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_en     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_nl     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_sv     |  Clearwater River                          |  Clearwater
Q3115025   |  MODvalue  |  name_en     |  Grande Ronde River                        |  Grande Ronde
Q6665167   |  MODvalue  |  name_en     |  Lochsa River                              |  Lochsa
Q334812    |  MODvalue  |  name_en     |  Bitterroot River                          |  Bitterroot
Q1099574   |  MODvalue  |  name_de     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_en     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_nl     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_sv     |  Clearwater River                          |  Clearwater
Q7448888   |  MODvalue  |  name_en     |  Selway River                              |  Selway
Q858903    |  MODvalue  |  name_de     |  Big Hole River                            |  Big Hole
Q858903    |  MODvalue  |  name_en     |  Big Hole River                            |  Big Hole
Q858903    |  MODvalue  |  name_fr     |  Big Hole River                            |  Big Hole
Q858903    |  MODvalue  |  name_nl     |  Big Hole River                            |  Big Hole
Q1440192   |  MODvalue  |  name_de     |  Fox River                                 |  Fox
Q1440192   |  MODvalue  |  name_en     |  Fox River                                 |  Fox
Q8637      |  MODvalue  |  name_de     |  Des Plaines River                         |  Des Plaines
Q8637      |  MODvalue  |  name_en     |  Des Plaines River                         |  Des Plaines
Q8637      |  MODvalue  |  name_nl     |  Des Plaines River                         |  Des Plaines
Q6749927   |  MODvalue  |  name_de     |  Manistee River                            |  Manistee
Q6749927   |  MODvalue  |  name_en     |  Manistee River                            |  Manistee
Q6749927   |  MODvalue  |  name_nl     |  Manistee River                            |  Manistee
Q4818973   |  MODvalue  |  name_de     |  Au Sable River                            |  Au Sable
Q4818973   |  MODvalue  |  name_en     |  Au Sable River                            |  Au Sable
Q1136667   |  MODvalue  |  name_de     |  Tippecanoe River                          |  Tippecanoe
Q1136667   |  MODvalue  |  name_en     |  Tippecanoe River                          |  Tippecanoe
Q1136667   |  MODvalue  |  name_nl     |  Tippecanoe River                          |  Tippecanoe
Q282052    |  MODvalue  |  name_de     |  Maumee River                              |  Maumee
Q282052    |  MODvalue  |  name_en     |  Maumee River                              |  Maumee
Q282052    |  MODvalue  |  name_nl     |  Maumee River                              |  Maumee
Q282052    |  MODvalue  |  name_pl     |  Maumee River                              |  Maumee
Q615010    |  MODvalue  |  name_de     |  Kalamazoo River                           |  Kalamazoo
Q615010    |  MODvalue  |  name_en     |  Kalamazoo River                           |  Kalamazoo
Q615010    |  MODvalue  |  name_nl     |  Kalamazoo River                           |  Kalamazoo
Q3433802   |  MODvalue  |  name_de     |  St. Joseph River                          |  St. Joseph
Q3433802   |  MODvalue  |  name_en     |  St. Joseph River                          |  St. Joseph
Q3433802   |  MODvalue  |  name_nl     |  St. Joseph River                          |  St. Joseph
Q1138574   |  MODvalue  |  name_de     |  St. Joseph River                          |  St. Joseph
Q1138574   |  MODvalue  |  name_en     |  St. Joseph River                          |  St. Joseph
Q1146724   |  MODvalue  |  name_de     |  Cuyahoga River                            |  Cuyahoga
Q1146724   |  MODvalue  |  name_en     |  Cuyahoga River                            |  Cuyahoga
Q1146724   |  MODvalue  |  name_nl     |  Cuyahoga River                            |  Cuyahoga
Q1146724   |  MODvalue  |  name_pl     |  Cuyahoga River                            |  Cuyahoga
Q1146724   |  MODvalue  |  name_sv     |  Cuyahoga River                            |  Cuyahoga
Q4920789   |  MODvalue  |  name_en     |  Black Fork Mohican River                  |  Black Fork Mohican
Q674618    |  MODvalue  |  name_de     |  Sandusky River                            |  Sandusky
Q674618    |  MODvalue  |  name_en     |  Sandusky River                            |  Sandusky
Q674618    |  MODvalue  |  name_hu     |  Sandusky River                            |  Sandusky
Q674618    |  MODvalue  |  name_nl     |  Sandusky River                            |  Sandusky
Q674618    |  MODvalue  |  name_pl     |  Sandusky River                            |  Sandusky
Q7808710   |  MODvalue  |  name_en     |  Tioga River                               |  Tioga
Q5141388   |  MODvalue  |  name_en     |  Cohocton River                            |  Cohocton
Q1422687   |  MODvalue  |  name_de     |  Genesee River                             |  Genesee
Q1422687   |  MODvalue  |  name_en     |  Genesee River                             |  Genesee
Q1422687   |  MODvalue  |  name_nl     |  Genesee River                             |  Genesee
Q1422687   |  MODvalue  |  name_sv     |  Genesee River                             |  Genesee
Q7299385   |  MODvalue  |  name_en     |  Raystown Branch Juniata River             |  Raystown Branch Juniata
Q605122    |  MODvalue  |  name_de     |  Schuylkill River                          |  Schuylkill
Q605122    |  MODvalue  |  name_en     |  Schuylkill River                          |  Schuylkill
Q605122    |  MODvalue  |  name_ja     |  英：Schuylkill River                        |  英：Schuylkill
Q605122    |  MODvalue  |  name_nl     |  Schuylkill River                          |  Schuylkill
Q1631368   |  MODvalue  |  name_de     |  Housatonic River                          |  Housatonic
Q1631368   |  MODvalue  |  name_en     |  Housatonic River                          |  Housatonic
Q1631368   |  MODvalue  |  name_nl     |  Housatonic River                          |  Housatonic
Q1631368   |  NEWvalue  |  name_zh     |                                            |  豪萨托尼河
Q880926    |  MODvalue  |  name_de     |  Blackstone River                          |  Blackstone
Q880926    |  MODvalue  |  name_en     |  Blackstone River                          |  Blackstone
Q880926    |  MODvalue  |  name_fr     |  Blackstone River                          |  Blackstone
Q880926    |  MODvalue  |  name_nl     |  Blackstone River                          |  Blackstone
Q2210898   |  MODvalue  |  name_de     |  Saco River                                |  Saco
Q2210898   |  MODvalue  |  name_en     |  Saco River                                |  Saco
Q2210898   |  MODvalue  |  name_fr     |  Saco River                                |  Saco
Q2210898   |  MODvalue  |  name_nl     |  Saco River                                |  Saco
Q514154    |  MODvalue  |  name_de     |  Androscoggin River                        |  Androscoggin
Q514154    |  MODvalue  |  name_en     |  Androscoggin River                        |  Androscoggin
Q514154    |  MODvalue  |  name_fr     |  Androscoggin River                        |  Androscoggin
Q514154    |  MODvalue  |  name_nl     |  Androscoggin River                        |  Androscoggin
Q945954    |  MODvalue  |  name_de     |  Penobscot River                           |  Penobscot
Q945954    |  MODvalue  |  name_en     |  Penobscot River                           |  Penobscot
Q945954    |  MODvalue  |  name_nl     |  Penobscot River                           |  Penobscot
Q6789623   |  MODvalue  |  name_en     |  Mattawamkeag River                        |  Mattawamkeag
Q14715290  |  MODvalue  |  name_en     |  Moose River                               |  Moose
Q14715290  |  MODvalue  |  name_en     |  Moose River                               |  Moose
Q3433767   |  MODvalue  |  name_en     |  Nicolet River                             |  Nicolet
Q2038996   |  MODvalue  |  name_en     |  Yamaska River                             |  Yamaska
Q1164787   |  MODvalue  |  name_de     |  Winooski River                            |  Winooski
Q1164787   |  MODvalue  |  name_en     |  Winooski River                            |  Winooski
Q6482141   |  MODvalue  |  name_de     |  Lamoille River                            |  Lamoille
Q6482141   |  MODvalue  |  name_en     |  Lamoille River                            |  Lamoille
Q1894790   |  MODvalue  |  name_de     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_en     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_fr     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_nl     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_sv     |  Margaree River                            |  Margaree
Q6460763   |  MODvalue  |  name_de     |  LaHave River                              |  LaHave
Q6460763   |  MODvalue  |  name_en     |  LaHave River                              |  LaHave
Q6460763   |  MODvalue  |  name_fr     |  Fleuve La Hève                            |  fleuve La Hève
Q6460763   |  MODvalue  |  name_nl     |  LaHave River                              |  LaHave
Q6460763   |  MODvalue  |  name_sv     |  LaHave River                              |  LaHave
Q3433623   |  MODvalue  |  name_de     |  Annapolis River                           |  Annapolis
Q3433623   |  MODvalue  |  name_en     |  Annapolis River                           |  Annapolis
Q3433623   |  MODvalue  |  name_sv     |  Annapolis River                           |  Annapolis
Q126922    |  MODvalue  |  name_en     |  Petitcodiac River                         |  Petitcodiac
Q126922    |  MODvalue  |  name_nl     |  Petitcodiac River                         |  Petitcodiac
Q126922    |  MODvalue  |  name_sv     |  Petitcodiac River                         |  Petitcodiac
Q3433710   |  MODvalue  |  name_de     |  Kennebecasis River                        |  Kennebecasis
Q3433710   |  MODvalue  |  name_en     |  Kennebecasis River                        |  Kennebecasis
Q3433710   |  MODvalue  |  name_sv     |  Kennebecasis River                        |  Kennebecasis
Q5327920   |  MODvalue  |  name_en     |  East Branch Penobscot River               |  East Branch Penobscot
Q1814459   |  MODvalue  |  name_en     |  Restigouche River                         |  Restigouche
Q1814459   |  MODvalue  |  name_sv     |  Restigouche River                         |  Restigouche
Q1323214   |  MODvalue  |  name_de     |  Tobique River                             |  Tobique
Q1323214   |  MODvalue  |  name_en     |  Tobique River                             |  Tobique
Q676140    |  MODvalue  |  name_de     |  Nepisiguit River                          |  Nepisiguit
Q676140    |  MODvalue  |  name_en     |  Nepisiguit River                          |  Nepisiguit
Q3433776   |  MODvalue  |  name_en     |  Patapédia River                           |  Patapédia
Q3433668   |  MODvalue  |  name_en     |  Cascapédia River                          |  Cascapédia
Q3433668   |  MODvalue  |  name_sv     |  Cascapédia River                          |  Cascapédia
Q2909926   |  MODvalue  |  name_en     |  Bonaventure River                         |  Bonaventure
Q15842609  |  MODvalue  |  name_en     |  York river                                |  York
Q15842579  |  MODvalue  |  name_en     |  Jupiter river                             |  Jupiter
Q7703132   |  MODvalue  |  name_en     |  Terra Nova River                          |  Terra Nova
Q7703132   |  MODvalue  |  name_sv     |  Terra Nova River                          |  Terra Nova
Q994493    |  MODvalue  |  name_de     |  Victoria River                            |  Victoria
Q994493    |  MODvalue  |  name_en     |  Victoria River                            |  Victoria
Q994493    |  MODvalue  |  name_fr     |  Victoria River                            |  Victoria
Q994493    |  MODvalue  |  name_nl     |  Victoria River                            |  Victoria
Q994493    |  MODvalue  |  name_sv     |  Victoria River                            |  Victoria
Q22385729  |  MODvalue  |  name_en     |  Alexis River                              |  Alexis
Q22385729  |  MODvalue  |  name_nl     |  Alexis River                              |  Alexis
Q22385729  |  MODvalue  |  name_sv     |  Alexis River                              |  Alexis
Q860143    |  MODvalue  |  name_en     |  Little Mecatina River                     |  Little Mecatina
Q860139    |  MODvalue  |  name_en     |  Romaine River                             |  Romaine
Q2155692   |  MODvalue  |  name_en     |  Magpie River                              |  Magpie
Q2155745   |  MODvalue  |  name_en     |  Saint-Jean River                          |  Saint-Jean
Q1229773   |  MODvalue  |  name_en     |  Saint-Augustin River                      |  Saint-Augustin
Q1276816   |  MODvalue  |  name_de     |  Eagle River                               |  Eagle
Q1276816   |  MODvalue  |  name_en     |  Eagle River                               |  Eagle
Q1276816   |  MODvalue  |  name_de     |  Eagle River                               |  Eagle
Q1276816   |  MODvalue  |  name_en     |  Eagle River                               |  Eagle
Q813500    |  MODvalue  |  name_de     |  Beaver River                              |  Beaver
Q813500    |  MODvalue  |  name_en     |  Beaver River                              |  Beaver
Q813500    |  MODvalue  |  name_nl     |  Beaver River                              |  Beaver
Q15391847  |  MODvalue  |  name_de     |  Kaipokok River                            |  Kaipokok
Q15391863  |  MODvalue  |  name_de     |  Kanairiktok River                         |  Kanairiktok
Q7056518   |  MODvalue  |  name_en     |  North River                               |  North
Q2155693   |  MODvalue  |  name_en     |  Marralik River                            |  Marralik
Q1690616   |  MODvalue  |  name_en     |  Qurlutuq River                            |  Qurlutuq
Q15842573  |  MODvalue  |  name_en     |  Falcoz River                              |  Falcoz
Q15842574  |  MODvalue  |  name_en     |  Ford River                                |  Ford
Q15842581  |  MODvalue  |  name_en     |  Koroc River                               |  Koroc
Q15842577  |  MODvalue  |  name_en     |  Goodwood River                            |  Goodwood
Q15842603  |  MODvalue  |  name_en     |  Swampy Bay River                          |  Swampy Bay
Q2155753   |  MODvalue  |  name_en     |  Wheeler River                             |  Wheeler
Q15842617  |  NEWvalue  |  name_ar     |                                            |  نهر الشيف
Q15842617  |  NEWvalue  |  name_bn     |                                            |  শেফের নদী
Q15842617  |  NEWvalue  |  name_en     |                                            |  Rivière du Chef
Q15842617  |  NEWvalue  |  name_it     |                                            |  rivière du Chef
Q15842617  |  NEWvalue  |  name_zh     |                                            |  厨师的河
Q15842591  |  MODvalue  |  name_en     |  Ouasiemsca river                          |  Ouasiemsca
Q771286    |  MODvalue  |  name_en     |  Mistassibi River                          |  Mistassibi
Q1376163   |  MODvalue  |  name_en     |  Mistassini River                          |  Mistassini
Q2155749   |  MODvalue  |  name_en     |  Temiscanie River                          |  Temiscanie
Q1968809   |  MODvalue  |  name_en     |  Eastmain River                            |  Eastmain
Q1968809   |  MODvalue  |  name_nl     |  Eastmain River                            |  Eastmain
Q1521554   |  MODvalue  |  name_en     |  Pons River                                |  Pons
Q2155674   |  MODvalue  |  name_en     |  False River                               |  False
Q20054135  |  MODvalue  |  name_en     |  Aigneau River                             |  Aigneau
Q20054135  |  MODvalue  |  name_nl     |  Aigneau River                             |  Aigneau
Q20054135  |  NEWvalue  |  name_sv     |                                            |  Rivière Aigneau
Q15842570  |  MODvalue  |  name_en     |  Delay River                               |  Delay
Q31308     |  MODvalue  |  name_en     |  Sakami River                              |  Sakami
Q20671938  |  MODvalue  |  name_en     |  Lefroy River                              |  Lefroy
Q20671938  |  MODvalue  |  name_nl     |  Lefroy River                              |  Lefroy
Q20011158  |  MODvalue  |  name_en     |  Buet River                                |  Buet
Q20011158  |  MODvalue  |  name_nl     |  Buet River                                |  Buet
Q7908009   |  MODvalue  |  name_en     |  Vachon River                              |  Vachon
Q19847205  |  MODvalue  |  name_en     |  Chukotat River                            |  Chukotat
Q19847205  |  MODvalue  |  name_nl     |  Chukotat River                            |  Chukotat
Q19934983  |  MODvalue  |  name_en     |  Qikirtaluup Kuunga River                  |  Qikirtaluup Kuunga
Q19955893  |  MODvalue  |  name_en     |  Coats River                               |  Coats
Q19955893  |  MODvalue  |  name_nl     |  Coats River                               |  Coats
Q20669533  |  MODvalue  |  name_en     |  Denys River                               |  Denys
Q20669533  |  MODvalue  |  name_nl     |  Denys River                               |  Denys
Q19952102  |  MODvalue  |  name_en     |  Chauvreulx River                          |  Chauvreulx
Q19952102  |  MODvalue  |  name_nl     |  Chauvreulx River                          |  Chauvreulx
Q15842606  |  MODvalue  |  name_en     |  Vauquelin River                           |  Vauquelin
Q7359388   |  MODvalue  |  name_en     |  Roggan River                              |  Roggan
Q1603754   |  MODvalue  |  name_en     |  Opawica river                             |  Opawica
Q1603754   |  MODvalue  |  name_nl     |  Opawica River                             |  Opawica
Q20645849  |  MODvalue  |  name_en     |  Maicasagi River                           |  Maicasagi
Q20645849  |  MODvalue  |  name_nl     |  Maicasagi River                           |  Maicasagi
Q22440718  |  MODvalue  |  name_en     |  Wetetnagami River                         |  Wetetnagami
Q15842566  |  MODvalue  |  name_en     |  Conn River                                |  Conn
Q15867664  |  MODvalue  |  name_en     |  Jolicoeur River                           |  Jolicoeur
Q1412295   |  MODvalue  |  name_en     |  Pontax River                              |  Pontax
Q22457456  |  MODvalue  |  name_en     |  Ashuanipi River                           |  Ashuanipi
Q22457456  |  MODvalue  |  name_nl     |  Ashuanipi River                           |  Ashuanipi
Q22457456  |  MODvalue  |  name_sv     |  Ashuanipi River                           |  Ashuanipi
Q22457456  |  MODvalue  |  name_en     |  Ashuanipi River                           |  Ashuanipi
Q22457456  |  MODvalue  |  name_nl     |  Ashuanipi River                           |  Ashuanipi
Q22457456  |  MODvalue  |  name_sv     |  Ashuanipi River                           |  Ashuanipi
Q22457456  |  MODvalue  |  name_en     |  Ashuanipi River                           |  Ashuanipi
Q22457456  |  MODvalue  |  name_nl     |  Ashuanipi River                           |  Ashuanipi
Q22457456  |  MODvalue  |  name_sv     |  Ashuanipi River                           |  Ashuanipi
Q779746    |  MODvalue  |  name_en     |  Opinaca River                             |  Opinaca
Q2155737   |  MODvalue  |  name_en     |  Sainte-Marguerite river                   |  Sainte-Marguerite
Q2155677   |  MODvalue  |  name_en     |  Hart Jaune river                          |  Hart Jaune
Q2155747   |  MODvalue  |  name_en     |  Toulnustouc River                         |  Toulnustouc
Q601290    |  MODvalue  |  name_en     |  Betsiamites River                         |  Betsiamites
Q601290    |  MODvalue  |  name_fr     |  Betsiamites                               |  rivière Betsiamites
Q15842594  |  MODvalue  |  name_en     |  Portneuf River                            |  Portneuf
Q2155664   |  MODvalue  |  name_en     |  Batiscan River                            |  Batiscan
Q1628265   |  MODvalue  |  name_en     |  Jacques-Cartier River                     |  Jacques-Cartier
Q968475    |  MODvalue  |  name_de     |  Black River                               |  Black
Q968475    |  MODvalue  |  name_en     |  Black River                               |  Black
Q968475    |  MODvalue  |  name_nl     |  Black River                               |  Black
Q3930308   |  MODvalue  |  name_de     |  Raquette River                            |  Raquette
Q3930308   |  MODvalue  |  name_en     |  Raquette River                            |  Raquette
Q3930308   |  MODvalue  |  name_fr     |  Raquette River                            |  rivière Raquette
Q3930308   |  MODvalue  |  name_nl     |  Raquette River                            |  Raquette
Q1570842   |  MODvalue  |  name_en     |  L'Assomption River                        |  L'Assomption
Q2155741   |  MODvalue  |  name_en     |  Rouge River                               |  Rouge
Q15842564  |  NEWvalue  |  name_ar     |                                            |  نهر بازين
Q15842564  |  MODvalue  |  name_en     |  Bazin River                               |  Bazin
Q15842564  |  NEWvalue  |  name_it     |                                            |  rivière Bazin
Q15842564  |  NEWvalue  |  name_nl     |                                            |  rivière Bazin
Q391411    |  MODvalue  |  name_en     |  Gatineau River                            |  Gatineau
Q391411    |  MODvalue  |  name_nl     |  Gatineau River                            |  Gatineau
Q391411    |  MODvalue  |  name_sv     |  Rivière Gatineau                          |  Gatineaufloden
Q60974     |  MODvalue  |  name_de     |  Ottawa River                              |  Ottawa
Q60974     |  MODvalue  |  name_en     |  Ottawa River                              |  Ottawa
Q60974     |  MODvalue  |  name_it     |  Ottawa River                              |  Ottawa
Q776238    |  MODvalue  |  name_en     |  Coulonge River                            |  Coulonge
Q1594722   |  MODvalue  |  name_de     |  Madawaska River                           |  Madawaska
Q1594722   |  MODvalue  |  name_en     |  Madawaska River                           |  Madawaska
Q1594722   |  MODvalue  |  name_nl     |  Madawaska River                           |  Madawaska
Q1594722   |  MODvalue  |  name_sv     |  Madawaska River                           |  Madawaska
Q1884310   |  MODvalue  |  name_de     |  Magnetawan River                          |  Magnetawan
Q1884310   |  MODvalue  |  name_en     |  Magnetawan River                          |  Magnetawan
Q1884310   |  MODvalue  |  name_fr     |  Magnetawan River                          |  Magnetawan
Q1884310   |  MODvalue  |  name_nl     |  Magnetawan River                          |  Magnetawan
Q1884310   |  MODvalue  |  name_sv     |  Magnetawan River                          |  Magnetawan
Q5617744   |  MODvalue  |  name_de     |  Gull River                                |  Gull
Q5617744   |  MODvalue  |  name_en     |  Gull River                                |  Gull
Q1379758   |  MODvalue  |  name_de     |  Moira River                               |  Moira
Q1379758   |  MODvalue  |  name_en     |  Moira River                               |  Moira
Q1379758   |  MODvalue  |  name_fr     |  Moira River                               |  Moira
Q1379758   |  MODvalue  |  name_nl     |  Moira River                               |  Moira
Q1379758   |  MODvalue  |  name_sv     |  Moira River                               |  Moira
Q1400280   |  MODvalue  |  name_de     |  Saugeen River                             |  Saugeen
Q1400280   |  MODvalue  |  name_en     |  Saugeen River                             |  Saugeen
Q1400280   |  MODvalue  |  name_fr     |  Saugeen River                             |  Saugeen
Q1400280   |  MODvalue  |  name_nl     |  Saugeen River                             |  Saugeen
Q1400280   |  MODvalue  |  name_sv     |  Saugeen River                             |  Saugeen
Q6737173   |  MODvalue  |  name_en     |  Maitland River                            |  Maitland
Q2408930   |  MODvalue  |  name_de     |  Thames River                              |  Thames
Q2408930   |  MODvalue  |  name_en     |  Thames River                              |  Thames
Q2408930   |  MODvalue  |  name_nl     |  Thames River                              |  Thames
Q2408930   |  MODvalue  |  name_sv     |  Thames River                              |  Thames
Q1955484   |  MODvalue  |  name_de     |  Musselshell River                         |  Musselshell
Q1955484   |  MODvalue  |  name_en     |  Musselshell River                         |  Musselshell
Q1955484   |  MODvalue  |  name_nl     |  Musselshell River                         |  Musselshell
Q1147392   |  MODvalue  |  name_de     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_en     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_fr     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_nl     |  Fox River                                 |  Fox
Q941928    |  MODvalue  |  name_de     |  Wolf River                                |  Wolf
Q941928    |  MODvalue  |  name_en     |  Wolf River                                |  Wolf
Q941928    |  MODvalue  |  name_nl     |  Wolf River                                |  Wolf
Q7171400   |  MODvalue  |  name_de     |  Peshtigo River                            |  Peshtigo
Q7171400   |  MODvalue  |  name_en     |  Peshtigo River                            |  Peshtigo
Q4978769   |  MODvalue  |  name_de     |  Brule River                               |  Brule
Q4978769   |  MODvalue  |  name_en     |  Brule River                               |  Brule
Q3311500   |  MODvalue  |  name_en     |  Michigamme River                          |  Michigamme
Q2278535   |  MODvalue  |  name_de     |  Sheyenne River                            |  Sheyenne
Q2278535   |  MODvalue  |  name_en     |  Sheyenne River                            |  Sheyenne
Q2278535   |  MODvalue  |  name_fr     |  Sheyenne River                            |  Sheyenne
Q2278535   |  MODvalue  |  name_nl     |  Sheyenne River                            |  Sheyenne
Q1861254   |  MODvalue  |  name_de     |  Yakima River                              |  Yakima
Q1861254   |  MODvalue  |  name_en     |  Yakima River                              |  Yakima
Q1861254   |  MODvalue  |  name_nl     |  Yakima River                              |  Yakima
Q1138229   |  MODvalue  |  name_de     |  Cowlitz River                             |  Cowlitz
Q1138229   |  MODvalue  |  name_en     |  Cowlitz River                             |  Cowlitz
Q1138229   |  MODvalue  |  name_fr     |  Cowlitz River                             |  Cowlitz
Q1138229   |  MODvalue  |  name_nl     |  Cowlitz River                             |  Cowlitz
Q3567786   |  MODvalue  |  name_en     |  White River                               |  White
Q3567786   |  MODvalue  |  name_fr     |  White River                               |  White
Q259157    |  MODvalue  |  name_de     |  Chehalis River                            |  Chehalis
Q259157    |  MODvalue  |  name_en     |  Chehalis River                            |  Chehalis
Q259157    |  MODvalue  |  name_nl     |  Chehalis River                            |  Chehalis
Q2196805   |  MODvalue  |  name_en     |  Saint Joe River                           |  Saint Joe
Q2196805   |  MODvalue  |  name_nl     |  Saint Joe River                           |  Saint Joe
Q305408    |  MODvalue  |  name_de     |  Skagit River                              |  Skagit
Q305408    |  MODvalue  |  name_en     |  Skagit River                              |  Skagit
Q305408    |  MODvalue  |  name_nl     |  Skagit River                              |  Skagit
Q304833    |  MODvalue  |  name_de     |  Similkameen River                         |  Similkameen
Q304833    |  MODvalue  |  name_en     |  Similkameen River                         |  Similkameen
Q304833    |  MODvalue  |  name_sv     |  Similkameen River                         |  Similkameen
Q270484    |  MODvalue  |  name_de     |  Kettle River                              |  Kettle
Q270484    |  MODvalue  |  name_en     |  Kettle River                              |  Kettle
Q270484    |  MODvalue  |  name_nl     |  Kettle River                              |  Kettle
Q2262      |  MODvalue  |  name_de     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_en     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_nl     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_sv     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_de     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_en     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_nl     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_sv     |  Kootenay River                            |  Kootenay
Q13948373  |  MODvalue  |  name_en     |  Highwood River                            |  Highwood
Q13948373  |  MODvalue  |  name_sv     |  Highwood River                            |  Highwood
Q5364109   |  MODvalue  |  name_en     |  Elk River                                 |  Elk
Q5364109   |  MODvalue  |  name_pl     |  Elk River                                 |  Elk
Q6114866   |  MODvalue  |  name_en     |  Blackfoot River                           |  Blackfoot
Q3503758   |  MODvalue  |  name_de     |  Sun River                                 |  Sun
Q3503758   |  MODvalue  |  name_en     |  Sun River                                 |  Sun
Q3503758   |  MODvalue  |  name_fr     |  Sun River                                 |  Sun
Q3503758   |  MODvalue  |  name_nl     |  Sun River                                 |  Sun
Q334781    |  MODvalue  |  name_en     |  Middle Fork Flathead River                |  Middle Fork Flathead
Q7859083   |  MODvalue  |  name_en     |  Two Medicine River                        |  Two Medicine
Q3433645   |  MODvalue  |  name_en     |  Belly River                               |  Belly
Q3433645   |  MODvalue  |  name_sv     |  Belly River                               |  Belly
Q177469    |  MODvalue  |  name_de     |  Frenchman River                           |  Frenchman
Q177469    |  MODvalue  |  name_en     |  Frenchman River                           |  Frenchman
Q177469    |  MODvalue  |  name_nl     |  Frenchman River                           |  Frenchman
Q177469    |  MODvalue  |  name_sv     |  Frenchman River                           |  Frenchman
Q487925    |  MODvalue  |  name_de     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_en     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_nl     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_sv     |  Souris River                              |  Souris
Q22461970  |  MODvalue  |  name_en     |  Aubinadong River                          |  Aubinadong
Q22461970  |  MODvalue  |  name_nl     |  Aubinadong River                          |  Aubinadong
Q22461970  |  MODvalue  |  name_sv     |  Aubinadong River                          |  Aubinadong
Q5588216   |  MODvalue  |  name_en     |  Goulais River                             |  Goulais
Q5588216   |  MODvalue  |  name_nl     |  Goulais River                             |  Goulais
Q5588216   |  MODvalue  |  name_sv     |  Goulais River                             |  Goulais
Q4868716   |  MODvalue  |  name_en     |  Batchawana River                          |  Batchawana
Q4868716   |  MODvalue  |  name_sv     |  Batchawana River                          |  Batchawana
Q1946435   |  MODvalue  |  name_de     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_en     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_sv     |  Montreal River                            |  Montreal
Q59464     |  MODvalue  |  name_de     |  Mattagami River                           |  Mattagami
Q59464     |  MODvalue  |  name_en     |  Mattagami River                           |  Mattagami
Q59464     |  MODvalue  |  name_fr     |  Mattagami River                           |  rivière Mattagami
Q59464     |  MODvalue  |  name_nl     |  Mattagami River                           |  Mattagami
Q59464     |  MODvalue  |  name_sv     |  Mattagami River                           |  Mattagami
Q116183    |  MODvalue  |  name_de     |  Kapuskasing River                         |  Kapuskasing
Q116183    |  MODvalue  |  name_en     |  Kapuskasing River                         |  Kapuskasing
Q116183    |  MODvalue  |  name_fr     |  Kapuskasing River                         |  Kapuskasing
Q116183    |  MODvalue  |  name_nl     |  Kapuskasing River                         |  Kapuskasing
Q116183    |  MODvalue  |  name_sv     |  Kapuskasing River                         |  Kapuskasing
Q20750422  |  MODvalue  |  name_en     |  Wawagosic River                           |  Wawagosic
Q22424453  |  MODvalue  |  name_en     |  Kinosheo River                            |  Kinosheo
Q22424453  |  MODvalue  |  name_nl     |  Kinosheo River                            |  Kinosheo
Q22424453  |  MODvalue  |  name_sv     |  Kinosheo River                            |  Kinosheo
Q15109911  |  MODvalue  |  name_de     |  Drowning River                            |  Drowning
Q15109911  |  MODvalue  |  name_en     |  Drowning River                            |  Drowning
Q15109911  |  MODvalue  |  name_sv     |  Drowning River                            |  Drowning
Q16893144  |  MODvalue  |  name_en     |  Kapiskau River                            |  Kapiskau
Q16893144  |  MODvalue  |  name_nl     |  Kapiskau River                            |  Kapiskau
Q16893144  |  MODvalue  |  name_sv     |  Kapiskau River                            |  Kapiskau
Q6503578   |  MODvalue  |  name_en     |  Lawashi River                             |  Lawashi
Q6503578   |  MODvalue  |  name_nl     |  Lawashi River                             |  Lawashi
Q6503578   |  MODvalue  |  name_sv     |  Lawashi River                             |  Lawashi
Q2372020   |  MODvalue  |  name_de     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_en     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_sv     |  Swan River                                |  Swan
Q15128416  |  MODvalue  |  name_de     |  Shamattawa River                          |  Shamattawa
Q15128416  |  MODvalue  |  name_en     |  Shamattawa River                          |  Shamattawa
Q15128416  |  MODvalue  |  name_nl     |  Shamattawa River                          |  Shamattawa
Q15128416  |  MODvalue  |  name_sv     |  Shamattawa River                          |  Shamattawa
Q7303872   |  MODvalue  |  name_en     |  Red Cedar River                           |  Red Cedar
Q968475    |  MODvalue  |  name_de     |  Black River                               |  Black
Q968475    |  MODvalue  |  name_en     |  Black River                               |  Black
Q968475    |  MODvalue  |  name_nl     |  Black River                               |  Black
Q1273955   |  MODvalue  |  name_de     |  Saint Louis River                         |  Saint Louis
Q1273955   |  MODvalue  |  name_en     |  Saint Louis River                         |  Saint Louis
Q1273955   |  MODvalue  |  name_nl     |  Saint Louis River                         |  Saint Louis
Q3442448   |  MODvalue  |  name_de     |  Roseau River                              |  Roseau
Q3442448   |  MODvalue  |  name_en     |  Roseau River                              |  Roseau
Q3442448   |  MODvalue  |  name_nl     |  Roseau River                              |  Roseau
Q7958699   |  MODvalue  |  name_de     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_en     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_nl     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_sv     |  Wabigoon River                            |  Wabigoon
Q22461606  |  MODvalue  |  name_en     |  Attwood River                             |  Attwood
Q22461606  |  MODvalue  |  name_nl     |  Attwood River                             |  Attwood
Q22461606  |  MODvalue  |  name_sv     |  Attwood River                             |  Attwood
Q5288219   |  MODvalue  |  name_de     |  Dog River                                 |  Dog
Q5288219   |  MODvalue  |  name_en     |  Dog River                                 |  Dog
Q7995902   |  MODvalue  |  name_en     |  Whitefish River                           |  Whitefish
Q2461680   |  MODvalue  |  name_de     |  Turtle River                              |  Turtle
Q2461680   |  MODvalue  |  name_en     |  Turtle River                              |  Turtle
Q15124859  |  MODvalue  |  name_de     |  Pineimuta River                           |  Pineimuta
Q15124859  |  MODvalue  |  name_en     |  Pineimuta River                           |  Pineimuta
Q15124859  |  MODvalue  |  name_nl     |  Pineimuta River                           |  Pineimuta
Q15124859  |  MODvalue  |  name_sv     |  Pineimuta River                           |  Pineimuta
Q15116445  |  MODvalue  |  name_de     |  Kawinogans River                          |  Kawinogans
Q15116445  |  MODvalue  |  name_en     |  Kawinogans River                          |  Kawinogans
Q15116445  |  MODvalue  |  name_nl     |  Kawinogans River                          |  Kawinogans
Q15116445  |  MODvalue  |  name_sv     |  Kawinogans River                          |  Kawinogans
Q15123712  |  MODvalue  |  name_de     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_en     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_nl     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_sv     |  Otoskwin River                            |  Otoskwin
Q15124871  |  MODvalue  |  name_de     |  Pipestone River                           |  Pipestone
Q15124871  |  MODvalue  |  name_en     |  Pipestone River                           |  Pipestone
Q819057    |  MODvalue  |  name_de     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_en     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_fr     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_nl     |  Berens River                              |  Berens
Q11880756  |  MODvalue  |  name_de     |  Manigotagan River                         |  Manigotagan
Q11880756  |  MODvalue  |  name_en     |  Manigotagan River                         |  Manigotagan
Q11880756  |  MODvalue  |  name_sv     |  Manigotagan River                         |  Manigotagan
Q885244    |  MODvalue  |  name_de     |  Bloodvein River                           |  Bloodvein
Q885244    |  MODvalue  |  name_en     |  Bloodvein River                           |  Bloodvein
Q885244    |  MODvalue  |  name_fr     |  Bloodvein River                           |  Bloodvein
Q885244    |  MODvalue  |  name_nl     |  Bloodvein River                           |  Bloodvein
Q885244    |  MODvalue  |  name_sv     |  Bloodvein River                           |  Bloodvein
Q819057    |  MODvalue  |  name_de     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_en     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_fr     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_nl     |  Berens River                              |  Berens
Q1621199   |  MODvalue  |  name_de     |  Poplar River                              |  Poplar
Q1621199   |  MODvalue  |  name_en     |  Poplar River                              |  Poplar
Q1621199   |  MODvalue  |  name_sv     |  Poplar River                              |  Poplar
Q7295398   |  MODvalue  |  name_en     |  Rat River                                 |  Rat
Q7295398   |  NEWvalue  |  name_nl     |                                            |  Rat
Q7295398   |  NEWvalue  |  name_sv     |                                            |  Rat
Q5046702   |  MODvalue  |  name_de     |  Carrot River                              |  Carrot
Q5046702   |  MODvalue  |  name_en     |  Carrot River                              |  Carrot
Q5046702   |  MODvalue  |  name_fr     |  Carrot River                              |  Carrot
Q5046702   |  MODvalue  |  name_sv     |  Carrot River                              |  Carrot
Q2372020   |  MODvalue  |  name_de     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_en     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_sv     |  Swan River                                |  Swan
Q850119    |  MODvalue  |  name_de     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_en     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_nl     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_sv     |  Red Deer River                            |  Red Deer
Q5046702   |  MODvalue  |  name_de     |  Carrot River                              |  Carrot
Q5046702   |  MODvalue  |  name_en     |  Carrot River                              |  Carrot
Q5046702   |  MODvalue  |  name_fr     |  Carrot River                              |  Carrot
Q5046702   |  MODvalue  |  name_sv     |  Carrot River                              |  Carrot
Q7415866   |  MODvalue  |  name_en     |  Sand River                                |  Sand
Q7415866   |  MODvalue  |  name_sv     |  Sand River                                |  Sand
Q14612484  |  MODvalue  |  name_de     |  Christina River                           |  Christina
Q14612484  |  MODvalue  |  name_en     |  Christina River                           |  Christina
Q14612484  |  MODvalue  |  name_fr     |  Christina River                           |  Christina
Q813500    |  MODvalue  |  name_de     |  Beaver River                              |  Beaver
Q813500    |  MODvalue  |  name_en     |  Beaver River                              |  Beaver
Q813500    |  MODvalue  |  name_nl     |  Beaver River                              |  Beaver
Q12749684  |  MODvalue  |  name_de     |  Vermilion River                           |  Vermilion
Q12749684  |  MODvalue  |  name_en     |  Vermilion River                           |  Vermilion
Q850119    |  MODvalue  |  name_de     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_en     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_nl     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_sv     |  Red Deer River                            |  Red Deer
Q22699042  |  MODvalue  |  name_en     |  Medicine River                            |  Medicine
Q22699042  |  MODvalue  |  name_nl     |  Medicine River                            |  Medicine
Q22699042  |  MODvalue  |  name_sv     |  Medicine River                            |  Medicine
Q1099571   |  MODvalue  |  name_de     |  Clearwater River                          |  Clearwater
Q1099571   |  MODvalue  |  name_en     |  Clearwater River                          |  Clearwater
Q1099571   |  MODvalue  |  name_fr     |  Clearwater River                          |  Clearwater
Q1099571   |  NEWvalue  |  name_it     |                                            |  Clearwater
Q1099571   |  MODvalue  |  name_sv     |  Clearwater River                          |  Clearwater
Q903023    |  MODvalue  |  name_de     |  Brazeau River                             |  Brazeau
Q903023    |  MODvalue  |  name_en     |  Brazeau River                             |  Brazeau
Q903023    |  MODvalue  |  name_sv     |  Brazeau River                             |  Brazeau
Q1915292   |  MODvalue  |  name_de     |  McLeod River                              |  McLeod
Q1915292   |  MODvalue  |  name_en     |  McLeod River                              |  McLeod
Q2068478   |  MODvalue  |  name_de     |  Pembina River                             |  Pembina
Q2068478   |  MODvalue  |  name_en     |  Pembina River                             |  Pembina
Q2372020   |  MODvalue  |  name_de     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_en     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_sv     |  Swan River                                |  Swan
Q6651973   |  MODvalue  |  name_de     |  Little Smoky River                        |  Little Smoky
Q6651973   |  MODvalue  |  name_en     |  Little Smoky River                        |  Little Smoky
Q6651973   |  MODvalue  |  name_sv     |  Little Smoky River                        |  Little Smoky
Q15128582  |  MODvalue  |  name_de     |  Simonette River                           |  Simonette
Q268519    |  MODvalue  |  name_de     |  Kakwa River                               |  Kakwa
Q268519    |  MODvalue  |  name_en     |  Kakwa River                               |  Kakwa
Q268519    |  MODvalue  |  name_sv     |  Kakwa River                               |  Kakwa
Q1551634   |  MODvalue  |  name_de     |  Smoky River                               |  Smoky
Q1551634   |  MODvalue  |  name_en     |  Smoky River                               |  Smoky
Q1551634   |  MODvalue  |  name_hu     |  Smoky River                               |  Smoky
Q1551634   |  NEWvalue  |  name_it     |                                            |  Smoky
Q1551634   |  NEWvalue  |  name_ja     |                                            |  スモーキー川
Q1551634   |  MODvalue  |  name_sv     |  Smoky River                               |  Smoky
Q22620185  |  MODvalue  |  name_nl     |  MacKay River                              |  MacKay
Q22620185  |  MODvalue  |  name_sv     |  MacKay River                              |  MacKay
Q5016581   |  MODvalue  |  name_en     |  Cadotte River                             |  Cadotte
Q5016581   |  MODvalue  |  name_sv     |  Cadotte River                             |  Cadotte
Q22659004  |  MODvalue  |  name_sv     |  Loon River                                |  Loon
Q15108141  |  MODvalue  |  name_de     |  Buffalo River                             |  Buffalo
Q15108141  |  MODvalue  |  name_en     |  Buffalo River                             |  Buffalo
Q22509169  |  MODvalue  |  name_en     |  Mikkwa River                              |  Mikkwa
Q22509169  |  MODvalue  |  name_nl     |  Mikkwa River                              |  Mikkwa
Q22509169  |  MODvalue  |  name_sv     |  Mikkwa River                              |  Mikkwa
Q15107689  |  MODvalue  |  name_de     |  Birch River                               |  Birch
Q15118712  |  MODvalue  |  name_de     |  Little Buffalo River                      |  Little Buffalo
Q15118712  |  MODvalue  |  name_en     |  Little Buffalo River                      |  Little Buffalo
Q15108141  |  MODvalue  |  name_de     |  Buffalo River                             |  Buffalo
Q15108141  |  MODvalue  |  name_en     |  Buffalo River                             |  Buffalo
Q22603397  |  MODvalue  |  name_en     |  Haultain River                            |  Haultain
Q22603397  |  MODvalue  |  name_nl     |  Haultain River                            |  Haultain
Q22603397  |  MODvalue  |  name_sv     |  Haultain River                            |  Haultain
Q7114861   |  MODvalue  |  name_en     |  Owl River                                 |  Owl
Q7114861   |  MODvalue  |  name_nl     |  Owl River                                 |  Owl
Q7114861   |  MODvalue  |  name_sv     |  Owl River                                 |  Owl
Q1840418   |  MODvalue  |  name_de     |  Firebag River                             |  Firebag
Q1840418   |  MODvalue  |  name_en     |  Firebag River                             |  Firebag
Q1840418   |  MODvalue  |  name_sv     |  Firebag River                             |  Firebag
Q15126104  |  MODvalue  |  name_de     |  Richardson River                          |  Richardson
Q15132109  |  MODvalue  |  name_de     |  Thoa River                                |  Thoa
Q15132109  |  MODvalue  |  name_en     |  Thoa River                                |  Thoa
Q15132109  |  MODvalue  |  name_nl     |  Thoa River                                |  Thoa
Q15132109  |  MODvalue  |  name_sv     |  Thoa River                                |  Thoa
Q15128716  |  MODvalue  |  name_de     |  Snare River                               |  Snare
Q11849694  |  MODvalue  |  name_de     |  Acasta River                              |  Acasta
Q11849694  |  MODvalue  |  name_en     |  Acasta River                              |  Acasta
Q11849694  |  MODvalue  |  name_sv     |  Acasta River                              |  Acasta
Q15124855  |  MODvalue  |  name_de     |  Pine River                                |  Pine
Q15124855  |  MODvalue  |  name_en     |  Pine River                                |  Pine
Q269551    |  MODvalue  |  name_de     |  Kiskatinaw River                          |  Kiskatinaw
Q269551    |  MODvalue  |  name_en     |  Kiskatinaw River                          |  Kiskatinaw
Q269551    |  MODvalue  |  name_sv     |  Kiskatinaw River                          |  Kiskatinaw
Q1336214   |  MODvalue  |  name_de     |  Wapiti River                              |  Wapiti
Q1336214   |  MODvalue  |  name_en     |  Wapiti River                              |  Wapiti
Q1336214   |  MODvalue  |  name_fr     |  Wapiti River                              |  Wapiti
Q1336214   |  NEWvalue  |  name_it     |                                            |  Wapiti
Q1336214   |  MODvalue  |  name_nl     |  Wapiti River                              |  Wapiti
Q1336214   |  NEWvalue  |  name_sv     |                                            |  Wapiti
Q22633098  |  MODvalue  |  name_sv     |  Murray River                              |  Murray
Q15130785  |  MODvalue  |  name_de     |  Sukunka River                             |  Sukunka
Q270479    |  MODvalue  |  name_de     |  Parsnip River                             |  Parsnip
Q270479    |  MODvalue  |  name_en     |  Parsnip River                             |  Parsnip
Q270479    |  MODvalue  |  name_fr     |  Parsnip River                             |  Parsnip
Q270479    |  MODvalue  |  name_nl     |  Parsnip River                             |  Parsnip
Q270479    |  MODvalue  |  name_sv     |  Parsnip River                             |  Parsnip
Q280542    |  MODvalue  |  name_de     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_en     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_fr     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_sv     |  Shuswap River                             |  Shuswap
Q351963    |  MODvalue  |  name_de     |  Adams River                               |  Adams
Q351963    |  MODvalue  |  name_en     |  Adams River                               |  Adams
Q351963    |  MODvalue  |  name_sv     |  Adams River                               |  Adams
Q268202    |  MODvalue  |  name_de     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_en     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_fr     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_nl     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_sv     |  Horsefly River                            |  Horsefly
Q6801464   |  MODvalue  |  name_de     |  McGregor River                            |  McGregor
Q6801464   |  MODvalue  |  name_en     |  McGregor River                            |  McGregor
Q6801464   |  MODvalue  |  name_sv     |  McGregor River                            |  McGregor
Q4951407   |  MODvalue  |  name_de     |  Bowron River                              |  Bowron
Q4951407   |  MODvalue  |  name_en     |  Bowron River                              |  Bowron
Q4951407   |  MODvalue  |  name_sv     |  Bowron River                              |  Bowron
Q5187841   |  MODvalue  |  name_de     |  Crooked River                             |  Crooked
Q5187841   |  MODvalue  |  name_en     |  Crooked River                             |  Crooked
Q5187841   |  MODvalue  |  name_sv     |  Crooked River                             |  Crooked
Q280019    |  MODvalue  |  name_de     |  Salmon River                              |  Salmon
Q280019    |  MODvalue  |  name_en     |  Salmon River                              |  Salmon
Q268952    |  MODvalue  |  name_de     |  Lillooet River                            |  Lillooet
Q268952    |  MODvalue  |  name_en     |  Lillooet River                            |  Lillooet
Q268952    |  MODvalue  |  name_nl     |  Lillooet River                            |  Lillooet
Q268952    |  MODvalue  |  name_sv     |  Lillooet River                            |  Lillooet
Q2663607   |  MODvalue  |  name_de     |  Bridge River                              |  Bridge
Q2663607   |  MODvalue  |  name_en     |  Bridge River                              |  Bridge
Q2663607   |  MODvalue  |  name_nl     |  Bridge River                              |  Bridge
Q2663607   |  MODvalue  |  name_sv     |  Bridge River                              |  Bridge
Q14874728  |  MODvalue  |  name_en     |  Nimpkish River                            |  Nimpkish
Q14874728  |  MODvalue  |  name_sv     |  Nimpkish River                            |  Nimpkish
Q265856    |  NEWvalue  |  name_de     |                                            |  Klinaklini
Q265856    |  MODvalue  |  name_en     |  Klinaklini River                          |  Klinaklini
Q265856    |  NEWvalue  |  name_fr     |                                            |  Klinaklini
Q265856    |  MODvalue  |  name_sv     |  Klinaklini River                          |  Klinaklini
Q14874714  |  MODvalue  |  name_en     |  Nazko River                               |  Nazko
Q14874714  |  MODvalue  |  name_sv     |  Nazko River                               |  Nazko
Q270961    |  MODvalue  |  name_de     |  Chilcotin River                           |  Chilcotin
Q270961    |  MODvalue  |  name_en     |  Chilcotin River                           |  Chilcotin
Q270961    |  MODvalue  |  name_nl     |  Chilcotin River                           |  Chilcotin
Q270961    |  MODvalue  |  name_sv     |  Chilcotin River                           |  Chilcotin
Q1250604   |  MODvalue  |  name_de     |  West Road River                           |  West Road
Q1250604   |  MODvalue  |  name_en     |  West Road River                           |  West Road
Q1250604   |  MODvalue  |  name_fr     |  West Road River                           |  West Road
Q1250604   |  MODvalue  |  name_nl     |  West Road River                           |  West Road
Q1250604   |  MODvalue  |  name_sv     |  West Road River                           |  West Road
Q267278    |  NEWvalue  |  name_de     |                                            |  Dean
Q267278    |  MODvalue  |  name_en     |  Dean River                                |  Dean
Q267278    |  NEWvalue  |  name_fr     |                                            |  Dean
Q267278    |  MODvalue  |  name_sv     |  Dean River                                |  Dean
Q265803    |  MODvalue  |  name_de     |  Muskwa River                              |  Muskwa
Q265803    |  MODvalue  |  name_en     |  Muskwa River                              |  Muskwa
Q265803    |  MODvalue  |  name_sv     |  Muskwa River                              |  Muskwa
Q4877304   |  MODvalue  |  name_de     |  Beatton River                             |  Beatton
Q4877304   |  MODvalue  |  name_en     |  Beatton River                             |  Beatton
Q4877304   |  MODvalue  |  name_sv     |  Beatton River                             |  Beatton
Q269567    |  MODvalue  |  name_de     |  Halfway River                             |  Halfway
Q269567    |  MODvalue  |  name_en     |  Halfway River                             |  Halfway
Q269567    |  MODvalue  |  name_sv     |  Halfway River                             |  Halfway
Q280106    |  MODvalue  |  name_de     |  Sikanni Chief River                       |  Sikanni Chief
Q280106    |  MODvalue  |  name_en     |  Sikanni Chief River                       |  Sikanni Chief
Q280106    |  MODvalue  |  name_sv     |  Sikanni Chief River                       |  Sikanni Chief
Q270412    |  MODvalue  |  name_de     |  Ospika River                              |  Ospika
Q270412    |  MODvalue  |  name_en     |  Ospika River                              |  Ospika
Q270412    |  MODvalue  |  name_sv     |  Ospika River                              |  Ospika
Q260158    |  MODvalue  |  name_de     |  Prophet River                             |  Prophet
Q260158    |  MODvalue  |  name_en     |  Prophet River                             |  Prophet
Q260158    |  MODvalue  |  name_sv     |  Prophet River                             |  Prophet
Q15117850  |  MODvalue  |  name_de     |  Kwadacha River                            |  Kwadacha
Q15117850  |  MODvalue  |  name_en     |  Kwadacha River                            |  Kwadacha
Q15117850  |  MODvalue  |  name_sv     |  Kwadacha River                            |  Kwadacha
Q270894    |  MODvalue  |  name_de     |  Omineca River                             |  Omineca
Q270894    |  MODvalue  |  name_en     |  Omineca River                             |  Omineca
Q270894    |  MODvalue  |  name_sv     |  Omineca River                             |  Omineca
Q15120122  |  MODvalue  |  name_de     |  Mesilinka River                           |  Mesilinka
Q15120122  |  MODvalue  |  name_en     |  Mesilinka River                           |  Mesilinka
Q15120122  |  MODvalue  |  name_sv     |  Mesilinka River                           |  Mesilinka
Q15115530  |  MODvalue  |  name_de     |  Ingenika River                            |  Ingenika
Q15115530  |  MODvalue  |  name_en     |  Ingenika River                            |  Ingenika
Q15115530  |  MODvalue  |  name_sv     |  Ingenika River                            |  Ingenika
Q7649744   |  MODvalue  |  name_de     |  Sustut River                              |  Sustut
Q7649744   |  MODvalue  |  name_en     |  Sustut River                              |  Sustut
Q7649744   |  MODvalue  |  name_sv     |  Sustut River                              |  Sustut
Q270955    |  MODvalue  |  name_de     |  Bulkley River                             |  Bulkley
Q270955    |  MODvalue  |  name_en     |  Bulkley River                             |  Bulkley
Q270955    |  MODvalue  |  name_sv     |  Bulkley River                             |  Bulkley
Q8075927   |  MODvalue  |  name_en     |  Zymoetz River                             |  Zymoetz
Q8075927   |  MODvalue  |  name_sv     |  Zymoetz River                             |  Zymoetz
Q270409    |  MODvalue  |  name_de     |  Kitimat River                             |  Kitimat
Q270409    |  MODvalue  |  name_en     |  Kitimat River                             |  Kitimat
Q270409    |  MODvalue  |  name_sv     |  Kitimat River                             |  Kitimat
Q15107466  |  MODvalue  |  name_de     |  Bell-Irving River                         |  Bell-Irving
Q15107466  |  MODvalue  |  name_en     |  Bell-Irving River                         |  Bell-Irving
Q15107466  |  MODvalue  |  name_sv     |  Bell-Irving River                         |  Bell-Irving
Q268666    |  MODvalue  |  name_de     |  Nass River                                |  Nass
Q268666    |  MODvalue  |  name_en     |  Nass River                                |  Nass
Q268666    |  MODvalue  |  name_nl     |  Nass River                                |  Nass
Q268666    |  MODvalue  |  name_sv     |  Nass River                                |  Nass
Q644607    |  MODvalue  |  name_de     |  Unuk River                                |  Unuk
Q644607    |  MODvalue  |  name_en     |  Unuk River                                |  Unuk
Q644607    |  MODvalue  |  name_nl     |  Unuk River                                |  Unuk
Q270502    |  MODvalue  |  name_de     |  Inklin River                              |  Inklin
Q270502    |  MODvalue  |  name_en     |  Inklin River                              |  Inklin
Q270502    |  MODvalue  |  name_sv     |  Inklin River                              |  Inklin
Q4931473   |  MODvalue  |  name_en     |  Boas River                                |  Boas
Q4931473   |  MODvalue  |  name_sv     |  Boas River                                |  Boas
Q22461897  |  MODvalue  |  name_en     |  Aua River                                 |  Aua
Q22461897  |  MODvalue  |  name_nl     |  Aua River                                 |  Aua
Q22461897  |  MODvalue  |  name_sv     |  Aua River                                 |  Aua
Q22420001  |  MODvalue  |  name_en     |  Kingora River                             |  Kingora
Q22420001  |  MODvalue  |  name_nl     |  Kingora River                             |  Kingora
Q22420001  |  MODvalue  |  name_sv     |  Kingora River                             |  Kingora
Q1627362   |  MODvalue  |  name_de     |  Hood River                                |  Hood
Q1627362   |  MODvalue  |  name_en     |  Hood River                                |  Hood
Q1627362   |  NEWvalue  |  name_ru     |                                            |  Худ
Q1627362   |  MODvalue  |  name_sv     |  Hood River                                |  Hood
Q22417975  |  MODvalue  |  name_en     |  Angimajuq River                           |  Angimajuq
Q22417975  |  MODvalue  |  name_nl     |  Angimajuq River                           |  Angimajuq
Q22417975  |  MODvalue  |  name_sv     |  Angimajuq River                           |  Angimajuq
Q22562651  |  MODvalue  |  name_sv     |  Kuugaarjuk River                          |  Kuugaarjuk
Q1332140   |  MODvalue  |  name_de     |  Ellice River                              |  Ellice
Q1332140   |  MODvalue  |  name_en     |  Ellice River                              |  Ellice
Q1332140   |  MODvalue  |  name_nl     |  Ellice River                              |  Ellice
Q1332140   |  MODvalue  |  name_sv     |  Ellice River                              |  Ellice
Q16247890  |  MODvalue  |  name_en     |  Kaleet River                              |  Kaleet
Q16247890  |  MODvalue  |  name_sv     |  Kaleet River                              |  Kaleet
Q1591919   |  MODvalue  |  name_de     |  Hayes River                               |  Hayes
Q1591919   |  MODvalue  |  name_en     |  Hayes River                               |  Hayes
Q1591919   |  MODvalue  |  name_de     |  Hayes River                               |  Hayes
Q1591919   |  MODvalue  |  name_en     |  Hayes River                               |  Hayes
Q22454334  |  MODvalue  |  name_en     |  Arrowsmith River                          |  Arrowsmith
Q22454334  |  MODvalue  |  name_nl     |  Arrowsmith River                          |  Arrowsmith
Q22454334  |  MODvalue  |  name_sv     |  Arrowsmith River                          |  Arrowsmith
Q22630419  |  MODvalue  |  name_en     |  Murchison River                           |  Murchison
Q22630419  |  MODvalue  |  name_nl     |  Murchison River                           |  Murchison
Q22630419  |  MODvalue  |  name_sv     |  Murchison River                           |  Murchison
Q22659451  |  MODvalue  |  name_en     |  Lord Lindsay River                        |  Lord Lindsay
Q22659451  |  MODvalue  |  name_nl     |  Lord Lindsay River                        |  Lord Lindsay
Q22659451  |  MODvalue  |  name_sv     |  Lord Lindsay River                        |  Lord Lindsay
Q22562704  |  MODvalue  |  name_sv     |  Kuujjua River                             |  Kuujjua
Q22562731  |  MODvalue  |  name_sv     |  Kuuk River                                |  Kuuk
Q22562704  |  MODvalue  |  name_sv     |  Kuujjua River                             |  Kuujjua
Q1571301   |  MODvalue  |  name_de     |  Soper River                               |  Soper
Q1571301   |  MODvalue  |  name_en     |  Soper River                               |  Soper
Q1571301   |  MODvalue  |  name_nl     |  Soper River                               |  Soper
Q1571301   |  MODvalue  |  name_sv     |  Soper River                               |  Soper
Q22596300  |  MODvalue  |  name_en     |  Hantzsch River                            |  Hantzsch
Q22596300  |  MODvalue  |  name_nl     |  Hantzsch River                            |  Hantzsch
Q22596300  |  MODvalue  |  name_sv     |  Hantzsch River                            |  Hantzsch
Q22461479  |  MODvalue  |  name_en     |  Isortoq River                             |  Isortoq
Q22461479  |  MODvalue  |  name_nl     |  Isortoq River                             |  Isortoq
Q22461479  |  MODvalue  |  name_sv     |  Isortoq River                             |  Isortoq
Q22641244  |  MODvalue  |  name_en     |  Gifford River                             |  Gifford
Q22641244  |  MODvalue  |  name_nl     |  Gifford River                             |  Gifford
Q22641244  |  MODvalue  |  name_sv     |  Gifford River                             |  Gifford
Q22491462  |  MODvalue  |  name_en     |  Jungersen River                           |  Jungersen
Q22491462  |  MODvalue  |  name_nl     |  Jungersen River                           |  Jungersen
Q22491462  |  MODvalue  |  name_sv     |  Jungersen River                           |  Jungersen
Q22641244  |  MODvalue  |  name_en     |  Gifford River                             |  Gifford
Q22641244  |  MODvalue  |  name_nl     |  Gifford River                             |  Gifford
Q22641244  |  MODvalue  |  name_sv     |  Gifford River                             |  Gifford
Q22584057  |  MODvalue  |  name_en     |  Haakon River                              |  Haakon
Q22584057  |  MODvalue  |  name_nl     |  Haakon River                              |  Haakon
Q22584057  |  MODvalue  |  name_sv     |  Haakon River                              |  Haakon
Q7795847   |  MODvalue  |  name_en     |  Thomsen River                             |  Thomsen
Q859175    |  MODvalue  |  name_de     |  Big River                                 |  Big
Q859175    |  MODvalue  |  name_en     |  Big River                                 |  Big
Q22563404  |  MODvalue  |  name_en     |  Davies River                              |  Davies
Q22563404  |  MODvalue  |  name_nl     |  Davies River                              |  Davies
Q22563404  |  MODvalue  |  name_sv     |  Davies River                              |  Davies
Q15109230  |  MODvalue  |  name_de     |  Dease River                               |  Dease
Q7281929   |  MODvalue  |  name_de     |  Rae River                                 |  Rae
Q7281929   |  MODvalue  |  name_en     |  Rae River                                 |  Rae
Q7281929   |  MODvalue  |  name_sv     |  Rae River                                 |  Rae
Q7281929   |  MODvalue  |  name_de     |  Rae River                                 |  Rae
Q7281929   |  MODvalue  |  name_en     |  Rae River                                 |  Rae
Q7281929   |  MODvalue  |  name_sv     |  Rae River                                 |  Rae
Q7367525   |  MODvalue  |  name_de     |  Roscoe River                              |  Roscoe
Q7367525   |  MODvalue  |  name_en     |  Roscoe River                              |  Roscoe
Q16209683  |  MODvalue  |  name_en     |  Bloody River                              |  Bloody
Q16209683  |  MODvalue  |  name_sv     |  Bloody River                              |  Bloody
Q15112077  |  MODvalue  |  name_de     |  Haldane River                             |  Haldane
Q15112077  |  MODvalue  |  name_en     |  Haldane River                             |  Haldane
Q15112077  |  MODvalue  |  name_nl     |  Haldane River                             |  Haldane
Q15112077  |  MODvalue  |  name_sv     |  Haldane River                             |  Haldane
Q1162665   |  MODvalue  |  name_de     |  Horton River                              |  Horton
Q1162665   |  MODvalue  |  name_en     |  Horton River                              |  Horton
Q1162665   |  MODvalue  |  name_fr     |  Horton River                              |  Horton
Q1162665   |  MODvalue  |  name_nl     |  Horton River                              |  Horton
Q1162665   |  MODvalue  |  name_pl     |  Horton River                              |  Horton
Q859207    |  MODvalue  |  name_de     |  Big Salmon River                          |  Big Salmon
Q859207    |  MODvalue  |  name_en     |  Big Salmon River                          |  Big Salmon
Q859207    |  MODvalue  |  name_pl     |  Big Salmon River                          |  Big Salmon
Q2372735   |  MODvalue  |  name_de     |  Swift River                               |  Swift
Q2372735   |  MODvalue  |  name_en     |  Swift River                               |  Swift
Q2372735   |  MODvalue  |  name_nl     |  Swift River                               |  Swift
Q2372735   |  MODvalue  |  name_sv     |  Swift River                               |  Swift
Q7290792   |  MODvalue  |  name_de     |  Rancheria River                           |  Rancheria
Q7290792   |  MODvalue  |  name_en     |  Rancheria River                           |  Rancheria
Q7290792   |  MODvalue  |  name_sv     |  Rancheria River                           |  Rancheria
Q269983    |  MODvalue  |  name_en     |  Little Rancheria River                    |  Little Rancheria
Q269983    |  MODvalue  |  name_sv     |  Little Rancheria River                    |  Little Rancheria
Q270283    |  MODvalue  |  name_de     |  Dease River                               |  Dease
Q270283    |  MODvalue  |  name_en     |  Dease River                               |  Dease
Q270283    |  MODvalue  |  name_sv     |  Dease River                               |  Dease
Q7855807   |  MODvalue  |  name_de     |  Turnagain River                           |  Turnagain
Q7855807   |  MODvalue  |  name_en     |  Turnagain River                           |  Turnagain
Q7855807   |  MODvalue  |  name_sv     |  Turnagain River                           |  Turnagain
Q268222    |  MODvalue  |  name_de     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_en     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_fr     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_nl     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_sv     |  Kechika River                             |  Kechika
Q4878156   |  MODvalue  |  name_de     |  Beaver River                              |  Beaver
Q4878156   |  MODvalue  |  name_en     |  Beaver River                              |  Beaver
Q4878156   |  MODvalue  |  name_sv     |  Beaver River                              |  Beaver
Q7545292   |  MODvalue  |  name_de     |  Smith River                               |  Smith
Q7545292   |  MODvalue  |  name_en     |  Smith River                               |  Smith
Q7545292   |  MODvalue  |  name_sv     |  Smith River                               |  Smith
Q270423    |  MODvalue  |  name_de     |  Gataga River                              |  Gataga
Q270423    |  MODvalue  |  name_en     |  Gataga River                              |  Gataga
Q270423    |  MODvalue  |  name_sv     |  Gataga River                              |  Gataga
Q15125737  |  MODvalue  |  name_de     |  Rabbit River                              |  Rabbit
Q15125737  |  MODvalue  |  name_en     |  Rabbit River                              |  Rabbit
Q2437592   |  MODvalue  |  name_de     |  Toad River                                |  Toad
Q2437592   |  MODvalue  |  name_en     |  Toad River                                |  Toad
Q2437592   |  MODvalue  |  name_fr     |  Toad River                                |  Toad
Q2437592   |  MODvalue  |  name_sv     |  Toad River                                |  Toad
Q22604623  |  MODvalue  |  name_en     |  Dunedin River                             |  Dunedin
Q22604623  |  MODvalue  |  name_nl     |  Dunedin River                             |  Dunedin
Q22604623  |  MODvalue  |  name_sv     |  Dunedin River                             |  Dunedin
Q22503588  |  MODvalue  |  name_en     |  Kahntah River                             |  Kahntah
Q22503588  |  MODvalue  |  name_nl     |  Kahntah River                             |  Kahntah
Q22503588  |  MODvalue  |  name_sv     |  Kahntah River                             |  Kahntah
Q266899    |  MODvalue  |  name_de     |  Fontas River                              |  Fontas
Q266899    |  MODvalue  |  name_en     |  Fontas River                              |  Fontas
Q266899    |  MODvalue  |  name_sv     |  Fontas River                              |  Fontas
Q5100295   |  MODvalue  |  name_en     |  Chinchaga River                           |  Chinchaga
Q5100295   |  MODvalue  |  name_sv     |  Chinchaga River                           |  Chinchaga
Q7063039   |  MODvalue  |  name_en     |  Notikewin River                           |  Notikewin
Q7063039   |  MODvalue  |  name_nl     |  Notikewin River                           |  Notikewin
Q7063039   |  MODvalue  |  name_sv     |  Notikewin River                           |  Notikewin
Q22607981  |  MODvalue  |  name_sv     |  Hay River                                 |  Hay
Q270571    |  MODvalue  |  name_de     |  Petitot River                             |  Petitot
Q270571    |  MODvalue  |  name_en     |  Petitot River                             |  Petitot
Q270571    |  MODvalue  |  name_nl     |  Petitot River                             |  Petitot
Q270571    |  MODvalue  |  name_sv     |  Petitot River                             |  Petitot
Q22635897  |  MODvalue  |  name_sv     |  Muskeg River                              |  Muskeg
Q6349481   |  MODvalue  |  name_de     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_en     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_sv     |  Kakisa River                              |  Kakisa
Q15107756  |  MODvalue  |  name_de     |  Blackwater River                          |  Blackwater
Q15107756  |  MODvalue  |  name_en     |  Blackwater River                          |  Blackwater
Q22566721  |  MODvalue  |  name_sv     |  La Biche River                            |  La Biche
Q15126341  |  MODvalue  |  name_de     |  Root River                                |  Root
Q15126341  |  MODvalue  |  name_en     |  Root River                                |  Root
Q15126341  |  MODvalue  |  name_nl     |  Root River                                |  Root
Q15126341  |  MODvalue  |  name_sv     |  Root River                                |  Root
Q3439      |  MODvalue  |  name_de     |  North Nahanni River                       |  North Nahanni
Q3439      |  MODvalue  |  name_en     |  North Nahanni River                       |  North Nahanni
Q3439      |  MODvalue  |  name_it     |  North Nahanni River                       |  North Nahanni
Q3439      |  MODvalue  |  name_nl     |  North Nahanni River                       |  North Nahanni
Q3439      |  NEWvalue  |  name_ru     |                                            |  Норт-На­хан­ни
Q3439      |  MODvalue  |  name_sv     |  North Nahanni River                       |  North Nahanni
Q14658488  |  MODvalue  |  name_de     |  Whitefish River                           |  Whitefish
Q14658488  |  MODvalue  |  name_en     |  Whitefish River                           |  Whitefish
Q15108615  |  MODvalue  |  name_de     |  Carcajou River                            |  Carcajou
Q15108615  |  MODvalue  |  name_en     |  Carcajou River                            |  Carcajou
Q15108615  |  MODvalue  |  name_nl     |  Carcajou River                            |  Carcajou
Q15108615  |  MODvalue  |  name_sv     |  Carcajou River                            |  Carcajou
Q22517624  |  MODvalue  |  name_nl     |  Miner River                               |  Miner
Q22517624  |  MODvalue  |  name_sv     |  Miner River                               |  Miner
Q15108615  |  MODvalue  |  name_de     |  Carcajou River                            |  Carcajou
Q15108615  |  MODvalue  |  name_en     |  Carcajou River                            |  Carcajou
Q15108615  |  MODvalue  |  name_nl     |  Carcajou River                            |  Carcajou
Q15108615  |  MODvalue  |  name_sv     |  Carcajou River                            |  Carcajou
Q268335    |  MODvalue  |  name_de     |  Coal River                                |  Coal
Q268335    |  MODvalue  |  name_en     |  Coal River                                |  Coal
Q268335    |  MODvalue  |  name_sv     |  Coal River                                |  Coal
Q15110758  |  MODvalue  |  name_de     |  Flat River                                |  Flat
Q15115326  |  MODvalue  |  name_de     |  Hyland River                              |  Hyland
Q15115326  |  MODvalue  |  name_en     |  Hyland River                              |  Hyland
Q15115326  |  MODvalue  |  name_sv     |  Hyland River                              |  Hyland
Q1898456   |  MODvalue  |  name_de     |  Pelly River                               |  Pelly
Q1898456   |  MODvalue  |  name_en     |  Pelly River                               |  Pelly
Q1898456   |  MODvalue  |  name_nl     |  Pelly River                               |  Pelly
Q1898456   |  MODvalue  |  name_pl     |  Pelly River                               |  Pelly
Q1898456   |  MODvalue  |  name_sv     |  Pelly River                               |  Pelly
Q3452      |  MODvalue  |  name_de     |  Redstone River                            |  Redstone
Q3452      |  MODvalue  |  name_en     |  Redstone River                            |  Redstone
Q3452      |  MODvalue  |  name_fr     |  Redstone River                            |  Redstone
Q3452      |  MODvalue  |  name_nl     |  Redstone River                            |  Redstone
Q3452      |  NEWvalue  |  name_ru     |                                            |  Ред­стон
Q1278909   |  MODvalue  |  name_de     |  Ross River                                |  Ross
Q1278909   |  MODvalue  |  name_en     |  Ross River                                |  Ross
Q1278909   |  MODvalue  |  name_nl     |  Ross River                                |  Ross
Q1278909   |  MODvalue  |  name_sv     |  Ross River                                |  Ross
Q15114758  |  MODvalue  |  name_de     |  Hess River                                |  Hess
Q15114758  |  MODvalue  |  name_en     |  Hess River                                |  Hess
Q15114758  |  MODvalue  |  name_nl     |  Hess River                                |  Hess
Q15114758  |  MODvalue  |  name_sv     |  Hess River                                |  Hess
Q7547066   |  MODvalue  |  name_de     |  Snake River                               |  Snake
Q7547066   |  MODvalue  |  name_en     |  Snake River                               |  Snake
Q7547066   |  MODvalue  |  name_sv     |  Snake River                               |  Snake
Q892784    |  MODvalue  |  name_de     |  Bonnet Plume River                        |  Bonnet Plume
Q892784    |  MODvalue  |  name_en     |  Bonnet Plume River                        |  Bonnet Plume
Q892784    |  MODvalue  |  name_sv     |  Bonnet Plume River                        |  Bonnet Plume
Q2583410   |  MODvalue  |  name_de     |  Wind River                                |  Wind
Q2583410   |  MODvalue  |  name_en     |  Wind River                                |  Wind
Q2583410   |  MODvalue  |  name_sv     |  Wind River                                |  Wind
Q4878160   |  MODvalue  |  name_en     |  Beaver River                              |  Beaver
Q15112165  |  MODvalue  |  name_de     |  Hart River                                |  Hart
Q15112165  |  MODvalue  |  name_en     |  Hart River                                |  Hart
Q15112165  |  MODvalue  |  name_nl     |  Hart River                                |  Hart
Q15112165  |  MODvalue  |  name_sv     |  Hart River                                |  Hart
Q4088437   |  MODvalue  |  name_de     |  Blackstone River                          |  Blackstone
Q45910906  |  MODvalue  |  name_de     |  Hoholitna River                           |  Hoholitna
Q45910906  |  MODvalue  |  name_en     |  Hoholitna River                           |  Hoholitna
Q286340    |  MODvalue  |  name_de     |  Klondike River                            |  Klondike
Q286340    |  MODvalue  |  name_en     |  Klondike River                            |  Klondike
Q286340    |  MODvalue  |  name_nl     |  Klondike River                            |  Klondike
Q15110020  |  MODvalue  |  name_de     |  Eagle River                               |  Eagle
Q15110020  |  MODvalue  |  name_en     |  Eagle River                               |  Eagle
Q15107467  |  MODvalue  |  name_de     |  Bell River                                |  Bell
Q15107467  |  MODvalue  |  name_en     |  Bell River                                |  Bell
Q22467918  |  MODvalue  |  name_en     |  Babbage River                             |  Babbage
Q22467918  |  MODvalue  |  name_nl     |  Babbage River                             |  Babbage
Q22467918  |  MODvalue  |  name_sv     |  Babbage River                             |  Babbage
Q1419623   |  MODvalue  |  name_de     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_en     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_nl     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_sv     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_de     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_en     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_nl     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_sv     |  Firth River                               |  Firth
Q3198650   |  MODvalue  |  name_en     |  Kongakut River                            |  Kongakut
Q3198650   |  MODvalue  |  name_nl     |  Kongakut River                            |  Kongakut
Q1108030   |  MODvalue  |  name_de     |  Coleen River                              |  Coleen
Q1108030   |  MODvalue  |  name_en     |  Coleen River                              |  Coleen
Q1108030   |  MODvalue  |  name_nl     |  Coleen River                              |  Coleen
Q2277693   |  MODvalue  |  name_de     |  Sheenjek River                            |  Sheenjek
Q2277693   |  MODvalue  |  name_en     |  Sheenjek River                            |  Sheenjek
Q2277693   |  MODvalue  |  name_nl     |  Sheenjek River                            |  Sheenjek
Q15134861  |  MODvalue  |  name_de     |  Whitestone River                          |  Whitestone
Q15134861  |  MODvalue  |  name_en     |  Whitestone River                          |  Whitestone
Q1066756   |  MODvalue  |  name_de     |  Charley River                             |  Charley
Q1066756   |  MODvalue  |  name_en     |  Charley River                             |  Charley
Q1066756   |  MODvalue  |  name_nl     |  Charley River                             |  Charley
Q574703    |  MODvalue  |  name_de     |  Wind River                                |  Wind
Q574703    |  MODvalue  |  name_en     |  Wind River                                |  Wind
Q574703    |  MODvalue  |  name_nl     |  Wind River                                |  Wind
Q271001    |  MODvalue  |  name_de     |  Chilkat River                             |  Chilkat
Q271001    |  MODvalue  |  name_en     |  Chilkat River                             |  Chilkat
Q271001    |  MODvalue  |  name_nl     |  Chilkat River                             |  Chilkat
Q271001    |  MODvalue  |  name_sv     |  Chilkat River                             |  Chilkat
Q23016     |  MODvalue  |  name_de     |  Tatshenshini River                        |  Tatshenshini
Q23016     |  MODvalue  |  name_en     |  Tatshenshini River                        |  Tatshenshini
Q23016     |  MODvalue  |  name_sv     |  Tatshenshini River                        |  Tatshenshini
Q1074901   |  MODvalue  |  name_de     |  Chitina River                             |  Chitina
Q1074901   |  MODvalue  |  name_en     |  Chitina River                             |  Chitina
Q1074901   |  MODvalue  |  name_nl     |  Chitina River                             |  Chitina
Q1961991   |  MODvalue  |  name_de     |  Nabesna River                             |  Nabesna
Q1961991   |  MODvalue  |  name_en     |  Nabesna River                             |  Nabesna
Q1961991   |  MODvalue  |  name_nl     |  Nabesna River                             |  Nabesna
Q1622755   |  MODvalue  |  name_de     |  Hodzana River                             |  Hodzana
Q1622755   |  MODvalue  |  name_en     |  Hodzana River                             |  Hodzana
Q1622755   |  MODvalue  |  name_nl     |  Hodzana River                             |  Hodzana
Q930455    |  MODvalue  |  name_de     |  Ivishak River                             |  Ivishak
Q930455    |  MODvalue  |  name_en     |  Ivishak River                             |  Ivishak
Q930455    |  MODvalue  |  name_nl     |  Ivishak River                             |  Ivishak
Q3200508   |  MODvalue  |  name_en     |  Kuparuk River                             |  Kuparuk
Q3200508   |  MODvalue  |  name_nl     |  Kuparuk River                             |  Kuparuk
Q1675300   |  MODvalue  |  name_de     |  Itkillik River                            |  Itkillik
Q1675300   |  MODvalue  |  name_en     |  Itkillik River                            |  Itkillik
Q1675300   |  MODvalue  |  name_nl     |  Itkillik River                            |  Itkillik
Q1675300   |  MODvalue  |  name_de     |  Itkillik River                            |  Itkillik
Q1675300   |  MODvalue  |  name_en     |  Itkillik River                            |  Itkillik
Q1675300   |  MODvalue  |  name_nl     |  Itkillik River                            |  Itkillik
Q484545    |  MODvalue  |  name_de     |  Anaktuvuk River                           |  Anaktuvuk
Q484545    |  MODvalue  |  name_en     |  Anaktuvuk River                           |  Anaktuvuk
Q484545    |  MODvalue  |  name_nl     |  Anaktuvuk River                           |  Anaktuvuk
Q16895078  |  MODvalue  |  name_en     |  Middle Fork Koyukuk River                 |  Middle Fork Koyukuk
Q1061725   |  MODvalue  |  name_de     |  Chandler River                            |  Chandler
Q1061725   |  MODvalue  |  name_en     |  Chandler River                            |  Chandler
Q932937    |  MODvalue  |  name_de     |  John River                                |  John
Q932937    |  MODvalue  |  name_en     |  John River                                |  John
Q932937    |  MODvalue  |  name_nl     |  John River                                |  John
Q968950    |  MODvalue  |  name_de     |  Killik River                              |  Killik
Q968950    |  MODvalue  |  name_en     |  Killik River                              |  Killik
Q968950    |  MODvalue  |  name_nl     |  Killik River                              |  Killik
Q826196    |  MODvalue  |  name_de     |  Alatna River                              |  Alatna
Q826196    |  MODvalue  |  name_en     |  Alatna River                              |  Alatna
Q826196    |  MODvalue  |  name_nl     |  Alatna River                              |  Alatna
Q1184924   |  MODvalue  |  name_de     |  Delta River                               |  Delta
Q1184924   |  MODvalue  |  name_en     |  Delta River                               |  Delta
Q3110723   |  MODvalue  |  name_en     |  Goodpaster River                          |  Goodpaster
Q3469654   |  MODvalue  |  name_de     |  Salcha River                              |  Salcha
Q3469654   |  MODvalue  |  name_en     |  Salcha River                              |  Salcha
Q2961511   |  MODvalue  |  name_de     |  Chatanika River                           |  Chatanika
Q2961511   |  MODvalue  |  name_en     |  Chatanika River                           |  Chatanika
Q2961511   |  MODvalue  |  name_nl     |  Chatanika River                           |  Chatanika
Q1670844   |  MODvalue  |  name_de     |  Teklanika River                           |  Teklanika
Q1670844   |  MODvalue  |  name_en     |  Teklanika River                           |  Teklanika
Q1977371   |  MODvalue  |  name_de     |  Nenana River                              |  Nenana
Q1977371   |  MODvalue  |  name_en     |  Nenana River                              |  Nenana
Q1977371   |  MODvalue  |  name_nl     |  Nenana River                              |  Nenana
Q1468104   |  MODvalue  |  name_de     |  Matanuska River                           |  Matanuska
Q1468104   |  MODvalue  |  name_en     |  Matanuska River                           |  Matanuska
Q1468104   |  MODvalue  |  name_nl     |  Matanuska River                           |  Matanuska
Q1321280   |  MODvalue  |  name_de     |  Talkeetna River                           |  Talkeetna
Q1321280   |  MODvalue  |  name_en     |  Talkeetna River                           |  Talkeetna
Q1089418   |  MODvalue  |  name_de     |  Chulitna River                            |  Chulitna
Q1089418   |  MODvalue  |  name_en     |  Chulitna River                            |  Chulitna
Q3486413   |  MODvalue  |  name_de     |  Skwentna River                            |  Skwentna
Q3486413   |  MODvalue  |  name_en     |  Skwentna River                            |  Skwentna
Q2947733   |  MODvalue  |  name_de     |  Chakachatna River                         |  Chakachatna
Q2947733   |  MODvalue  |  name_en     |  Chakachatna River                         |  Chakachatna
Q2947733   |  MODvalue  |  name_nl     |  Chakachatna River                         |  Chakachatna
Q546105    |  MODvalue  |  name_de     |  Aniakchak River                           |  Aniakchak
Q546105    |  MODvalue  |  name_en     |  Aniakchak River                           |  Aniakchak
Q859175    |  MODvalue  |  name_de     |  Big River                                 |  Big
Q859175    |  MODvalue  |  name_en     |  Big River                                 |  Big
Q1370855   |  MODvalue  |  name_de     |  Stony River                               |  Stony
Q1370855   |  MODvalue  |  name_en     |  Stony River                               |  Stony
Q1293534   |  MODvalue  |  name_de     |  Mulchatna River                           |  Mulchatna
Q1293534   |  MODvalue  |  name_en     |  Mulchatna River                           |  Mulchatna
Q1293534   |  MODvalue  |  name_nl     |  Mulchatna River                           |  Mulchatna
Q1072928   |  MODvalue  |  name_de     |  Chilikadrotna River                       |  Chilikadrotna
Q1072928   |  MODvalue  |  name_en     |  Chilikadrotna River                       |  Chilikadrotna
Q1072928   |  MODvalue  |  name_nl     |  Chilikadrotna River                       |  Chilikadrotna
Q2005508   |  MODvalue  |  name_de     |  Nushagak River                            |  Nushagak
Q2005508   |  MODvalue  |  name_en     |  Nushagak River                            |  Nushagak
Q2005508   |  MODvalue  |  name_nl     |  Nushagak River                            |  Nushagak
Q3198421   |  MODvalue  |  name_en     |  Kokwok River                              |  Kokwok
Q667197    |  MODvalue  |  name_de     |  Swift River                               |  Swift
Q667197    |  MODvalue  |  name_en     |  Swift River                               |  Swift
Q667197    |  MODvalue  |  name_nl     |  Swift River                               |  Swift
Q1624702   |  MODvalue  |  name_de     |  Holitna River                             |  Holitna
Q1624702   |  MODvalue  |  name_en     |  Holitna River                             |  Holitna
Q1624702   |  MODvalue  |  name_nl     |  Holitna River                             |  Holitna
Q1656844   |  MODvalue  |  name_de     |  Iditarod River                            |  Iditarod
Q1656844   |  MODvalue  |  name_en     |  Iditarod River                            |  Iditarod
Q1656844   |  MODvalue  |  name_nl     |  Iditarod River                            |  Iditarod
Q3030256   |  MODvalue  |  name_de     |  Dishna River                              |  Dishna
Q3030256   |  MODvalue  |  name_en     |  Dishna River                              |  Dishna
Q1664161   |  MODvalue  |  name_de     |  Innoko River                              |  Innoko
Q1664161   |  MODvalue  |  name_en     |  Innoko River                              |  Innoko
Q1664161   |  MODvalue  |  name_nl     |  Innoko River                              |  Innoko
Q1430047   |  MODvalue  |  name_de     |  Nowitna River                             |  Nowitna
Q1430047   |  MODvalue  |  name_en     |  Nowitna River                             |  Nowitna
Q1430047   |  MODvalue  |  name_nl     |  Nowitna River                             |  Nowitna
Q1919701   |  MODvalue  |  name_de     |  Melozitna River                           |  Melozitna
Q1919701   |  MODvalue  |  name_en     |  Melozitna River                           |  Melozitna
Q1919701   |  MODvalue  |  name_nl     |  Melozitna River                           |  Melozitna
Q1623353   |  MODvalue  |  name_de     |  Hogatza River                             |  Hogatza
Q1623353   |  MODvalue  |  name_en     |  Hogatza River                             |  Hogatza
Q1623353   |  MODvalue  |  name_nl     |  Hogatza River                             |  Hogatza
Q753980    |  MODvalue  |  name_de     |  Atchuelinguk River                        |  Atchuelinguk
Q753980    |  MODvalue  |  name_en     |  Atchuelinguk River                        |  Atchuelinguk
Q753980    |  MODvalue  |  name_nl     |  Atchuelinguk River                        |  Atchuelinguk
Q305100    |  MODvalue  |  name_de     |  Andreafsky River                          |  Andreafsky
Q305100    |  MODvalue  |  name_en     |  Andreafsky River                          |  Andreafsky
Q305100    |  MODvalue  |  name_nl     |  Andreafsky River                          |  Andreafsky
Q612981    |  MODvalue  |  name_de     |  Anvik River                               |  Anvik
Q612981    |  MODvalue  |  name_en     |  Anvik River                               |  Anvik
Q612981    |  MODvalue  |  name_nl     |  Anvik River                               |  Anvik
Q763999    |  MODvalue  |  name_de     |  Unalakleet River                          |  Unalakleet
Q763999    |  MODvalue  |  name_en     |  Unalakleet River                          |  Unalakleet
Q1131889   |  MODvalue  |  name_de     |  Togiak River                              |  Togiak
Q1131889   |  MODvalue  |  name_en     |  Togiak River                              |  Togiak
Q3192622   |  MODvalue  |  name_de     |  Kanektok River                            |  Kanektok
Q3192622   |  MODvalue  |  name_en     |  Kanektok River                            |  Kanektok
Q1794782   |  MODvalue  |  name_de     |  Kuzitrin River                            |  Kuzitrin
Q1794782   |  MODvalue  |  name_en     |  Kuzitrin River                            |  Kuzitrin
Q1794782   |  MODvalue  |  name_nl     |  Kuzitrin River                            |  Kuzitrin
Q3199429   |  MODvalue  |  name_en     |  Koyuk River                               |  Koyuk
Q3199429   |  MODvalue  |  name_nl     |  Koyuk River                               |  Koyuk
Q686347    |  MODvalue  |  name_de     |  Selawik River                             |  Selawik
Q686347    |  MODvalue  |  name_en     |  Selawik River                             |  Selawik
Q686347    |  MODvalue  |  name_nl     |  Selawik River                             |  Selawik
Q686347    |  MODvalue  |  name_de     |  Selawik River                             |  Selawik
Q686347    |  MODvalue  |  name_en     |  Selawik River                             |  Selawik
Q686347    |  MODvalue  |  name_nl     |  Selawik River                             |  Selawik
Q2315080   |  MODvalue  |  name_de     |  Squirrel River                            |  Squirrel
Q2315080   |  MODvalue  |  name_en     |  Squirrel River                            |  Squirrel
Q1517486   |  MODvalue  |  name_de     |  Noatak River                              |  Noatak
Q1517486   |  MODvalue  |  name_en     |  Noatak River                              |  Noatak
Q1517486   |  MODvalue  |  name_nl     |  Noatak River                              |  Noatak
Q1517486   |  MODvalue  |  name_de     |  Noatak River                              |  Noatak
Q1517486   |  MODvalue  |  name_en     |  Noatak River                              |  Noatak
Q1517486   |  MODvalue  |  name_nl     |  Noatak River                              |  Noatak
Q179117    |  MODvalue  |  name_de     |  Awuna River                               |  Awuna
Q179117    |  MODvalue  |  name_en     |  Awuna River                               |  Awuna
Q179117    |  MODvalue  |  name_nl     |  Awuna River                               |  Awuna
Q2873255   |  MODvalue  |  name_en     |  Avalik River                              |  Avalik
Q769397    |  MODvalue  |  name_en     |  Utukok River                              |  Utukok
Q769397    |  MODvalue  |  name_nl     |  Utukok River                              |  Utukok
Q769397    |  MODvalue  |  name_en     |  Utukok River                              |  Utukok
Q769397    |  MODvalue  |  name_nl     |  Utukok River                              |  Utukok
Q1778953   |  MODvalue  |  name_de     |  Kokolik River                             |  Kokolik
Q1778953   |  MODvalue  |  name_en     |  Kokolik River                             |  Kokolik
Q1778953   |  MODvalue  |  name_nl     |  Kokolik River                             |  Kokolik
Q1778953   |  MODvalue  |  name_de     |  Kokolik River                             |  Kokolik
Q1778953   |  MODvalue  |  name_en     |  Kokolik River                             |  Kokolik
Q1778953   |  MODvalue  |  name_nl     |  Kokolik River                             |  Kokolik
Q3200296   |  MODvalue  |  name_en     |  Kukpowruk River                           |  Kukpowruk
Q3200296   |  MODvalue  |  name_nl     |  Kukpowruk River                           |  Kukpowruk
Q3200296   |  MODvalue  |  name_en     |  Kukpowruk River                           |  Kukpowruk
Q3200296   |  MODvalue  |  name_nl     |  Kukpowruk River                           |  Kukpowruk
Q3200297   |  MODvalue  |  name_en     |  Kukpuk River                              |  Kukpuk
Q3200297   |  MODvalue  |  name_nl     |  Kukpuk River                              |  Kukpuk
Q217739    |  MODvalue  |  name_de     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_en     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_nl     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_pl     |  Milk River                                |  Milk
Q2408930   |  MODvalue  |  name_de     |  Thames River                              |  Thames
Q2408930   |  MODvalue  |  name_en     |  Thames River                              |  Thames
Q2408930   |  MODvalue  |  name_nl     |  Thames River                              |  Thames
Q2408930   |  MODvalue  |  name_sv     |  Thames River                              |  Thames
Q6737173   |  MODvalue  |  name_en     |  Maitland River                            |  Maitland
Q1400280   |  MODvalue  |  name_de     |  Saugeen River                             |  Saugeen
Q1400280   |  MODvalue  |  name_en     |  Saugeen River                             |  Saugeen
Q1400280   |  MODvalue  |  name_fr     |  Saugeen River                             |  Saugeen
Q1400280   |  MODvalue  |  name_nl     |  Saugeen River                             |  Saugeen
Q1400280   |  MODvalue  |  name_sv     |  Saugeen River                             |  Saugeen
Q175816    |  MODvalue  |  name_de     |  Trent River                               |  Trent
Q175816    |  MODvalue  |  name_en     |  Trent River                               |  Trent
Q175816    |  MODvalue  |  name_sv     |  Trent River                               |  Trent
Q1379758   |  MODvalue  |  name_de     |  Moira River                               |  Moira
Q1379758   |  MODvalue  |  name_en     |  Moira River                               |  Moira
Q1379758   |  MODvalue  |  name_fr     |  Moira River                               |  Moira
Q1379758   |  MODvalue  |  name_nl     |  Moira River                               |  Moira
Q1379758   |  MODvalue  |  name_sv     |  Moira River                               |  Moira
Q5617744   |  MODvalue  |  name_de     |  Gull River                                |  Gull
Q5617744   |  MODvalue  |  name_en     |  Gull River                                |  Gull
Q681048    |  MODvalue  |  name_de     |  Severn River                              |  Severn
Q681048    |  MODvalue  |  name_en     |  Severn River                              |  Severn
Q681048    |  MODvalue  |  name_nl     |  Severn River                              |  Severn
Q280507    |  MODvalue  |  name_en     |  Rideau River                              |  Rideau
Q280507    |  MODvalue  |  name_nl     |  Rideau River                              |  Rideau
Q280507    |  MODvalue  |  name_sv     |  Rideau River                              |  Rideau
Q1503538   |  MODvalue  |  name_de     |  Mississippi River                         |  Mississippi
Q1503538   |  MODvalue  |  name_en     |  Mississippi River                         |  Mississippi
Q1503538   |  MODvalue  |  name_nl     |  Mississippi River                         |  Mississippi
Q1503538   |  MODvalue  |  name_sv     |  Mississippi River                         |  Mississippi
Q1503538   |  MODvalue  |  name_de     |  Mississippi River                         |  Mississippi
Q1503538   |  MODvalue  |  name_en     |  Mississippi River                         |  Mississippi
Q1503538   |  MODvalue  |  name_nl     |  Mississippi River                         |  Mississippi
Q1503538   |  MODvalue  |  name_sv     |  Mississippi River                         |  Mississippi
Q280507    |  MODvalue  |  name_en     |  Rideau River                              |  Rideau
Q280507    |  MODvalue  |  name_nl     |  Rideau River                              |  Rideau
Q280507    |  MODvalue  |  name_sv     |  Rideau River                              |  Rideau
Q1884310   |  MODvalue  |  name_de     |  Magnetawan River                          |  Magnetawan
Q1884310   |  MODvalue  |  name_en     |  Magnetawan River                          |  Magnetawan
Q1884310   |  MODvalue  |  name_fr     |  Magnetawan River                          |  Magnetawan
Q1884310   |  MODvalue  |  name_nl     |  Magnetawan River                          |  Magnetawan
Q1884310   |  MODvalue  |  name_sv     |  Magnetawan River                          |  Magnetawan
Q1594722   |  MODvalue  |  name_de     |  Madawaska River                           |  Madawaska
Q1594722   |  MODvalue  |  name_en     |  Madawaska River                           |  Madawaska
Q1594722   |  MODvalue  |  name_nl     |  Madawaska River                           |  Madawaska
Q1594722   |  MODvalue  |  name_sv     |  Madawaska River                           |  Madawaska
Q1939154   |  MODvalue  |  name_de     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_en     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_nl     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_sv     |  Mississagi River                          |  Mississagi
Q1594722   |  MODvalue  |  name_de     |  Madawaska River                           |  Madawaska
Q1594722   |  MODvalue  |  name_en     |  Madawaska River                           |  Madawaska
Q1594722   |  MODvalue  |  name_nl     |  Madawaska River                           |  Madawaska
Q1594722   |  MODvalue  |  name_sv     |  Madawaska River                           |  Madawaska
Q22437847  |  MODvalue  |  name_en     |  Serpent River                             |  Serpent
Q478249    |  MODvalue  |  name_de     |  Spanish River                             |  Spanish
Q478249    |  MODvalue  |  name_en     |  Spanish River                             |  Spanish
Q478249    |  MODvalue  |  name_pl     |  Spanish River                             |  Spanish
Q3491719   |  MODvalue  |  name_en     |  Opeongo River                             |  Opeongo
Q3491719   |  MODvalue  |  name_sv     |  Opeongo River                             |  Opeongo
Q1491538   |  MODvalue  |  name_de     |  Wanapitei River                           |  Wanapitei
Q1491538   |  MODvalue  |  name_en     |  Wanapitei River                           |  Wanapitei
Q1491538   |  MODvalue  |  name_fr     |  Wanapitei River                           |  Wanapitei
Q1491538   |  MODvalue  |  name_nl     |  Wanapitei River                           |  Wanapitei
Q1491538   |  MODvalue  |  name_sv     |  Wanapitei River                           |  Wanapitei
Q1939154   |  MODvalue  |  name_de     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_en     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_nl     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_sv     |  Mississagi River                          |  Mississagi
Q22641260  |  MODvalue  |  name_en     |  Little White River                        |  Little White
Q22641260  |  MODvalue  |  name_nl     |  Little White River                        |  Little White
Q22641260  |  MODvalue  |  name_sv     |  Little White River                        |  Little White
Q5522295   |  MODvalue  |  name_en     |  Garden River                              |  Garden
Q478249    |  MODvalue  |  name_de     |  Spanish River                             |  Spanish
Q478249    |  MODvalue  |  name_en     |  Spanish River                             |  Spanish
Q478249    |  MODvalue  |  name_pl     |  Spanish River                             |  Spanish
Q12749684  |  MODvalue  |  name_de     |  Vermilion River                           |  Vermilion
Q12749684  |  MODvalue  |  name_en     |  Vermilion River                           |  Vermilion
Q5588216   |  MODvalue  |  name_en     |  Goulais River                             |  Goulais
Q5588216   |  MODvalue  |  name_nl     |  Goulais River                             |  Goulais
Q5588216   |  MODvalue  |  name_sv     |  Goulais River                             |  Goulais
Q22641260  |  MODvalue  |  name_en     |  Little White River                        |  Little White
Q22641260  |  MODvalue  |  name_nl     |  Little White River                        |  Little White
Q22641260  |  MODvalue  |  name_sv     |  Little White River                        |  Little White
Q60974     |  MODvalue  |  name_de     |  Ottawa River                              |  Ottawa
Q60974     |  MODvalue  |  name_en     |  Ottawa River                              |  Ottawa
Q60974     |  MODvalue  |  name_it     |  Ottawa River                              |  Ottawa
Q4868716   |  MODvalue  |  name_en     |  Batchawana River                          |  Batchawana
Q4868716   |  MODvalue  |  name_sv     |  Batchawana River                          |  Batchawana
Q18168198  |  MODvalue  |  name_en     |  Onaping River                             |  Onaping
Q18168198  |  MODvalue  |  name_nl     |  Onaping River                             |  Onaping
Q18168198  |  MODvalue  |  name_sv     |  Onaping River                             |  Onaping
Q7921614   |  MODvalue  |  name_de     |  Vermilion River                           |  Vermilion
Q7921614   |  MODvalue  |  name_en     |  Vermilion River                           |  Vermilion
Q2359274   |  MODvalue  |  name_de     |  Sturgeon River                            |  Sturgeon
Q2359274   |  MODvalue  |  name_en     |  Sturgeon River                            |  Sturgeon
Q22461970  |  MODvalue  |  name_en     |  Aubinadong River                          |  Aubinadong
Q22461970  |  MODvalue  |  name_nl     |  Aubinadong River                          |  Aubinadong
Q22461970  |  MODvalue  |  name_sv     |  Aubinadong River                          |  Aubinadong
Q1939154   |  MODvalue  |  name_de     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_en     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_nl     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_sv     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_de     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_en     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_nl     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_sv     |  Mississagi River                          |  Mississagi
Q776238    |  MODvalue  |  name_en     |  Coulonge River                            |  Coulonge
Q7921614   |  MODvalue  |  name_de     |  Vermilion River                           |  Vermilion
Q7921614   |  MODvalue  |  name_en     |  Vermilion River                           |  Vermilion
Q2359274   |  MODvalue  |  name_de     |  Sturgeon River                            |  Sturgeon
Q2359274   |  MODvalue  |  name_en     |  Sturgeon River                            |  Sturgeon
Q1946435   |  MODvalue  |  name_de     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_en     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_sv     |  Montreal River                            |  Montreal
Q1407181   |  MODvalue  |  name_en     |  Dumoine River                             |  Dumoine
Q2155741   |  MODvalue  |  name_en     |  Rouge River                               |  Rouge
Q1491538   |  MODvalue  |  name_de     |  Wanapitei River                           |  Wanapitei
Q1491538   |  MODvalue  |  name_en     |  Wanapitei River                           |  Wanapitei
Q1491538   |  MODvalue  |  name_fr     |  Wanapitei River                           |  Wanapitei
Q1491538   |  MODvalue  |  name_nl     |  Wanapitei River                           |  Wanapitei
Q1491538   |  MODvalue  |  name_sv     |  Wanapitei River                           |  Wanapitei
Q2038996   |  MODvalue  |  name_en     |  Yamaska River                             |  Yamaska
Q2359274   |  MODvalue  |  name_de     |  Sturgeon River                            |  Sturgeon
Q2359274   |  MODvalue  |  name_en     |  Sturgeon River                            |  Sturgeon
Q1485122   |  MODvalue  |  name_de     |  Pigeon River                              |  Pigeon
Q1485122   |  MODvalue  |  name_en     |  Pigeon River                              |  Pigeon
Q22454073  |  MODvalue  |  name_en     |  Arrow River                               |  Arrow
Q22454073  |  MODvalue  |  name_sv     |  Arrow River                               |  Arrow
Q6414609   |  MODvalue  |  name_en     |  Kipawa River                              |  Kipawa
Q22454073  |  MODvalue  |  name_en     |  Arrow River                               |  Arrow
Q22454073  |  MODvalue  |  name_sv     |  Arrow River                               |  Arrow
Q1570842   |  MODvalue  |  name_en     |  L'Assomption River                        |  L'Assomption
Q7995902   |  MODvalue  |  name_en     |  Whitefish River                           |  Whitefish
Q15122455  |  MODvalue  |  name_de     |  Namakan River                             |  Namakan
Q15122455  |  MODvalue  |  name_en     |  Namakan River                             |  Namakan
Q15122455  |  MODvalue  |  name_nl     |  Namakan River                             |  Namakan
Q15122455  |  MODvalue  |  name_sv     |  Namakan River                             |  Namakan
Q7259088   |  MODvalue  |  name_de     |  Pukaskwa River                            |  Pukaskwa
Q7259088   |  MODvalue  |  name_en     |  Pukaskwa River                            |  Pukaskwa
Q7259088   |  MODvalue  |  name_nl     |  Pukaskwa River                            |  Pukaskwa
Q7259088   |  MODvalue  |  name_sv     |  Pukaskwa River                            |  Pukaskwa
Q1946435   |  MODvalue  |  name_de     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_en     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_sv     |  Montreal River                            |  Montreal
Q1884687   |  MODvalue  |  name_de     |  Magpie River                              |  Magpie
Q1884687   |  MODvalue  |  name_en     |  Magpie River                              |  Magpie
Q1884687   |  MODvalue  |  name_nl     |  Magpie River                              |  Magpie
Q1884687   |  MODvalue  |  name_sv     |  Magpie River                              |  Magpie
Q1946433   |  MODvalue  |  name_de     |  Montreal River                            |  Montreal
Q1946433   |  MODvalue  |  name_en     |  Montreal River                            |  Montreal
Q1946433   |  MODvalue  |  name_sv     |  Montreal River                            |  Montreal
Q5288219   |  MODvalue  |  name_de     |  Dog River                                 |  Dog
Q5288219   |  MODvalue  |  name_en     |  Dog River                                 |  Dog
Q6414609   |  MODvalue  |  name_en     |  Kipawa River                              |  Kipawa
Q59464     |  MODvalue  |  name_de     |  Mattagami River                           |  Mattagami
Q59464     |  MODvalue  |  name_en     |  Mattagami River                           |  Mattagami
Q59464     |  MODvalue  |  name_fr     |  Mattagami River                           |  rivière Mattagami
Q59464     |  MODvalue  |  name_nl     |  Mattagami River                           |  Mattagami
Q59464     |  MODvalue  |  name_sv     |  Mattagami River                           |  Mattagami
Q5288219   |  MODvalue  |  name_de     |  Dog River                                 |  Dog
Q5288219   |  MODvalue  |  name_en     |  Dog River                                 |  Dog
Q116183    |  MODvalue  |  name_de     |  Kapuskasing River                         |  Kapuskasing
Q116183    |  MODvalue  |  name_en     |  Kapuskasing River                         |  Kapuskasing
Q116183    |  MODvalue  |  name_fr     |  Kapuskasing River                         |  Kapuskasing
Q116183    |  MODvalue  |  name_nl     |  Kapuskasing River                         |  Kapuskasing
Q116183    |  MODvalue  |  name_sv     |  Kapuskasing River                         |  Kapuskasing
Q1946435   |  MODvalue  |  name_de     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_en     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_sv     |  Montreal River                            |  Montreal
Q5288219   |  MODvalue  |  name_de     |  Dog River                                 |  Dog
Q5288219   |  MODvalue  |  name_en     |  Dog River                                 |  Dog
Q2461680   |  MODvalue  |  name_de     |  Turtle River                              |  Turtle
Q2461680   |  MODvalue  |  name_en     |  Turtle River                              |  Turtle
Q3433767   |  MODvalue  |  name_en     |  Nicolet River                             |  Nicolet
Q3433693   |  MODvalue  |  name_en     |  Gens de Terre River                       |  Gens de Terre
Q4924881   |  MODvalue  |  name_de     |  Blanche River                             |  Blanche
Q4924881   |  MODvalue  |  name_en     |  Blanche River                             |  Blanche
Q4924881   |  MODvalue  |  name_nl     |  Blanche River                             |  Blanche
Q4924881   |  MODvalue  |  name_sv     |  Blanche River                             |  Blanche
Q1570490   |  MODvalue  |  name_de     |  Seine River                               |  Seine
Q1570490   |  MODvalue  |  name_en     |  Seine River                               |  Seine
Q1570490   |  MODvalue  |  name_nl     |  Seine River                               |  Seine
Q1529669   |  MODvalue  |  name_de     |  White River                               |  White
Q1529669   |  MODvalue  |  name_en     |  White River                               |  White
Q1529669   |  MODvalue  |  name_fr     |  White River                               |  White
Q1529669   |  MODvalue  |  name_it     |  White River                               |  White
Q1529669   |  MODvalue  |  name_nl     |  White River                               |  White
Q1529669   |  MODvalue  |  name_pl     |  White River                               |  White
Q1529669   |  MODvalue  |  name_de     |  White River                               |  White
Q1529669   |  MODvalue  |  name_en     |  White River                               |  White
Q1529669   |  MODvalue  |  name_fr     |  White River                               |  White
Q1529669   |  MODvalue  |  name_it     |  White River                               |  White
Q1529669   |  MODvalue  |  name_nl     |  White River                               |  White
Q1529669   |  MODvalue  |  name_pl     |  White River                               |  White
Q5288219   |  MODvalue  |  name_de     |  Dog River                                 |  Dog
Q5288219   |  MODvalue  |  name_en     |  Dog River                                 |  Dog
Q1710848   |  MODvalue  |  name_de     |  Pic River                                 |  Pic
Q1710848   |  MODvalue  |  name_en     |  Pic River                                 |  Pic
Q1710848   |  MODvalue  |  name_nl     |  Pic River                                 |  Pic
Q1710848   |  MODvalue  |  name_sv     |  Pic River                                 |  Pic
Q3442448   |  MODvalue  |  name_de     |  Roseau River                              |  Roseau
Q3442448   |  MODvalue  |  name_en     |  Roseau River                              |  Roseau
Q3442448   |  MODvalue  |  name_nl     |  Roseau River                              |  Roseau
Q391411    |  MODvalue  |  name_en     |  Gatineau River                            |  Gatineau
Q391411    |  MODvalue  |  name_nl     |  Gatineau River                            |  Gatineau
Q391411    |  MODvalue  |  name_sv     |  Rivière Gatineau                          |  Gatineaufloden
Q6344175   |  MODvalue  |  name_de     |  Kabinakagami River                        |  Kabinakagami
Q6344175   |  MODvalue  |  name_en     |  Kabinakagami River                        |  Kabinakagami
Q6344175   |  MODvalue  |  name_sv     |  Kabinakagami River                        |  Kabinakagami
Q2068478   |  MODvalue  |  name_de     |  Pembina River                             |  Pembina
Q2068478   |  MODvalue  |  name_en     |  Pembina River                             |  Pembina
Q5288219   |  MODvalue  |  name_de     |  Dog River                                 |  Dog
Q5288219   |  MODvalue  |  name_en     |  Dog River                                 |  Dog
Q4921930   |  MODvalue  |  name_de     |  Black Sturgeon River                      |  Black Sturgeon
Q4921930   |  MODvalue  |  name_en     |  Black Sturgeon River                      |  Black Sturgeon
Q397996    |  MODvalue  |  name_de     |  Aguasabon River                           |  Aguasabon
Q397996    |  MODvalue  |  name_en     |  Aguasabon River                           |  Aguasabon
Q397996    |  MODvalue  |  name_fr     |  Aguasabon River                           |  Aguasabon
Q397996    |  MODvalue  |  name_nl     |  Aguasabon River                           |  Aguasabon
Q397996    |  MODvalue  |  name_sv     |  Aguasabon River                           |  Aguasabon
Q487925    |  MODvalue  |  name_de     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_en     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_nl     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_sv     |  Souris River                              |  Souris
Q4924881   |  MODvalue  |  name_de     |  Blanche River                             |  Blanche
Q4924881   |  MODvalue  |  name_en     |  Blanche River                             |  Blanche
Q4924881   |  MODvalue  |  name_nl     |  Blanche River                             |  Blanche
Q4924881   |  MODvalue  |  name_sv     |  Blanche River                             |  Blanche
Q286703    |  MODvalue  |  name_de     |  English River                             |  English
Q286703    |  MODvalue  |  name_en     |  English River                             |  English
Q286703    |  MODvalue  |  name_pl     |  English River                             |  English
Q487925    |  MODvalue  |  name_de     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_en     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_nl     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_sv     |  Souris River                              |  Souris
Q7996173   |  MODvalue  |  name_de     |  Whitemouth River                          |  Whitemouth
Q7996173   |  MODvalue  |  name_en     |  Whitemouth River                          |  Whitemouth
Q7996173   |  MODvalue  |  name_sv     |  Whitemouth River                          |  Whitemouth
Q60974     |  MODvalue  |  name_de     |  Ottawa River                              |  Ottawa
Q60974     |  MODvalue  |  name_en     |  Ottawa River                              |  Ottawa
Q60974     |  MODvalue  |  name_it     |  Ottawa River                              |  Ottawa
Q2155708   |  MODvalue  |  name_en     |  Matawin River                             |  Matawin
Q2155664   |  MODvalue  |  name_en     |  Batiscan River                            |  Batiscan
Q2068478   |  MODvalue  |  name_de     |  Pembina River                             |  Pembina
Q2068478   |  MODvalue  |  name_en     |  Pembina River                             |  Pembina
Q680761    |  MODvalue  |  name_en     |  Kinojévis River                           |  Kinojévis
Q397996    |  MODvalue  |  name_de     |  Aguasabon River                           |  Aguasabon
Q397996    |  MODvalue  |  name_en     |  Aguasabon River                           |  Aguasabon
Q397996    |  MODvalue  |  name_fr     |  Aguasabon River                           |  Aguasabon
Q397996    |  MODvalue  |  name_nl     |  Aguasabon River                           |  Aguasabon
Q397996    |  MODvalue  |  name_sv     |  Aguasabon River                           |  Aguasabon
Q487925    |  MODvalue  |  name_de     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_en     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_nl     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_sv     |  Souris River                              |  Souris
Q5617744   |  MODvalue  |  name_de     |  Gull River                                |  Gull
Q5617744   |  MODvalue  |  name_en     |  Gull River                                |  Gull
Q487925    |  MODvalue  |  name_de     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_en     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_nl     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_sv     |  Souris River                              |  Souris
Q7958699   |  MODvalue  |  name_de     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_en     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_nl     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_sv     |  Wabigoon River                            |  Wabigoon
Q391411    |  MODvalue  |  name_en     |  Gatineau River                            |  Gatineau
Q391411    |  MODvalue  |  name_nl     |  Gatineau River                            |  Gatineau
Q391411    |  MODvalue  |  name_sv     |  Rivière Gatineau                          |  Gatineaufloden
Q15842564  |  NEWvalue  |  name_ar     |                                            |  نهر بازين
Q15842564  |  MODvalue  |  name_en     |  Bazin River                               |  Bazin
Q15842564  |  NEWvalue  |  name_it     |                                            |  rivière Bazin
Q15842564  |  NEWvalue  |  name_nl     |                                            |  rivière Bazin
Q1628265   |  MODvalue  |  name_en     |  Jacques-Cartier River                     |  Jacques-Cartier
Q1452915   |  MODvalue  |  name_de     |  Frederick House River                     |  Frederick House
Q1452915   |  MODvalue  |  name_en     |  Frederick House River                     |  Frederick House
Q1452915   |  MODvalue  |  name_fr     |  Frederick House River                     |  Frederick House
Q1452915   |  NEWvalue  |  name_ja     |                                            |  フレデリックハウス川
Q1452915   |  MODvalue  |  name_nl     |  Frederick House River                     |  Frederick House
Q1452915   |  MODvalue  |  name_sv     |  Frederick House River                     |  Frederick House
Q22424013  |  MODvalue  |  name_en     |  Kanasuta River                            |  Kanasuta
Q6344175   |  MODvalue  |  name_de     |  Kabinakagami River                        |  Kabinakagami
Q6344175   |  MODvalue  |  name_en     |  Kabinakagami River                        |  Kabinakagami
Q6344175   |  MODvalue  |  name_sv     |  Kabinakagami River                        |  Kabinakagami
Q7229424   |  MODvalue  |  name_en     |  Poplar River                              |  Poplar
Q7229424   |  MODvalue  |  name_fr     |  Poplar River                              |  Poplar
Q487925    |  MODvalue  |  name_de     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_en     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_nl     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_sv     |  Souris River                              |  Souris
Q71996     |  MODvalue  |  name_en     |  Harricana River                           |  Harricana
Q71996     |  MODvalue  |  name_nl     |  Harricana River                           |  Harricana
Q1452915   |  MODvalue  |  name_de     |  Frederick House River                     |  Frederick House
Q1452915   |  MODvalue  |  name_en     |  Frederick House River                     |  Frederick House
Q1452915   |  MODvalue  |  name_fr     |  Frederick House River                     |  Frederick House
Q1452915   |  NEWvalue  |  name_ja     |                                            |  フレデリックハウス川
Q1452915   |  MODvalue  |  name_nl     |  Frederick House River                     |  Frederick House
Q1452915   |  MODvalue  |  name_sv     |  Frederick House River                     |  Frederick House
Q22654431  |  MODvalue  |  name_en     |  Namewaminikan River                       |  Namewaminikan
Q22654431  |  MODvalue  |  name_nl     |  Namewaminikan River                       |  Namewaminikan
Q22654431  |  MODvalue  |  name_sv     |  Namewaminikan River                       |  Namewaminikan
Q5617744   |  MODvalue  |  name_de     |  Gull River                                |  Gull
Q5617744   |  MODvalue  |  name_en     |  Gull River                                |  Gull
Q177469    |  MODvalue  |  name_de     |  Frenchman River                           |  Frenchman
Q177469    |  MODvalue  |  name_en     |  Frenchman River                           |  Frenchman
Q177469    |  MODvalue  |  name_nl     |  Frenchman River                           |  Frenchman
Q177469    |  MODvalue  |  name_sv     |  Frenchman River                           |  Frenchman
Q7958699   |  MODvalue  |  name_de     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_en     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_nl     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_sv     |  Wabigoon River                            |  Wabigoon
Q59647     |  MODvalue  |  name_de     |  Abitibi River                             |  Abitibi
Q59647     |  MODvalue  |  name_en     |  Abitibi River                             |  Abitibi
Q59647     |  MODvalue  |  name_nl     |  Abitibi River                             |  Abitibi
Q15122970  |  MODvalue  |  name_en     |  Manouane River                            |  Manouane
Q7958699   |  MODvalue  |  name_de     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_en     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_nl     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_sv     |  Wabigoon River                            |  Wabigoon
Q3433710   |  MODvalue  |  name_de     |  Kennebecasis River                        |  Kennebecasis
Q3433710   |  MODvalue  |  name_en     |  Kennebecasis River                        |  Kennebecasis
Q3433710   |  MODvalue  |  name_sv     |  Kennebecasis River                        |  Kennebecasis
Q15122432  |  MODvalue  |  name_de     |  Nagagami River                            |  Nagagami
Q15122432  |  MODvalue  |  name_en     |  Nagagami River                            |  Nagagami
Q15122432  |  MODvalue  |  name_sv     |  Nagagami River                            |  Nagagami
Q14506269  |  MODvalue  |  name_en     |  Bell River                                |  Bell
Q14506269  |  NEWvalue  |  name_sv     |                                            |  Rivière Bell
Q15842582  |  MODvalue  |  name_en     |  La Sarre River                            |  La Sarre
Q15123828  |  MODvalue  |  name_de     |  Pagwachuan River                          |  Pagwachuan
Q15123828  |  MODvalue  |  name_en     |  Pagwachuan River                          |  Pagwachuan
Q15123828  |  MODvalue  |  name_sv     |  Pagwachuan River                          |  Pagwachuan
Q7958699   |  MODvalue  |  name_de     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_en     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_nl     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_sv     |  Wabigoon River                            |  Wabigoon
Q1739002   |  MODvalue  |  name_de     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_en     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_fr     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_nl     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_sv     |  Kenogami River                            |  Kenogami
Q3433821   |  MODvalue  |  name_de     |  Shubenacadie River                        |  Shubenacadie
Q3433821   |  MODvalue  |  name_en     |  Shubenacadie River                        |  Shubenacadie
Q3433821   |  MODvalue  |  name_sv     |  Shubenacadie River                        |  Shubenacadie
Q15123828  |  MODvalue  |  name_de     |  Pagwachuan River                          |  Pagwachuan
Q15123828  |  MODvalue  |  name_en     |  Pagwachuan River                          |  Pagwachuan
Q15123828  |  MODvalue  |  name_sv     |  Pagwachuan River                          |  Pagwachuan
Q2155754   |  MODvalue  |  name_en     |  Turgeon River                             |  Turgeon
Q59647     |  MODvalue  |  name_de     |  Abitibi River                             |  Abitibi
Q59647     |  MODvalue  |  name_en     |  Abitibi River                             |  Abitibi
Q59647     |  MODvalue  |  name_nl     |  Abitibi River                             |  Abitibi
Q59647     |  MODvalue  |  name_de     |  Abitibi River                             |  Abitibi
Q59647     |  MODvalue  |  name_en     |  Abitibi River                             |  Abitibi
Q59647     |  MODvalue  |  name_nl     |  Abitibi River                             |  Abitibi
Q7629029   |  MODvalue  |  name_de     |  Sturgeon River                            |  Sturgeon
Q7629029   |  MODvalue  |  name_en     |  Sturgeon River                            |  Sturgeon
Q20750422  |  MODvalue  |  name_en     |  Wawagosic River                           |  Wawagosic
Q15109911  |  MODvalue  |  name_de     |  Drowning River                            |  Drowning
Q15109911  |  MODvalue  |  name_en     |  Drowning River                            |  Drowning
Q15109911  |  MODvalue  |  name_sv     |  Drowning River                            |  Drowning
Q22436349  |  MODvalue  |  name_en     |  Saint-Cyr River                           |  Saint-Cyr
Q22440718  |  MODvalue  |  name_en     |  Wetetnagami River                         |  Wetetnagami
Q6648837   |  MODvalue  |  name_de     |  Little Abitibi River                      |  Little Abitibi
Q6648837   |  MODvalue  |  name_en     |  Little Abitibi River                      |  Little Abitibi
Q6648837   |  MODvalue  |  name_sv     |  Little Abitibi River                      |  Little Abitibi
Q6648837   |  MODvalue  |  name_de     |  Little Abitibi River                      |  Little Abitibi
Q6648837   |  MODvalue  |  name_en     |  Little Abitibi River                      |  Little Abitibi
Q6648837   |  MODvalue  |  name_sv     |  Little Abitibi River                      |  Little Abitibi
Q391566    |  MODvalue  |  name_de     |  Qu’Appelle River                          |  Qu’Appelle
Q391566    |  MODvalue  |  name_en     |  Qu'Appelle River                          |  Qu'Appelle
Q391566    |  MODvalue  |  name_sv     |  Qu'Appelle River                          |  Qu'Appelle
Q7571323   |  MODvalue  |  name_en     |  Southwest Miramichi River                 |  Southwest Miramichi
Q7571323   |  MODvalue  |  name_nl     |  Southwest Miramichi River                 |  Southwest Miramichi
Q7571323   |  MODvalue  |  name_sv     |  Southwest Miramichi River                 |  Southwest Miramichi
Q15108795  |  MODvalue  |  name_de     |  Chukuni River                             |  Chukuni
Q15108795  |  MODvalue  |  name_en     |  Chukuni River                             |  Chukuni
Q15108795  |  MODvalue  |  name_nl     |  Chukuni River                             |  Chukuni
Q15108795  |  MODvalue  |  name_sv     |  Chukuni River                             |  Chukuni
Q126922    |  MODvalue  |  name_en     |  Petitcodiac River                         |  Petitcodiac
Q126922    |  MODvalue  |  name_nl     |  Petitcodiac River                         |  Petitcodiac
Q126922    |  MODvalue  |  name_sv     |  Petitcodiac River                         |  Petitcodiac
Q11880756  |  MODvalue  |  name_de     |  Manigotagan River                         |  Manigotagan
Q11880756  |  MODvalue  |  name_en     |  Manigotagan River                         |  Manigotagan
Q11880756  |  MODvalue  |  name_sv     |  Manigotagan River                         |  Manigotagan
Q7590512   |  MODvalue  |  name_en     |  St. Mary River                            |  St. Mary
Q1739002   |  MODvalue  |  name_de     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_en     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_fr     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_nl     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_sv     |  Kenogami River                            |  Kenogami
Q1323214   |  MODvalue  |  name_de     |  Tobique River                             |  Tobique
Q1323214   |  MODvalue  |  name_en     |  Tobique River                             |  Tobique
Q247160    |  MODvalue  |  name_de     |  Aroostook River                           |  Aroostook
Q247160    |  MODvalue  |  name_en     |  Aroostook River                           |  Aroostook
Q247160    |  MODvalue  |  name_nl     |  Aroostook River                           |  Aroostook
Q1592361   |  MODvalue  |  name_de     |  Kesagami River                            |  Kesagami
Q1592361   |  MODvalue  |  name_en     |  Kesagami River                            |  Kesagami
Q1592361   |  MODvalue  |  name_nl     |  Kesagami River                            |  Kesagami
Q1592361   |  MODvalue  |  name_sv     |  Kesagami River                            |  Kesagami
Q2016217   |  MODvalue  |  name_de     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_en     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_fr     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_nl     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_sv     |  Ogoki River                               |  Ogoki
Q3433645   |  MODvalue  |  name_en     |  Belly River                               |  Belly
Q3433645   |  MODvalue  |  name_sv     |  Belly River                               |  Belly
Q15118716  |  MODvalue  |  name_de     |  Little Current River                      |  Little Current
Q15118716  |  MODvalue  |  name_en     |  Little Current River                      |  Little Current
Q15118716  |  MODvalue  |  name_sv     |  Little Current River                      |  Little Current
Q15132584  |  MODvalue  |  name_de     |  Troutlake River                           |  Troutlake
Q15132584  |  MODvalue  |  name_en     |  Troutlake River                           |  Troutlake
Q15132584  |  MODvalue  |  name_nl     |  Troutlake River                           |  Troutlake
Q15132584  |  MODvalue  |  name_sv     |  Troutlake River                           |  Troutlake
Q15108795  |  MODvalue  |  name_de     |  Chukuni River                             |  Chukuni
Q15108795  |  MODvalue  |  name_en     |  Chukuni River                             |  Chukuni
Q15108795  |  MODvalue  |  name_nl     |  Chukuni River                             |  Chukuni
Q15108795  |  MODvalue  |  name_sv     |  Chukuni River                             |  Chukuni
Q2214785   |  MODvalue  |  name_de     |  Salmon River                              |  Salmon
Q2214785   |  MODvalue  |  name_en     |  Salmon River                              |  Salmon
Q1739002   |  MODvalue  |  name_de     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_en     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_fr     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_nl     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_sv     |  Kenogami River                            |  Kenogami
Q2016217   |  MODvalue  |  name_de     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_en     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_fr     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_nl     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_sv     |  Ogoki River                               |  Ogoki
Q1739002   |  MODvalue  |  name_de     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_en     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_fr     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_nl     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_sv     |  Kenogami River                            |  Kenogami
Q15118716  |  MODvalue  |  name_de     |  Little Current River                      |  Little Current
Q15118716  |  MODvalue  |  name_en     |  Little Current River                      |  Little Current
Q15118716  |  MODvalue  |  name_sv     |  Little Current River                      |  Little Current
Q2016217   |  MODvalue  |  name_de     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_en     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_fr     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_nl     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_sv     |  Ogoki River                               |  Ogoki
Q7590512   |  MODvalue  |  name_en     |  St. Mary River                            |  St. Mary
Q391566    |  MODvalue  |  name_de     |  Qu’Appelle River                          |  Qu’Appelle
Q391566    |  MODvalue  |  name_en     |  Qu'Appelle River                          |  Qu'Appelle
Q391566    |  MODvalue  |  name_sv     |  Qu'Appelle River                          |  Qu'Appelle
Q391566    |  MODvalue  |  name_de     |  Qu’Appelle River                          |  Qu’Appelle
Q391566    |  MODvalue  |  name_en     |  Qu'Appelle River                          |  Qu'Appelle
Q391566    |  MODvalue  |  name_sv     |  Qu'Appelle River                          |  Qu'Appelle
Q2016217   |  MODvalue  |  name_de     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_en     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_fr     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_nl     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_sv     |  Ogoki River                               |  Ogoki
Q20650477  |  MODvalue  |  name_en     |  O'Sullivan River                          |  O'Sullivan
Q20650477  |  MODvalue  |  name_nl     |  O'Sullivan River                          |  O'Sullivan
Q846926    |  MODvalue  |  name_de     |  Madawaska River                           |  Madawaska
Q846926    |  MODvalue  |  name_en     |  Madawaska River                           |  Madawaska
Q846926    |  MODvalue  |  name_nl     |  Madawaska River                           |  Madawaska
Q885244    |  MODvalue  |  name_de     |  Bloodvein River                           |  Bloodvein
Q885244    |  MODvalue  |  name_en     |  Bloodvein River                           |  Bloodvein
Q885244    |  MODvalue  |  name_fr     |  Bloodvein River                           |  Bloodvein
Q885244    |  MODvalue  |  name_nl     |  Bloodvein River                           |  Bloodvein
Q885244    |  MODvalue  |  name_sv     |  Bloodvein River                           |  Bloodvein
Q15118716  |  MODvalue  |  name_de     |  Little Current River                      |  Little Current
Q15118716  |  MODvalue  |  name_en     |  Little Current River                      |  Little Current
Q15118716  |  MODvalue  |  name_sv     |  Little Current River                      |  Little Current
Q2016217   |  MODvalue  |  name_de     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_en     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_fr     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_nl     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_sv     |  Ogoki River                               |  Ogoki
Q7590512   |  MODvalue  |  name_en     |  St. Mary River                            |  St. Mary
Q22461606  |  MODvalue  |  name_en     |  Attwood River                             |  Attwood
Q22461606  |  MODvalue  |  name_nl     |  Attwood River                             |  Attwood
Q22461606  |  MODvalue  |  name_sv     |  Attwood River                             |  Attwood
Q1514985   |  MODvalue  |  name_de     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_en     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_nl     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_sv     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_de     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_en     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_nl     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_sv     |  Oldman River                              |  Oldman
Q1814459   |  MODvalue  |  name_en     |  Restigouche River                         |  Restigouche
Q1814459   |  MODvalue  |  name_sv     |  Restigouche River                         |  Restigouche
Q5364109   |  MODvalue  |  name_en     |  Elk River                                 |  Elk
Q5364109   |  MODvalue  |  name_pl     |  Elk River                                 |  Elk
Q2155754   |  MODvalue  |  name_en     |  Turgeon River                             |  Turgeon
Q2262      |  MODvalue  |  name_de     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_en     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_nl     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_sv     |  Kootenay River                            |  Kootenay
Q15116445  |  MODvalue  |  name_de     |  Kawinogans River                          |  Kawinogans
Q15116445  |  MODvalue  |  name_en     |  Kawinogans River                          |  Kawinogans
Q15116445  |  MODvalue  |  name_nl     |  Kawinogans River                          |  Kawinogans
Q15116445  |  MODvalue  |  name_sv     |  Kawinogans River                          |  Kawinogans
Q22485701  |  MODvalue  |  name_en     |  Cheepay River                             |  Cheepay
Q22485701  |  MODvalue  |  name_nl     |  Cheepay River                             |  Cheepay
Q22485701  |  MODvalue  |  name_sv     |  Cheepay River                             |  Cheepay
Q1603754   |  MODvalue  |  name_en     |  Opawica river                             |  Opawica
Q1603754   |  MODvalue  |  name_nl     |  Opawica River                             |  Opawica
Q1603754   |  MODvalue  |  name_en     |  Opawica river                             |  Opawica
Q1603754   |  MODvalue  |  name_nl     |  Opawica River                             |  Opawica
Q1514985   |  MODvalue  |  name_de     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_en     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_nl     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_sv     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_de     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_en     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_nl     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_sv     |  Oldman River                              |  Oldman
Q1376163   |  MODvalue  |  name_en     |  Mistassini River                          |  Mistassini
Q2262      |  MODvalue  |  name_de     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_en     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_nl     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_sv     |  Kootenay River                            |  Kootenay
Q3482326   |  MODvalue  |  name_en     |  Shipshaw River                            |  Shipshaw
Q1376034   |  MODvalue  |  name_en     |  Waswanipi River                           |  Waswanipi
Q1376034   |  MODvalue  |  name_en     |  Waswanipi River                           |  Waswanipi
Q59647     |  MODvalue  |  name_de     |  Abitibi River                             |  Abitibi
Q59647     |  MODvalue  |  name_en     |  Abitibi River                             |  Abitibi
Q59647     |  MODvalue  |  name_nl     |  Abitibi River                             |  Abitibi
Q1539523   |  MODvalue  |  name_en     |  Kitchigama River                          |  Kitchigama
Q3256660   |  MODvalue  |  name_en     |  Little Bow River                          |  Little Bow
Q3256660   |  MODvalue  |  name_fr     |  Little Bow River                          |  Little Bow
Q3256660   |  MODvalue  |  name_sv     |  Little Bow River                          |  Little Bow
Q1603754   |  MODvalue  |  name_en     |  Opawica river                             |  Opawica
Q1603754   |  MODvalue  |  name_nl     |  Opawica River                             |  Opawica
Q1514985   |  MODvalue  |  name_de     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_en     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_nl     |  Oldman River                              |  Oldman
Q1514985   |  MODvalue  |  name_sv     |  Oldman River                              |  Oldman
Q1376034   |  MODvalue  |  name_en     |  Waswanipi River                           |  Waswanipi
Q1739002   |  MODvalue  |  name_de     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_en     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_fr     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_nl     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_sv     |  Kenogami River                            |  Kenogami
Q819057    |  MODvalue  |  name_de     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_en     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_fr     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_nl     |  Berens River                              |  Berens
Q1376034   |  MODvalue  |  name_en     |  Waswanipi River                           |  Waswanipi
Q22461606  |  MODvalue  |  name_en     |  Attwood River                             |  Attwood
Q22461606  |  MODvalue  |  name_nl     |  Attwood River                             |  Attwood
Q22461606  |  MODvalue  |  name_sv     |  Attwood River                             |  Attwood
Q2155662   |  MODvalue  |  name_en     |  Chibougamau River                         |  Chibougamau
Q1739002   |  MODvalue  |  name_de     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_en     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_fr     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_nl     |  Kenogami River                            |  Kenogami
Q1739002   |  MODvalue  |  name_sv     |  Kenogami River                            |  Kenogami
Q1376163   |  MODvalue  |  name_en     |  Mistassini River                          |  Mistassini
Q771286    |  MODvalue  |  name_en     |  Mistassibi River                          |  Mistassibi
Q22485701  |  MODvalue  |  name_en     |  Cheepay River                             |  Cheepay
Q22485701  |  MODvalue  |  name_nl     |  Cheepay River                             |  Cheepay
Q22485701  |  MODvalue  |  name_sv     |  Cheepay River                             |  Cheepay
Q15842591  |  MODvalue  |  name_en     |  Ouasiemsca river                          |  Ouasiemsca
Q1592361   |  MODvalue  |  name_de     |  Kesagami River                            |  Kesagami
Q1592361   |  MODvalue  |  name_en     |  Kesagami River                            |  Kesagami
Q1592361   |  MODvalue  |  name_nl     |  Kesagami River                            |  Kesagami
Q1592361   |  MODvalue  |  name_sv     |  Kesagami River                            |  Kesagami
Q1376163   |  MODvalue  |  name_en     |  Mistassini River                          |  Mistassini
Q676140    |  MODvalue  |  name_de     |  Nepisiguit River                          |  Nepisiguit
Q676140    |  MODvalue  |  name_en     |  Nepisiguit River                          |  Nepisiguit
Q391566    |  MODvalue  |  name_de     |  Qu’Appelle River                          |  Qu’Appelle
Q391566    |  MODvalue  |  name_en     |  Qu'Appelle River                          |  Qu'Appelle
Q391566    |  MODvalue  |  name_sv     |  Qu'Appelle River                          |  Qu'Appelle
Q20645849  |  MODvalue  |  name_en     |  Maicasagi River                           |  Maicasagi
Q20645849  |  MODvalue  |  name_nl     |  Maicasagi River                           |  Maicasagi
Q1320358   |  MODvalue  |  name_en     |  Obatogamau river                          |  Obatogamau
Q1320358   |  MODvalue  |  name_en     |  Obatogamau river                          |  Obatogamau
Q15123712  |  MODvalue  |  name_de     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_en     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_nl     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_sv     |  Otoskwin River                            |  Otoskwin
Q15122998  |  MODvalue  |  name_de     |  North French River                        |  North French
Q15122998  |  MODvalue  |  name_en     |  North French River                        |  North French
Q15122998  |  MODvalue  |  name_sv     |  North French River                        |  North French
Q2155662   |  MODvalue  |  name_en     |  Chibougamau River                         |  Chibougamau
Q270484    |  MODvalue  |  name_de     |  Kettle River                              |  Kettle
Q270484    |  MODvalue  |  name_en     |  Kettle River                              |  Kettle
Q270484    |  MODvalue  |  name_nl     |  Kettle River                              |  Kettle
Q15124841  |  MODvalue  |  name_de     |  Pigeon River                              |  Pigeon
Q2155662   |  MODvalue  |  name_en     |  Chibougamau River                         |  Chibougamau
Q1173016   |  MODvalue  |  name_de     |  Dauphin River                             |  Dauphin
Q1173016   |  MODvalue  |  name_en     |  Dauphin River                             |  Dauphin
Q1173016   |  MODvalue  |  name_nl     |  Dauphin River                             |  Dauphin
Q1173016   |  MODvalue  |  name_sv     |  Dauphin River                             |  Dauphin
Q15123712  |  MODvalue  |  name_de     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_en     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_nl     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_sv     |  Otoskwin River                            |  Otoskwin
Q270484    |  MODvalue  |  name_de     |  Kettle River                              |  Kettle
Q270484    |  MODvalue  |  name_en     |  Kettle River                              |  Kettle
Q270484    |  MODvalue  |  name_nl     |  Kettle River                              |  Kettle
Q2262      |  MODvalue  |  name_de     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_en     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_nl     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_sv     |  Kootenay River                            |  Kootenay
Q15842617  |  NEWvalue  |  name_ar     |                                            |  نهر الشيف
Q15842617  |  NEWvalue  |  name_bn     |                                            |  শেফের নদী
Q15842617  |  NEWvalue  |  name_en     |                                            |  Rivière du Chef
Q15842617  |  NEWvalue  |  name_it     |                                            |  rivière du Chef
Q15842617  |  NEWvalue  |  name_zh     |                                            |  厨师的河
Q819057    |  MODvalue  |  name_de     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_en     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_fr     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_nl     |  Berens River                              |  Berens
Q850119    |  MODvalue  |  name_de     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_en     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_nl     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_sv     |  Red Deer River                            |  Red Deer
Q2262      |  MODvalue  |  name_de     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_en     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_nl     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_sv     |  Kootenay River                            |  Kootenay
Q15842594  |  MODvalue  |  name_en     |  Portneuf River                            |  Portneuf
Q2294385   |  MODvalue  |  name_de     |  Slocan River                              |  Slocan
Q2294385   |  MODvalue  |  name_en     |  Slocan River                              |  Slocan
Q2294385   |  MODvalue  |  name_sv     |  Slocan River                              |  Slocan
Q15124859  |  MODvalue  |  name_de     |  Pineimuta River                           |  Pineimuta
Q15124859  |  MODvalue  |  name_en     |  Pineimuta River                           |  Pineimuta
Q15124859  |  MODvalue  |  name_nl     |  Pineimuta River                           |  Pineimuta
Q15124859  |  MODvalue  |  name_sv     |  Pineimuta River                           |  Pineimuta
Q819057    |  MODvalue  |  name_de     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_en     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_fr     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_nl     |  Berens River                              |  Berens
Q22424453  |  MODvalue  |  name_en     |  Kinosheo River                            |  Kinosheo
Q22424453  |  MODvalue  |  name_nl     |  Kinosheo River                            |  Kinosheo
Q22424453  |  MODvalue  |  name_sv     |  Kinosheo River                            |  Kinosheo
Q271058    |  MODvalue  |  name_de     |  Okanogan River                            |  Okanogan
Q271058    |  MODvalue  |  name_en     |  Okanogan River                            |  Okanogan
Q271058    |  MODvalue  |  name_nl     |  Okanogan River                            |  Okanogan
Q3433741   |  MODvalue  |  name_en     |  Matapédia River                           |  Matapédia
Q15124871  |  MODvalue  |  name_de     |  Pipestone River                           |  Pipestone
Q15124871  |  MODvalue  |  name_en     |  Pipestone River                           |  Pipestone
Q819057    |  MODvalue  |  name_de     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_en     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_fr     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_nl     |  Berens River                              |  Berens
Q15123712  |  MODvalue  |  name_de     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_en     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_nl     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_sv     |  Otoskwin River                            |  Otoskwin
Q2372020   |  MODvalue  |  name_de     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_en     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_sv     |  Swan River                                |  Swan
Q304833    |  MODvalue  |  name_de     |  Similkameen River                         |  Similkameen
Q304833    |  MODvalue  |  name_en     |  Similkameen River                         |  Similkameen
Q304833    |  MODvalue  |  name_sv     |  Similkameen River                         |  Similkameen
Q850119    |  MODvalue  |  name_de     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_en     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_nl     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_sv     |  Red Deer River                            |  Red Deer
Q15123712  |  MODvalue  |  name_de     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_en     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_nl     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_sv     |  Otoskwin River                            |  Otoskwin
Q771286    |  MODvalue  |  name_en     |  Mistassibi River                          |  Mistassibi
Q13948373  |  MODvalue  |  name_en     |  Highwood River                            |  Highwood
Q13948373  |  MODvalue  |  name_sv     |  Highwood River                            |  Highwood
Q1621199   |  MODvalue  |  name_de     |  Poplar River                              |  Poplar
Q1621199   |  MODvalue  |  name_en     |  Poplar River                              |  Poplar
Q1621199   |  MODvalue  |  name_sv     |  Poplar River                              |  Poplar
Q22618093  |  MODvalue  |  name_en     |  MacDowell River                           |  MacDowell
Q22618093  |  MODvalue  |  name_nl     |  MacDowell River                           |  MacDowell
Q22618093  |  MODvalue  |  name_sv     |  MacDowell River                           |  MacDowell
Q757914    |  MODvalue  |  name_de     |  Attawapiskat River                        |  Attawapiskat
Q757914    |  MODvalue  |  name_en     |  Attawapiskat River                        |  Attawapiskat
Q757914    |  MODvalue  |  name_nl     |  Attawapiskat River                        |  Attawapiskat
Q13948373  |  MODvalue  |  name_en     |  Highwood River                            |  Highwood
Q13948373  |  MODvalue  |  name_sv     |  Highwood River                            |  Highwood
Q850119    |  MODvalue  |  name_de     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_en     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_nl     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_sv     |  Red Deer River                            |  Red Deer
Q2155694   |  MODvalue  |  name_en     |  Manouane River                            |  Manouane
Q2155694   |  MODvalue  |  name_nl     |  Manouane River                            |  Manouane
Q94368     |  MODvalue  |  name_en     |  Broadback River                           |  Broadback
Q94368     |  MODvalue  |  name_nl     |  Broadback River                           |  Broadback
Q601290    |  MODvalue  |  name_en     |  Betsiamites River                         |  Betsiamites
Q601290    |  MODvalue  |  name_fr     |  Betsiamites                               |  rivière Betsiamites
Q15123712  |  MODvalue  |  name_de     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_en     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_nl     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_sv     |  Otoskwin River                            |  Otoskwin
Q16893144  |  MODvalue  |  name_en     |  Kapiskau River                            |  Kapiskau
Q16893144  |  MODvalue  |  name_nl     |  Kapiskau River                            |  Kapiskau
Q16893144  |  MODvalue  |  name_sv     |  Kapiskau River                            |  Kapiskau
Q94368     |  MODvalue  |  name_en     |  Broadback River                           |  Broadback
Q94368     |  MODvalue  |  name_nl     |  Broadback River                           |  Broadback
Q305408    |  MODvalue  |  name_de     |  Skagit River                              |  Skagit
Q305408    |  MODvalue  |  name_en     |  Skagit River                              |  Skagit
Q305408    |  MODvalue  |  name_nl     |  Skagit River                              |  Skagit
Q94368     |  MODvalue  |  name_en     |  Broadback River                           |  Broadback
Q94368     |  MODvalue  |  name_nl     |  Broadback River                           |  Broadback
Q2909926   |  MODvalue  |  name_en     |  Bonaventure River                         |  Bonaventure
Q3433668   |  MODvalue  |  name_en     |  Cascapédia River                          |  Cascapédia
Q3433668   |  MODvalue  |  name_sv     |  Cascapédia River                          |  Cascapédia
Q94368     |  MODvalue  |  name_en     |  Broadback River                           |  Broadback
Q94368     |  MODvalue  |  name_nl     |  Broadback River                           |  Broadback
Q270562    |  NEWvalue  |  name_de     |                                            |  Duncan
Q270562    |  MODvalue  |  name_en     |  Duncan River                              |  Duncan
Q1239783   |  MODvalue  |  name_de     |  Severn River                              |  Severn
Q1239783   |  MODvalue  |  name_en     |  Severn River                              |  Severn
Q1239783   |  MODvalue  |  name_fr     |  Severn River                              |  Severn
Q1239783   |  MODvalue  |  name_nl     |  Severn River                              |  Severn
Q1239783   |  MODvalue  |  name_de     |  Severn River                              |  Severn
Q1239783   |  MODvalue  |  name_en     |  Severn River                              |  Severn
Q1239783   |  MODvalue  |  name_fr     |  Severn River                              |  Severn
Q1239783   |  MODvalue  |  name_nl     |  Severn River                              |  Severn
Q94368     |  MODvalue  |  name_en     |  Broadback River                           |  Broadback
Q94368     |  MODvalue  |  name_nl     |  Broadback River                           |  Broadback
Q1621199   |  MODvalue  |  name_de     |  Poplar River                              |  Poplar
Q1621199   |  MODvalue  |  name_en     |  Poplar River                              |  Poplar
Q1621199   |  MODvalue  |  name_sv     |  Poplar River                              |  Poplar
Q270562    |  NEWvalue  |  name_de     |                                            |  Duncan
Q270562    |  MODvalue  |  name_en     |  Duncan River                              |  Duncan
Q15135028  |  MODvalue  |  name_de     |  Windigo River                             |  Windigo
Q15135028  |  MODvalue  |  name_en     |  Windigo River                             |  Windigo
Q15135028  |  MODvalue  |  name_nl     |  Windigo River                             |  Windigo
Q15135028  |  MODvalue  |  name_sv     |  Windigo River                             |  Windigo
Q22525014  |  MODvalue  |  name_en     |  Missisa River                             |  Missisa
Q22525014  |  MODvalue  |  name_nl     |  Missisa River                             |  Missisa
Q22525014  |  MODvalue  |  name_sv     |  Missisa River                             |  Missisa
Q6503578   |  MODvalue  |  name_en     |  Lawashi River                             |  Lawashi
Q6503578   |  MODvalue  |  name_nl     |  Lawashi River                             |  Lawashi
Q6503578   |  MODvalue  |  name_sv     |  Lawashi River                             |  Lawashi
Q15135028  |  MODvalue  |  name_de     |  Windigo River                             |  Windigo
Q15135028  |  MODvalue  |  name_en     |  Windigo River                             |  Windigo
Q15135028  |  MODvalue  |  name_nl     |  Windigo River                             |  Windigo
Q15135028  |  MODvalue  |  name_sv     |  Windigo River                             |  Windigo
Q1621199   |  MODvalue  |  name_de     |  Poplar River                              |  Poplar
Q1621199   |  MODvalue  |  name_en     |  Poplar River                              |  Poplar
Q1621199   |  MODvalue  |  name_sv     |  Poplar River                              |  Poplar
Q270562    |  NEWvalue  |  name_de     |                                            |  Duncan
Q270562    |  MODvalue  |  name_en     |  Duncan River                              |  Duncan
Q1412295   |  MODvalue  |  name_en     |  Pontax River                              |  Pontax
Q601290    |  MODvalue  |  name_en     |  Betsiamites River                         |  Betsiamites
Q601290    |  MODvalue  |  name_fr     |  Betsiamites                               |  rivière Betsiamites
Q1586288   |  MODvalue  |  name_de     |  Harrison River                            |  Harrison
Q1586288   |  MODvalue  |  name_en     |  Harrison River                            |  Harrison
Q1586288   |  MODvalue  |  name_fr     |  Harrison River                            |  Harrison
Q1586288   |  MODvalue  |  name_nl     |  Harrison River                            |  Harrison
Q1586288   |  MODvalue  |  name_sv     |  Harrison River                            |  Harrison
Q7604798   |  MODvalue  |  name_en     |  Stave River                               |  Stave
Q7604798   |  MODvalue  |  name_sv     |  Stave River                               |  Stave
Q15135028  |  MODvalue  |  name_de     |  Windigo River                             |  Windigo
Q15135028  |  MODvalue  |  name_en     |  Windigo River                             |  Windigo
Q15135028  |  MODvalue  |  name_nl     |  Windigo River                             |  Windigo
Q15135028  |  MODvalue  |  name_sv     |  Windigo River                             |  Windigo
Q80350     |  MODvalue  |  name_de     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_en     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_nl     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_sv     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_de     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_en     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_nl     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_sv     |  Winisk River                              |  Winisk
Q850119    |  MODvalue  |  name_de     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_en     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_nl     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_sv     |  Red Deer River                            |  Red Deer
Q280542    |  MODvalue  |  name_de     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_en     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_fr     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_sv     |  Shuswap River                             |  Shuswap
Q14555119  |  MODvalue  |  name_en     |  Nemiscau River                            |  Nemiscau
Q15867664  |  MODvalue  |  name_en     |  Jolicoeur River                           |  Jolicoeur
Q5046702   |  MODvalue  |  name_de     |  Carrot River                              |  Carrot
Q5046702   |  MODvalue  |  name_en     |  Carrot River                              |  Carrot
Q5046702   |  MODvalue  |  name_fr     |  Carrot River                              |  Carrot
Q5046702   |  MODvalue  |  name_sv     |  Carrot River                              |  Carrot
Q80350     |  MODvalue  |  name_de     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_en     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_nl     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_sv     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_de     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_en     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_nl     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_sv     |  Winisk River                              |  Winisk
Q427437    |  MODvalue  |  name_en     |  Rupert River                              |  Rupert
Q427437    |  MODvalue  |  name_nl     |  Rupert River                              |  Rupert
Q15106873  |  MODvalue  |  name_de     |  Asheweig River                            |  Asheweig
Q15106873  |  MODvalue  |  name_en     |  Asheweig River                            |  Asheweig
Q15106873  |  MODvalue  |  name_sv     |  Asheweig River                            |  Asheweig
Q427437    |  MODvalue  |  name_en     |  Rupert River                              |  Rupert
Q427437    |  MODvalue  |  name_nl     |  Rupert River                              |  Rupert
Q427437    |  MODvalue  |  name_en     |  Rupert River                              |  Rupert
Q427437    |  MODvalue  |  name_nl     |  Rupert River                              |  Rupert
Q15867664  |  MODvalue  |  name_en     |  Jolicoeur River                           |  Jolicoeur
Q2155747   |  MODvalue  |  name_en     |  Toulnustouc River                         |  Toulnustouc
Q2155749   |  MODvalue  |  name_en     |  Temiscanie River                          |  Temiscanie
Q15842609  |  MODvalue  |  name_en     |  York river                                |  York
Q280542    |  MODvalue  |  name_de     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_en     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_fr     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_sv     |  Shuswap River                             |  Shuswap
Q757914    |  MODvalue  |  name_de     |  Attawapiskat River                        |  Attawapiskat
Q757914    |  MODvalue  |  name_en     |  Attawapiskat River                        |  Attawapiskat
Q757914    |  MODvalue  |  name_nl     |  Attawapiskat River                        |  Attawapiskat
Q268952    |  MODvalue  |  name_de     |  Lillooet River                            |  Lillooet
Q268952    |  MODvalue  |  name_en     |  Lillooet River                            |  Lillooet
Q268952    |  MODvalue  |  name_nl     |  Lillooet River                            |  Lillooet
Q268952    |  MODvalue  |  name_sv     |  Lillooet River                            |  Lillooet
Q176234    |  MODvalue  |  name_de     |  Battle River                              |  Battle
Q176234    |  MODvalue  |  name_en     |  Battle River                              |  Battle
Q176234    |  NEWvalue  |  name_ja     |                                            |  バトル川
Q176234    |  MODvalue  |  name_nl     |  Battle River                              |  Battle
Q850119    |  MODvalue  |  name_de     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_en     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_nl     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_sv     |  Red Deer River                            |  Red Deer
Q779746    |  MODvalue  |  name_en     |  Opinaca River                             |  Opinaca
Q15842566  |  MODvalue  |  name_en     |  Conn River                                |  Conn
Q176234    |  MODvalue  |  name_de     |  Battle River                              |  Battle
Q176234    |  MODvalue  |  name_en     |  Battle River                              |  Battle
Q176234    |  NEWvalue  |  name_ja     |                                            |  バトル川
Q176234    |  MODvalue  |  name_nl     |  Battle River                              |  Battle
Q14555119  |  MODvalue  |  name_en     |  Nemiscau River                            |  Nemiscau
Q1138870   |  MODvalue  |  name_de     |  Squamish River                            |  Squamish
Q1138870   |  MODvalue  |  name_en     |  Squamish River                            |  Squamish
Q1138870   |  MODvalue  |  name_nl     |  Squamish River                            |  Squamish
Q1138870   |  MODvalue  |  name_sv     |  Squamish River                            |  Squamish
Q15106873  |  MODvalue  |  name_de     |  Asheweig River                            |  Asheweig
Q15106873  |  MODvalue  |  name_en     |  Asheweig River                            |  Asheweig
Q15106873  |  MODvalue  |  name_sv     |  Asheweig River                            |  Asheweig
Q2155749   |  MODvalue  |  name_en     |  Temiscanie River                          |  Temiscanie
Q850119    |  MODvalue  |  name_de     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_en     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_nl     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_sv     |  Red Deer River                            |  Red Deer
Q779746    |  MODvalue  |  name_en     |  Opinaca River                             |  Opinaca
Q15128416  |  MODvalue  |  name_de     |  Shamattawa River                          |  Shamattawa
Q15128416  |  MODvalue  |  name_en     |  Shamattawa River                          |  Shamattawa
Q15128416  |  MODvalue  |  name_nl     |  Shamattawa River                          |  Shamattawa
Q15128416  |  MODvalue  |  name_sv     |  Shamattawa River                          |  Shamattawa
Q22699042  |  MODvalue  |  name_en     |  Medicine River                            |  Medicine
Q22699042  |  MODvalue  |  name_nl     |  Medicine River                            |  Medicine
Q22699042  |  MODvalue  |  name_sv     |  Medicine River                            |  Medicine
Q351963    |  MODvalue  |  name_de     |  Adams River                               |  Adams
Q351963    |  MODvalue  |  name_en     |  Adams River                               |  Adams
Q351963    |  MODvalue  |  name_sv     |  Adams River                               |  Adams
Q850119    |  MODvalue  |  name_de     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_en     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_nl     |  Red Deer River                            |  Red Deer
Q850119    |  MODvalue  |  name_sv     |  Red Deer River                            |  Red Deer
Q15842624  |  MODvalue  |  name_en     |  Vieux Comptoir River                      |  Vieux Comptoir
Q1398954   |  MODvalue  |  name_de     |  Fawn River                                |  Fawn
Q1398954   |  MODvalue  |  name_en     |  Fawn River                                |  Fawn
Q1398954   |  MODvalue  |  name_sv     |  Fawn River                                |  Fawn
Q2155747   |  MODvalue  |  name_en     |  Toulnustouc River                         |  Toulnustouc
Q1099571   |  MODvalue  |  name_de     |  Clearwater River                          |  Clearwater
Q1099571   |  MODvalue  |  name_en     |  Clearwater River                          |  Clearwater
Q1099571   |  MODvalue  |  name_fr     |  Clearwater River                          |  Clearwater
Q1099571   |  NEWvalue  |  name_it     |                                            |  Clearwater
Q1099571   |  MODvalue  |  name_sv     |  Clearwater River                          |  Clearwater
Q7396716   |  MODvalue  |  name_de     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_en     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_nl     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_sv     |  Sachigo River                             |  Sachigo
Q15842612  |  MODvalue  |  name_en     |  Aux Rochers River                         |  Aux Rochers
Q4926702   |  MODvalue  |  name_en     |  Blindman River                            |  Blindman
Q4926702   |  MODvalue  |  name_sv     |  Blindman River                            |  Blindman
Q1968809   |  MODvalue  |  name_en     |  Eastmain River                            |  Eastmain
Q1968809   |  MODvalue  |  name_nl     |  Eastmain River                            |  Eastmain
Q268952    |  MODvalue  |  name_de     |  Lillooet River                            |  Lillooet
Q268952    |  MODvalue  |  name_en     |  Lillooet River                            |  Lillooet
Q268952    |  MODvalue  |  name_nl     |  Lillooet River                            |  Lillooet
Q268952    |  MODvalue  |  name_sv     |  Lillooet River                            |  Lillooet
Q3047      |  MODvalue  |  name_de     |  Saskatchewan River                        |  Saskatchewan
Q3047      |  MODvalue  |  name_en     |  Saskatchewan River                        |  Saskatchewan
Q3047      |  MODvalue  |  name_sv     |  Saskatchewan River                        |  Saskatchewan
Q270044    |  NEWvalue  |  name_de     |                                            |  Elaho
Q270044    |  MODvalue  |  name_en     |  Elaho River                               |  Elaho
Q270044    |  MODvalue  |  name_es     |  Elaho River                               |  Elaho
Q270044    |  MODvalue  |  name_nl     |  Elaho River                               |  Elaho
Q270044    |  MODvalue  |  name_sv     |  Elaho River                               |  Elaho
Q1138870   |  MODvalue  |  name_de     |  Squamish River                            |  Squamish
Q1138870   |  MODvalue  |  name_en     |  Squamish River                            |  Squamish
Q1138870   |  MODvalue  |  name_nl     |  Squamish River                            |  Squamish
Q1138870   |  MODvalue  |  name_sv     |  Squamish River                            |  Squamish
Q2155737   |  MODvalue  |  name_en     |  Sainte-Marguerite river                   |  Sainte-Marguerite
Q268526    |  MODvalue  |  name_en     |  Bonaparte River                           |  Bonaparte
Q268526    |  MODvalue  |  name_sv     |  Bonaparte River                           |  Bonaparte
Q7396716   |  MODvalue  |  name_de     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_en     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_nl     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_sv     |  Sachigo River                             |  Sachigo
Q19843743  |  MODvalue  |  name_en     |  Maquatua River                            |  Maquatua
Q19843743  |  MODvalue  |  name_nl     |  Maquatua River                            |  Maquatua
Q2372020   |  MODvalue  |  name_de     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_en     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_sv     |  Swan River                                |  Swan
Q15842612  |  MODvalue  |  name_en     |  Aux Rochers River                         |  Aux Rochers
Q267246    |  MODvalue  |  name_en     |  Powell River                              |  Powell
Q267246    |  MODvalue  |  name_sv     |  Powell River                              |  Powell
Q351963    |  MODvalue  |  name_de     |  Adams River                               |  Adams
Q351963    |  MODvalue  |  name_en     |  Adams River                               |  Adams
Q351963    |  MODvalue  |  name_sv     |  Adams River                               |  Adams
Q1591919   |  MODvalue  |  name_de     |  Hayes River                               |  Hayes
Q1591919   |  MODvalue  |  name_en     |  Hayes River                               |  Hayes
Q2663607   |  MODvalue  |  name_de     |  Bridge River                              |  Bridge
Q2663607   |  MODvalue  |  name_en     |  Bridge River                              |  Bridge
Q2663607   |  MODvalue  |  name_nl     |  Bridge River                              |  Bridge
Q2663607   |  MODvalue  |  name_sv     |  Bridge River                              |  Bridge
Q601279    |  MODvalue  |  name_en     |  Moisie River                              |  Moisie
Q5332818   |  MODvalue  |  name_de     |  Echoing River                             |  Echoing
Q5332818   |  MODvalue  |  name_en     |  Echoing River                             |  Echoing
Q22600344  |  MODvalue  |  name_sv     |  Hargrave River                            |  Hargrave
Q2155747   |  MODvalue  |  name_en     |  Toulnustouc River                         |  Toulnustouc
Q15106873  |  MODvalue  |  name_de     |  Asheweig River                            |  Asheweig
Q15106873  |  MODvalue  |  name_en     |  Asheweig River                            |  Asheweig
Q15106873  |  MODvalue  |  name_sv     |  Asheweig River                            |  Asheweig
Q3292      |  NEWvalue  |  name_bn     |                                            |  নেলসন নদী
Q3292      |  MODvalue  |  name_de     |  Nelson River                              |  Nelson
Q3292      |  MODvalue  |  name_en     |  Nelson River                              |  Nelson
Q12749684  |  MODvalue  |  name_de     |  Vermilion River                           |  Vermilion
Q12749684  |  MODvalue  |  name_en     |  Vermilion River                           |  Vermilion
Q2359245   |  MODvalue  |  name_de     |  Sturgeon-weir River                       |  Sturgeon-weir
Q2359245   |  MODvalue  |  name_en     |  Sturgeon-Weir River                       |  Sturgeon-Weir
Q2359245   |  MODvalue  |  name_sv     |  Sturgeon-weir River                       |  Sturgeon-weir
Q5332818   |  MODvalue  |  name_de     |  Echoing River                             |  Echoing
Q5332818   |  MODvalue  |  name_en     |  Echoing River                             |  Echoing
Q903023    |  MODvalue  |  name_de     |  Brazeau River                             |  Brazeau
Q903023    |  MODvalue  |  name_en     |  Brazeau River                             |  Brazeau
Q903023    |  MODvalue  |  name_sv     |  Brazeau River                             |  Brazeau
Q1591919   |  MODvalue  |  name_de     |  Hayes River                               |  Hayes
Q1591919   |  MODvalue  |  name_en     |  Hayes River                               |  Hayes
Q601279    |  MODvalue  |  name_en     |  Moisie River                              |  Moisie
Q2155747   |  MODvalue  |  name_en     |  Toulnustouc River                         |  Toulnustouc
Q1099574   |  MODvalue  |  name_de     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_en     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_nl     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_sv     |  Clearwater River                          |  Clearwater
Q15128706  |  MODvalue  |  name_de     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_en     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_nl     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_sv     |  Smoothstone River                         |  Smoothstone
Q2437619   |  MODvalue  |  name_de     |  Toba River                                |  Toba
Q2437619   |  MODvalue  |  name_en     |  Toba River                                |  Toba
Q2437619   |  MODvalue  |  name_fr     |  Toba River                                |  Toba
Q2437619   |  MODvalue  |  name_sv     |  Toba River                                |  Toba
Q18168183  |  MODvalue  |  name_en     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_nl     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_sv     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_en     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_nl     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_sv     |  Grass River                               |  Grass
Q2359245   |  MODvalue  |  name_de     |  Sturgeon-weir River                       |  Sturgeon-weir
Q2359245   |  MODvalue  |  name_en     |  Sturgeon-Weir River                       |  Sturgeon-Weir
Q2359245   |  MODvalue  |  name_sv     |  Sturgeon-weir River                       |  Sturgeon-weir
Q1591919   |  MODvalue  |  name_de     |  Hayes River                               |  Hayes
Q1591919   |  MODvalue  |  name_en     |  Hayes River                               |  Hayes
Q18168183  |  MODvalue  |  name_en     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_nl     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_sv     |  Grass River                               |  Grass
Q7687133   |  MODvalue  |  name_en     |  Taseko River                              |  Taseko
Q7687133   |  MODvalue  |  name_sv     |  Taseko River                              |  Taseko
Q2155692   |  MODvalue  |  name_en     |  Magpie River                              |  Magpie
Q2155745   |  MODvalue  |  name_en     |  Saint-Jean River                          |  Saint-Jean
Q1099574   |  MODvalue  |  name_de     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_en     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_nl     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_sv     |  Clearwater River                          |  Clearwater
Q1968809   |  MODvalue  |  name_en     |  Eastmain River                            |  Eastmain
Q1968809   |  MODvalue  |  name_nl     |  Eastmain River                            |  Eastmain
Q1946435   |  MODvalue  |  name_de     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_en     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_sv     |  Montreal River                            |  Montreal
Q31308     |  MODvalue  |  name_en     |  Sakami River                              |  Sakami
Q2068478   |  MODvalue  |  name_de     |  Pembina River                             |  Pembina
Q2068478   |  MODvalue  |  name_en     |  Pembina River                             |  Pembina
Q31308     |  MODvalue  |  name_en     |  Sakami River                              |  Sakami
Q15128706  |  MODvalue  |  name_de     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_en     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_nl     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_sv     |  Smoothstone River                         |  Smoothstone
Q1626939   |  MODvalue  |  name_en     |  Mouchalagane River                        |  Mouchalagane
Q31308     |  MODvalue  |  name_en     |  Sakami River                              |  Sakami
Q7396716   |  MODvalue  |  name_de     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_en     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_nl     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_sv     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_de     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_en     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_nl     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_sv     |  Sachigo River                             |  Sachigo
Q860139    |  MODvalue  |  name_en     |  Romaine River                             |  Romaine
Q2155677   |  MODvalue  |  name_en     |  Hart Jaune river                          |  Hart Jaune
Q1591919   |  MODvalue  |  name_de     |  Hayes River                               |  Hayes
Q1591919   |  MODvalue  |  name_en     |  Hayes River                               |  Hayes
Q18168183  |  MODvalue  |  name_en     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_nl     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_sv     |  Grass River                               |  Grass
Q3433827   |  MODvalue  |  name_en     |  Sturgeon River                            |  Sturgeon
Q3433827   |  MODvalue  |  name_sv     |  Sturgeon River                            |  Sturgeon
Q7974133   |  MODvalue  |  name_de     |  Waterhen River                            |  Waterhen
Q7974133   |  MODvalue  |  name_en     |  Waterhen River                            |  Waterhen
Q7974133   |  MODvalue  |  name_nl     |  Waterhen River                            |  Waterhen
Q7974133   |  MODvalue  |  name_sv     |  Waterhen River                            |  Waterhen
Q15842615  |  NEWvalue  |  name_ar     |                                            |  البتولا، إستأصل، ريفير
Q15842615  |  NEWvalue  |  name_bn     |                                            |  বার্চ রুট নদী
Q15842615  |  NEWvalue  |  name_en     |                                            |  Racine de Bouleau
Q15842615  |  NEWvalue  |  name_it     |                                            |  rivière de la Racine de Bouleau
Q1915292   |  MODvalue  |  name_de     |  McLeod River                              |  McLeod
Q1915292   |  MODvalue  |  name_en     |  McLeod River                              |  McLeod
Q270485    |  MODvalue  |  name_de     |  Homathko River                            |  Homathko
Q270485    |  MODvalue  |  name_en     |  Homathko River                            |  Homathko
Q270485    |  MODvalue  |  name_fr     |  Homathko River                            |  Homathko
Q270485    |  MODvalue  |  name_nl     |  Homathko River                            |  Homathko
Q270485    |  MODvalue  |  name_sv     |  Homathko River                            |  Homathko
Q7974133   |  MODvalue  |  name_de     |  Waterhen River                            |  Waterhen
Q7974133   |  MODvalue  |  name_en     |  Waterhen River                            |  Waterhen
Q7974133   |  MODvalue  |  name_nl     |  Waterhen River                            |  Waterhen
Q7974133   |  MODvalue  |  name_sv     |  Waterhen River                            |  Waterhen
Q601279    |  MODvalue  |  name_en     |  Moisie River                              |  Moisie
Q7687133   |  MODvalue  |  name_en     |  Taseko River                              |  Taseko
Q7687133   |  MODvalue  |  name_sv     |  Taseko River                              |  Taseko
Q15128706  |  MODvalue  |  name_de     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_en     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_nl     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_sv     |  Smoothstone River                         |  Smoothstone
Q270961    |  MODvalue  |  name_de     |  Chilcotin River                           |  Chilcotin
Q270961    |  MODvalue  |  name_en     |  Chilcotin River                           |  Chilcotin
Q270961    |  MODvalue  |  name_nl     |  Chilcotin River                           |  Chilcotin
Q270961    |  MODvalue  |  name_sv     |  Chilcotin River                           |  Chilcotin
Q7359388   |  MODvalue  |  name_en     |  Roggan River                              |  Roggan
Q6663893   |  MODvalue  |  name_en     |  Lobstick River                            |  Lobstick
Q6663893   |  MODvalue  |  name_nl     |  Lobstick River                            |  Lobstick
Q6663893   |  MODvalue  |  name_sv     |  Lobstick River                            |  Lobstick
Q2068478   |  MODvalue  |  name_de     |  Pembina River                             |  Pembina
Q2068478   |  MODvalue  |  name_en     |  Pembina River                             |  Pembina
Q268202    |  MODvalue  |  name_de     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_en     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_fr     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_nl     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_sv     |  Horsefly River                            |  Horsefly
Q22434259  |  MODvalue  |  name_en     |  Kississing River                          |  Kississing
Q22434259  |  MODvalue  |  name_nl     |  Kississing River                          |  Kississing
Q22434259  |  MODvalue  |  name_sv     |  Kississing River                          |  Kississing
Q7359388   |  MODvalue  |  name_en     |  Roggan River                              |  Roggan
Q7359388   |  MODvalue  |  name_en     |  Roggan River                              |  Roggan
Q5000261   |  MODvalue  |  name_en     |  Burntwood River                           |  Burntwood
Q5000261   |  MODvalue  |  name_sv     |  Burntwood River                           |  Burntwood
Q813500    |  MODvalue  |  name_de     |  Beaver River                              |  Beaver
Q813500    |  MODvalue  |  name_en     |  Beaver River                              |  Beaver
Q813500    |  MODvalue  |  name_nl     |  Beaver River                              |  Beaver
Q1946435   |  MODvalue  |  name_de     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_en     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_sv     |  Montreal River                            |  Montreal
Q7415866   |  MODvalue  |  name_en     |  Sand River                                |  Sand
Q7415866   |  MODvalue  |  name_sv     |  Sand River                                |  Sand
Q2155649   |  MODvalue  |  name_en     |  Aguanish River                            |  Aguanish
Q18168183  |  MODvalue  |  name_en     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_nl     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_sv     |  Grass River                               |  Grass
Q5000261   |  MODvalue  |  name_en     |  Burntwood River                           |  Burntwood
Q5000261   |  MODvalue  |  name_sv     |  Burntwood River                           |  Burntwood
Q18168183  |  MODvalue  |  name_en     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_nl     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_sv     |  Grass River                               |  Grass
Q265856    |  NEWvalue  |  name_de     |                                            |  Klinaklini
Q265856    |  MODvalue  |  name_en     |  Klinaklini River                          |  Klinaklini
Q265856    |  NEWvalue  |  name_fr     |                                            |  Klinaklini
Q265856    |  MODvalue  |  name_sv     |  Klinaklini River                          |  Klinaklini
Q268202    |  MODvalue  |  name_de     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_en     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_fr     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_nl     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_sv     |  Horsefly River                            |  Horsefly
Q5000261   |  MODvalue  |  name_en     |  Burntwood River                           |  Burntwood
Q5000261   |  MODvalue  |  name_sv     |  Burntwood River                           |  Burntwood
Q15119827  |  MODvalue  |  name_de     |  Martineau River                           |  Martineau
Q15119827  |  MODvalue  |  name_en     |  Martineau River                           |  Martineau
Q15119827  |  MODvalue  |  name_nl     |  Martineau River                           |  Martineau
Q15119827  |  MODvalue  |  name_sv     |  Martineau River                           |  Martineau
Q18168183  |  MODvalue  |  name_en     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_nl     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_sv     |  Grass River                               |  Grass
Q2155692   |  MODvalue  |  name_en     |  Magpie River                              |  Magpie
Q268197    |  MODvalue  |  name_de     |  Chilko River                              |  Chilko
Q268197    |  MODvalue  |  name_en     |  Chilko River                              |  Chilko
Q268197    |  MODvalue  |  name_fr     |  Chilko River                              |  Chilko
Q268197    |  MODvalue  |  name_nl     |  Chilko River                              |  Chilko
Q268197    |  MODvalue  |  name_sv     |  Chilko River                              |  Chilko
Q7295398   |  MODvalue  |  name_en     |  Rat River                                 |  Rat
Q7295398   |  NEWvalue  |  name_nl     |                                            |  Rat
Q7295398   |  NEWvalue  |  name_sv     |                                            |  Rat
Q270485    |  MODvalue  |  name_de     |  Homathko River                            |  Homathko
Q270485    |  MODvalue  |  name_en     |  Homathko River                            |  Homathko
Q270485    |  MODvalue  |  name_fr     |  Homathko River                            |  Homathko
Q270485    |  MODvalue  |  name_nl     |  Homathko River                            |  Homathko
Q270485    |  MODvalue  |  name_sv     |  Homathko River                            |  Homathko
Q1440192   |  MODvalue  |  name_de     |  Fox River                                 |  Fox
Q1440192   |  MODvalue  |  name_en     |  Fox River                                 |  Fox
Q20645412  |  MODvalue  |  name_en     |  Kanaaupscow River                         |  Kanaaupscow
Q20645412  |  MODvalue  |  name_nl     |  Kanaaupscow River                         |  Rivière Kanaaupscow
Q20645412  |  NEWvalue  |  name_sv     |                                            |  Rivière Kanaaupscow
Q270109    |  MODvalue  |  name_de     |  Quesnel River                             |  Quesnel
Q270109    |  MODvalue  |  name_en     |  Quesnel River                             |  Quesnel
Q270109    |  MODvalue  |  name_fr     |  Quesnel River                             |  Quesnel
Q270109    |  MODvalue  |  name_nl     |  Quesnel River                             |  Quesnel
Q270109    |  MODvalue  |  name_sv     |  Quesnel River                             |  Quesnel
Q31379     |  MODvalue  |  name_en     |  La Grande River                           |  La Grande
Q1412484   |  MODvalue  |  name_en     |  Musquaro River                            |  Musquaro
Q1551634   |  MODvalue  |  name_de     |  Smoky River                               |  Smoky
Q1551634   |  MODvalue  |  name_en     |  Smoky River                               |  Smoky
Q1551634   |  MODvalue  |  name_hu     |  Smoky River                               |  Smoky
Q1551634   |  NEWvalue  |  name_it     |                                            |  Smoky
Q1551634   |  NEWvalue  |  name_ja     |                                            |  スモーキー川
Q1551634   |  MODvalue  |  name_sv     |  Smoky River                               |  Smoky
Q268197    |  MODvalue  |  name_de     |  Chilko River                              |  Chilko
Q268197    |  MODvalue  |  name_en     |  Chilko River                              |  Chilko
Q268197    |  MODvalue  |  name_fr     |  Chilko River                              |  Chilko
Q268197    |  MODvalue  |  name_nl     |  Chilko River                              |  Chilko
Q268197    |  MODvalue  |  name_sv     |  Chilko River                              |  Chilko
Q268164    |  MODvalue  |  name_de     |  Cariboo River                             |  Cariboo
Q268164    |  MODvalue  |  name_en     |  Cariboo River                             |  Cariboo
Q268164    |  MODvalue  |  name_sv     |  Cariboo River                             |  Cariboo
Q15108593  |  MODvalue  |  name_de     |  Canoe River                               |  Canoe
Q270961    |  MODvalue  |  name_de     |  Chilcotin River                           |  Chilcotin
Q270961    |  MODvalue  |  name_en     |  Chilcotin River                           |  Chilcotin
Q270961    |  MODvalue  |  name_nl     |  Chilcotin River                           |  Chilcotin
Q270961    |  MODvalue  |  name_sv     |  Chilcotin River                           |  Chilcotin
Q19952102  |  MODvalue  |  name_en     |  Chauvreulx River                          |  Chauvreulx
Q19952102  |  MODvalue  |  name_nl     |  Chauvreulx River                          |  Chauvreulx
Q270109    |  MODvalue  |  name_de     |  Quesnel River                             |  Quesnel
Q270109    |  MODvalue  |  name_en     |  Quesnel River                             |  Quesnel
Q270109    |  MODvalue  |  name_fr     |  Quesnel River                             |  Quesnel
Q270109    |  MODvalue  |  name_nl     |  Quesnel River                             |  Quesnel
Q270109    |  MODvalue  |  name_sv     |  Quesnel River                             |  Quesnel
Q291233    |  MODvalue  |  name_de     |  Churchill River                           |  Churchill
Q291233    |  MODvalue  |  name_en     |  Churchill River                           |  Churchill
Q291233    |  MODvalue  |  name_fr     |  Fleuve Churchill                          |  fleuve Churchill
Q291233    |  MODvalue  |  name_nl     |  Churchill River                           |  Churchill
Q20645412  |  MODvalue  |  name_en     |  Kanaaupscow River                         |  Kanaaupscow
Q20645412  |  MODvalue  |  name_nl     |  Kanaaupscow River                         |  Rivière Kanaaupscow
Q20645412  |  NEWvalue  |  name_sv     |                                            |  Rivière Kanaaupscow
Q15842606  |  MODvalue  |  name_en     |  Vauquelin River                           |  Vauquelin
Q15842606  |  MODvalue  |  name_en     |  Vauquelin River                           |  Vauquelin
Q15842606  |  MODvalue  |  name_en     |  Vauquelin River                           |  Vauquelin
Q1591919   |  MODvalue  |  name_de     |  Hayes River                               |  Hayes
Q1591919   |  MODvalue  |  name_en     |  Hayes River                               |  Hayes
Q22659007  |  MODvalue  |  name_en     |  Loon River                                |  Loon
Q22659007  |  MODvalue  |  name_nl     |  Loon River                                |  Loon
Q22659007  |  MODvalue  |  name_sv     |  Loon River                                |  Loon
Q5000261   |  MODvalue  |  name_en     |  Burntwood River                           |  Burntwood
Q5000261   |  MODvalue  |  name_sv     |  Burntwood River                           |  Burntwood
Q14874714  |  MODvalue  |  name_en     |  Nazko River                               |  Nazko
Q14874714  |  MODvalue  |  name_sv     |  Nazko River                               |  Nazko
Q268164    |  MODvalue  |  name_de     |  Cariboo River                             |  Cariboo
Q268164    |  MODvalue  |  name_en     |  Cariboo River                             |  Cariboo
Q268164    |  MODvalue  |  name_sv     |  Cariboo River                             |  Cariboo
Q15117959  |  MODvalue  |  name_de     |  La Biche River                            |  La Biche
Q4951407   |  MODvalue  |  name_de     |  Bowron River                              |  Bowron
Q4951407   |  MODvalue  |  name_en     |  Bowron River                              |  Bowron
Q4951407   |  MODvalue  |  name_sv     |  Bowron River                              |  Bowron
Q7295398   |  MODvalue  |  name_en     |  Rat River                                 |  Rat
Q7295398   |  NEWvalue  |  name_nl     |                                            |  Rat
Q7295398   |  NEWvalue  |  name_sv     |                                            |  Rat
Q20669533  |  MODvalue  |  name_en     |  Denys River                               |  Denys
Q20669533  |  MODvalue  |  name_nl     |  Denys River                               |  Denys
Q6651973   |  MODvalue  |  name_de     |  Little Smoky River                        |  Little Smoky
Q6651973   |  MODvalue  |  name_en     |  Little Smoky River                        |  Little Smoky
Q6651973   |  MODvalue  |  name_sv     |  Little Smoky River                        |  Little Smoky
Q1412484   |  MODvalue  |  name_en     |  Musquaro River                            |  Musquaro
Q2155649   |  MODvalue  |  name_en     |  Aguanish River                            |  Aguanish
Q267278    |  NEWvalue  |  name_de     |                                            |  Dean
Q267278    |  MODvalue  |  name_en     |  Dean River                                |  Dean
Q267278    |  NEWvalue  |  name_fr     |                                            |  Dean
Q267278    |  MODvalue  |  name_sv     |  Dean River                                |  Dean
Q291233    |  MODvalue  |  name_de     |  Churchill River                           |  Churchill
Q291233    |  MODvalue  |  name_en     |  Churchill River                           |  Churchill
Q291233    |  MODvalue  |  name_fr     |  Fleuve Churchill                          |  fleuve Churchill
Q291233    |  MODvalue  |  name_nl     |  Churchill River                           |  Churchill
Q22603397  |  MODvalue  |  name_en     |  Haultain River                            |  Haultain
Q22603397  |  MODvalue  |  name_nl     |  Haultain River                            |  Haultain
Q22603397  |  MODvalue  |  name_sv     |  Haultain River                            |  Haultain
Q22543023  |  REDIRECT  |  wikidataid  |  Q22543023                                 |  Q6549344
Q22543023  |  NEWvalue  |  name_de     |                                            |  Limestone
Q22543023  |  MODvalue  |  name_en     |  Limestone River                           |  Limestone
Q22543023  |  MODvalue  |  name_nl     |  Limestone River                           |  Limestone
Q22543023  |  MODvalue  |  name_sv     |  Limestone River                           |  Limestone
Q15128582  |  MODvalue  |  name_de     |  Simonette River                           |  Simonette
Q601279    |  MODvalue  |  name_en     |  Moisie River                              |  Moisie
Q17041002  |  NEWvalue  |  name_de     |                                            |  Talchako
Q17041002  |  MODvalue  |  name_en     |  Talchako River                            |  Talchako
Q17041002  |  MODvalue  |  name_sv     |  Talchako River                            |  Talchako
Q6649563   |  MODvalue  |  name_de     |  Little Churchill River                    |  Little Churchill
Q6649563   |  MODvalue  |  name_en     |  Little Churchill River                    |  Little Churchill
Q6649563   |  MODvalue  |  name_sv     |  Little Churchill River                    |  Little Churchill
Q757532    |  MODvalue  |  name_de     |  Atnarko River                             |  Atnarko
Q757532    |  MODvalue  |  name_en     |  Atnarko River                             |  Atnarko
Q757532    |  MODvalue  |  name_fr     |  Atnarko River                             |  Atnarko
Q757532    |  MODvalue  |  name_nl     |  Atnarko River                             |  Atnarko
Q757532    |  MODvalue  |  name_sv     |  Atnarko River                             |  Atnarko
Q15111285  |  MODvalue  |  name_de     |  Gauer River                               |  Gauer
Q15111285  |  MODvalue  |  name_en     |  Gauer River                               |  Gauer
Q15111285  |  MODvalue  |  name_nl     |  Gauer River                               |  Gauer
Q15111285  |  MODvalue  |  name_sv     |  Gauer River                               |  Gauer
Q2372020   |  MODvalue  |  name_de     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_en     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_sv     |  Swan River                                |  Swan
Q19955893  |  MODvalue  |  name_en     |  Coats River                               |  Coats
Q19955893  |  MODvalue  |  name_nl     |  Coats River                               |  Coats
Q6801464   |  MODvalue  |  name_de     |  McGregor River                            |  McGregor
Q6801464   |  MODvalue  |  name_en     |  McGregor River                            |  McGregor
Q6801464   |  MODvalue  |  name_sv     |  McGregor River                            |  McGregor
Q860143    |  MODvalue  |  name_en     |  Little Mecatina River                     |  Little Mecatina
Q860143    |  MODvalue  |  name_en     |  Little Mecatina River                     |  Little Mecatina
Q22649147  |  MODvalue  |  name_en     |  Hughes River                              |  Hughes
Q22649147  |  MODvalue  |  name_nl     |  Hughes River                              |  Hughes
Q22649147  |  MODvalue  |  name_sv     |  Hughes River                              |  Hughes
Q22649147  |  MODvalue  |  name_en     |  Hughes River                              |  Hughes
Q22649147  |  MODvalue  |  name_nl     |  Hughes River                              |  Hughes
Q22649147  |  MODvalue  |  name_sv     |  Hughes River                              |  Hughes
Q268519    |  MODvalue  |  name_de     |  Kakwa River                               |  Kakwa
Q268519    |  MODvalue  |  name_en     |  Kakwa River                               |  Kakwa
Q268519    |  MODvalue  |  name_sv     |  Kakwa River                               |  Kakwa
Q14612484  |  MODvalue  |  name_de     |  Christina River                           |  Christina
Q14612484  |  MODvalue  |  name_en     |  Christina River                           |  Christina
Q14612484  |  MODvalue  |  name_fr     |  Christina River                           |  Christina
Q22457456  |  MODvalue  |  name_en     |  Ashuanipi River                           |  Ashuanipi
Q22457456  |  MODvalue  |  name_nl     |  Ashuanipi River                           |  Ashuanipi
Q22457456  |  MODvalue  |  name_sv     |  Ashuanipi River                           |  Ashuanipi
Q1250604   |  MODvalue  |  name_de     |  West Road River                           |  West Road
Q1250604   |  MODvalue  |  name_en     |  West Road River                           |  West Road
Q1250604   |  MODvalue  |  name_fr     |  West Road River                           |  West Road
Q1250604   |  MODvalue  |  name_nl     |  West Road River                           |  West Road
Q1250604   |  MODvalue  |  name_sv     |  West Road River                           |  West Road
Q1250604   |  MODvalue  |  name_de     |  West Road River                           |  West Road
Q1250604   |  MODvalue  |  name_en     |  West Road River                           |  West Road
Q1250604   |  MODvalue  |  name_fr     |  West Road River                           |  West Road
Q1250604   |  MODvalue  |  name_nl     |  West Road River                           |  West Road
Q1250604   |  MODvalue  |  name_sv     |  West Road River                           |  West Road
Q268948    |  MODvalue  |  name_de     |  Bella Coola River                         |  Bella Coola
Q268948    |  MODvalue  |  name_en     |  Bella Coola River                         |  Bella Coola
Q268948    |  MODvalue  |  name_fr     |  Bella Coola River                         |  Bella Coola
Q268948    |  MODvalue  |  name_nl     |  Bella Coola River                         |  Bella Coola
Q268948    |  MODvalue  |  name_sv     |  Bella Coola River                         |  Bella Coola
Q22457456  |  MODvalue  |  name_en     |  Ashuanipi River                           |  Ashuanipi
Q22457456  |  MODvalue  |  name_nl     |  Ashuanipi River                           |  Ashuanipi
Q22457456  |  MODvalue  |  name_sv     |  Ashuanipi River                           |  Ashuanipi
Q6463459   |  MODvalue  |  name_en     |  La Loche River                            |  La Loche
Q1551634   |  MODvalue  |  name_de     |  Smoky River                               |  Smoky
Q1551634   |  MODvalue  |  name_en     |  Smoky River                               |  Smoky
Q1551634   |  MODvalue  |  name_hu     |  Smoky River                               |  Smoky
Q1551634   |  NEWvalue  |  name_it     |                                            |  Smoky
Q1551634   |  NEWvalue  |  name_ja     |                                            |  スモーキー川
Q1551634   |  MODvalue  |  name_sv     |  Smoky River                               |  Smoky
Q22655069  |  NEWvalue  |  name_de     |                                            |  La Loche
Q22655069  |  NEWvalue  |  name_en     |                                            |  La Loche
Q22655069  |  NEWvalue  |  name_fr     |                                            |  rivière La Loche
Q22655069  |  NEWvalue  |  name_it     |                                            |  La Loche
Q22655069  |  MODvalue  |  name_nl     |  La Loche River                            |  La Loche
Q22655069  |  MODvalue  |  name_sv     |  La Loche River                            |  La Loche
Q14612484  |  MODvalue  |  name_de     |  Christina River                           |  Christina
Q14612484  |  MODvalue  |  name_en     |  Christina River                           |  Christina
Q14612484  |  MODvalue  |  name_fr     |  Christina River                           |  Christina
Q14874579  |  MODvalue  |  name_en     |  Chilako River                             |  Chilako
Q14874579  |  MODvalue  |  name_sv     |  Chilako River                             |  Chilako
Q15111285  |  MODvalue  |  name_de     |  Gauer River                               |  Gauer
Q15111285  |  MODvalue  |  name_en     |  Gauer River                               |  Gauer
Q15111285  |  MODvalue  |  name_nl     |  Gauer River                               |  Gauer
Q15111285  |  MODvalue  |  name_sv     |  Gauer River                               |  Gauer
Q7114861   |  MODvalue  |  name_en     |  Owl River                                 |  Owl
Q7114861   |  MODvalue  |  name_nl     |  Owl River                                 |  Owl
Q7114861   |  MODvalue  |  name_sv     |  Owl River                                 |  Owl
Q616784    |  MODvalue  |  name_de     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_en     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_fr     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_nl     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_sv     |  Wabasca River                             |  Wabasca
Q15111285  |  MODvalue  |  name_de     |  Gauer River                               |  Gauer
Q15111285  |  MODvalue  |  name_en     |  Gauer River                               |  Gauer
Q15111285  |  MODvalue  |  name_nl     |  Gauer River                               |  Gauer
Q15111285  |  MODvalue  |  name_sv     |  Gauer River                               |  Gauer
Q860143    |  MODvalue  |  name_en     |  Little Mecatina River                     |  Little Mecatina
Q22549060  |  MODvalue  |  name_nl     |  Little Beaver River                       |  Little Beaver
Q22549060  |  MODvalue  |  name_sv     |  Little Beaver River                       |  Little Beaver
Q14612484  |  MODvalue  |  name_de     |  Christina River                           |  Christina
Q14612484  |  MODvalue  |  name_en     |  Christina River                           |  Christina
Q14612484  |  MODvalue  |  name_fr     |  Christina River                           |  Christina
Q1336214   |  MODvalue  |  name_de     |  Wapiti River                              |  Wapiti
Q1336214   |  MODvalue  |  name_en     |  Wapiti River                              |  Wapiti
Q1336214   |  MODvalue  |  name_fr     |  Wapiti River                              |  Wapiti
Q1336214   |  NEWvalue  |  name_it     |                                            |  Wapiti
Q1336214   |  MODvalue  |  name_nl     |  Wapiti River                              |  Wapiti
Q1336214   |  NEWvalue  |  name_sv     |                                            |  Wapiti
Q6651973   |  MODvalue  |  name_de     |  Little Smoky River                        |  Little Smoky
Q6651973   |  MODvalue  |  name_en     |  Little Smoky River                        |  Little Smoky
Q6651973   |  MODvalue  |  name_sv     |  Little Smoky River                        |  Little Smoky
Q616784    |  MODvalue  |  name_de     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_en     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_fr     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_nl     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_sv     |  Wabasca River                             |  Wabasca
Q22649147  |  MODvalue  |  name_en     |  Hughes River                              |  Hughes
Q22649147  |  MODvalue  |  name_nl     |  Hughes River                              |  Hughes
Q22649147  |  MODvalue  |  name_sv     |  Hughes River                              |  Hughes
Q280019    |  MODvalue  |  name_de     |  Salmon River                              |  Salmon
Q280019    |  MODvalue  |  name_en     |  Salmon River                              |  Salmon
Q1551634   |  MODvalue  |  name_de     |  Smoky River                               |  Smoky
Q1551634   |  MODvalue  |  name_en     |  Smoky River                               |  Smoky
Q1551634   |  MODvalue  |  name_hu     |  Smoky River                               |  Smoky
Q1551634   |  NEWvalue  |  name_it     |                                            |  Smoky
Q1551634   |  NEWvalue  |  name_ja     |                                            |  スモーキー川
Q1551634   |  MODvalue  |  name_sv     |  Smoky River                               |  Smoky
Q1551634   |  MODvalue  |  name_de     |  Smoky River                               |  Smoky
Q1551634   |  MODvalue  |  name_en     |  Smoky River                               |  Smoky
Q1551634   |  MODvalue  |  name_hu     |  Smoky River                               |  Smoky
Q1551634   |  NEWvalue  |  name_it     |                                            |  Smoky
Q1551634   |  NEWvalue  |  name_ja     |                                            |  スモーキー川
Q1551634   |  MODvalue  |  name_sv     |  Smoky River                               |  Smoky
Q15109240  |  MODvalue  |  name_de     |  Deer River                                |  Deer
Q15109240  |  MODvalue  |  name_en     |  Deer River                                |  Deer
Q1229773   |  MODvalue  |  name_en     |  Saint-Augustin River                      |  Saint-Augustin
Q1099574   |  MODvalue  |  name_de     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_en     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_nl     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_sv     |  Clearwater River                          |  Clearwater
Q270445    |  MODvalue  |  name_en     |  Kitlope River                             |  Kitlope
Q270445    |  MODvalue  |  name_sv     |  Kitlope River                             |  Kitlope
Q270479    |  MODvalue  |  name_de     |  Parsnip River                             |  Parsnip
Q270479    |  MODvalue  |  name_en     |  Parsnip River                             |  Parsnip
Q270479    |  MODvalue  |  name_fr     |  Parsnip River                             |  Parsnip
Q270479    |  MODvalue  |  name_nl     |  Parsnip River                             |  Parsnip
Q270479    |  MODvalue  |  name_sv     |  Parsnip River                             |  Parsnip
Q616784    |  MODvalue  |  name_de     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_en     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_fr     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_nl     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_sv     |  Wabasca River                             |  Wabasca
Q22633098  |  MODvalue  |  name_sv     |  Murray River                              |  Murray
Q553334    |  MODvalue  |  name_de     |  Stuart River                              |  Stuart
Q553334    |  MODvalue  |  name_en     |  Stuart River                              |  Stuart
Q17059760  |  MODvalue  |  name_en     |  Tezwa River                               |  Tezwa
Q17059760  |  MODvalue  |  name_sv     |  Tezwa River                               |  Tezwa
Q5187841   |  MODvalue  |  name_de     |  Crooked River                             |  Crooked
Q5187841   |  MODvalue  |  name_en     |  Crooked River                             |  Crooked
Q5187841   |  MODvalue  |  name_sv     |  Crooked River                             |  Crooked
Q1099574   |  MODvalue  |  name_de     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_en     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_nl     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_sv     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_de     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_en     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_nl     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_sv     |  Clearwater River                          |  Clearwater
Q616784    |  MODvalue  |  name_de     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_en     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_fr     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_nl     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_sv     |  Wabasca River                             |  Wabasca
Q269551    |  MODvalue  |  name_de     |  Kiskatinaw River                          |  Kiskatinaw
Q269551    |  MODvalue  |  name_en     |  Kiskatinaw River                          |  Kiskatinaw
Q269551    |  MODvalue  |  name_sv     |  Kiskatinaw River                          |  Kiskatinaw
Q1551634   |  MODvalue  |  name_de     |  Smoky River                               |  Smoky
Q1551634   |  MODvalue  |  name_en     |  Smoky River                               |  Smoky
Q1551634   |  MODvalue  |  name_hu     |  Smoky River                               |  Smoky
Q1551634   |  NEWvalue  |  name_it     |                                            |  Smoky
Q1551634   |  NEWvalue  |  name_ja     |                                            |  スモーキー川
Q1551634   |  MODvalue  |  name_sv     |  Smoky River                               |  Smoky
Q15130785  |  MODvalue  |  name_de     |  Sukunka River                             |  Sukunka
Q22499146  |  MODvalue  |  name_en     |  Metchin River                             |  Metchin
Q22499146  |  MODvalue  |  name_nl     |  Metchin River                             |  Metchin
Q22499146  |  MODvalue  |  name_sv     |  Metchin River                             |  Metchin
Q15128873  |  MODvalue  |  name_de     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_en     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_it     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_nl     |  South Seal River                          |  South Seal
Q22620185  |  MODvalue  |  name_nl     |  MacKay River                              |  MacKay
Q22620185  |  MODvalue  |  name_sv     |  MacKay River                              |  MacKay
Q15842570  |  MODvalue  |  name_en     |  Delay River                               |  Delay
Q18150029  |  MODvalue  |  name_de     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_en     |  Cochrane River                            |  Cochrane
Q15128873  |  MODvalue  |  name_de     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_en     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_it     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_nl     |  South Seal River                          |  South Seal
Q280019    |  MODvalue  |  name_de     |  Salmon River                              |  Salmon
Q280019    |  MODvalue  |  name_en     |  Salmon River                              |  Salmon
Q1840418   |  MODvalue  |  name_de     |  Firebag River                             |  Firebag
Q1840418   |  MODvalue  |  name_en     |  Firebag River                             |  Firebag
Q1840418   |  MODvalue  |  name_sv     |  Firebag River                             |  Firebag
Q1099574   |  MODvalue  |  name_de     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_en     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_nl     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_sv     |  Clearwater River                          |  Clearwater
Q5016581   |  MODvalue  |  name_en     |  Cadotte River                             |  Cadotte
Q5016581   |  MODvalue  |  name_sv     |  Cadotte River                             |  Cadotte
Q208959    |  MODvalue  |  name_en     |  Nastapoka River                           |  Nastapoka
Q22659004  |  MODvalue  |  name_sv     |  Loon River                                |  Loon
Q1099574   |  MODvalue  |  name_de     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_en     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_nl     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_sv     |  Clearwater River                          |  Clearwater
Q15842603  |  MODvalue  |  name_en     |  Swampy Bay River                          |  Swampy Bay
Q1521554   |  MODvalue  |  name_en     |  Pons River                                |  Pons
Q15842577  |  MODvalue  |  name_en     |  Goodwood River                            |  Goodwood
Q15126104  |  MODvalue  |  name_de     |  Richardson River                          |  Richardson
Q2386767   |  MODvalue  |  name_de     |  Tachie River                              |  Tachie
Q2386767   |  NEWvalue  |  name_en     |                                            |  Tachie
Q2386767   |  NEWvalue  |  name_sv     |                                            |  Tachie
Q1276816   |  MODvalue  |  name_de     |  Eagle River                               |  Eagle
Q1276816   |  MODvalue  |  name_en     |  Eagle River                               |  Eagle
Q22563035  |  MODvalue  |  name_en     |  Kuzkwa River                              |  Kuzkwa
Q22563035  |  MODvalue  |  name_nl     |  Kuzkwa River                              |  Kuzkwa
Q22563035  |  MODvalue  |  name_sv     |  Kuzkwa River                              |  Kuzkwa
Q813500    |  MODvalue  |  name_de     |  Beaver River                              |  Beaver
Q813500    |  MODvalue  |  name_en     |  Beaver River                              |  Beaver
Q813500    |  MODvalue  |  name_nl     |  Beaver River                              |  Beaver
Q15124855  |  MODvalue  |  name_de     |  Pine River                                |  Pine
Q15124855  |  MODvalue  |  name_en     |  Pine River                                |  Pine
Q15124855  |  MODvalue  |  name_de     |  Pine River                                |  Pine
Q15124855  |  MODvalue  |  name_en     |  Pine River                                |  Pine
Q15124855  |  MODvalue  |  name_de     |  Pine River                                |  Pine
Q15124855  |  MODvalue  |  name_en     |  Pine River                                |  Pine
Q270955    |  MODvalue  |  name_de     |  Bulkley River                             |  Bulkley
Q270955    |  MODvalue  |  name_en     |  Bulkley River                             |  Bulkley
Q270955    |  MODvalue  |  name_sv     |  Bulkley River                             |  Bulkley
Q15128873  |  MODvalue  |  name_de     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_en     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_it     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_nl     |  South Seal River                          |  South Seal
Q22509169  |  MODvalue  |  name_en     |  Mikkwa River                              |  Mikkwa
Q22509169  |  MODvalue  |  name_nl     |  Mikkwa River                              |  Mikkwa
Q22509169  |  MODvalue  |  name_sv     |  Mikkwa River                              |  Mikkwa
Q1414492   |  MODvalue  |  name_de     |  Naskaupi River                            |  Naskaupi
Q1414492   |  MODvalue  |  name_en     |  Naskaupi River                            |  Naskaupi
Q1414492   |  MODvalue  |  name_nl     |  Naskaupi River                            |  Naskaupi
Q1414492   |  MODvalue  |  name_sv     |  Naskaupi River                            |  Naskaupi
Q2386767   |  MODvalue  |  name_de     |  Tachie River                              |  Tachie
Q2386767   |  NEWvalue  |  name_en     |                                            |  Tachie
Q2386767   |  NEWvalue  |  name_sv     |                                            |  Tachie
Q72063     |  MODvalue  |  name_de     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_en     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_it     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_nl     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_sv     |  Seal River                                |  Seal
Q266877    |  MODvalue  |  name_de     |  Morice River                              |  Morice
Q266877    |  MODvalue  |  name_en     |  Morice River                              |  Morice
Q266877    |  MODvalue  |  name_sv     |  Morice River                              |  Morice
Q616784    |  MODvalue  |  name_de     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_en     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_fr     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_nl     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_sv     |  Wabasca River                             |  Wabasca
Q15123008  |  MODvalue  |  name_de     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_en     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_nl     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_sv     |  North Seal River                          |  North Seal
Q15842603  |  MODvalue  |  name_en     |  Swampy Bay River                          |  Swampy Bay
Q72063     |  MODvalue  |  name_de     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_en     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_it     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_nl     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_sv     |  Seal River                                |  Seal
Q15123008  |  MODvalue  |  name_de     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_en     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_nl     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_sv     |  North Seal River                          |  North Seal
Q4877304   |  MODvalue  |  name_de     |  Beatton River                             |  Beatton
Q4877304   |  MODvalue  |  name_en     |  Beatton River                             |  Beatton
Q4877304   |  MODvalue  |  name_sv     |  Beatton River                             |  Beatton
Q72063     |  MODvalue  |  name_de     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_en     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_it     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_nl     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_sv     |  Seal River                                |  Seal
Q268946    |  MODvalue  |  name_de     |  Middle River                              |  Middle
Q268946    |  MODvalue  |  name_en     |  Middle River                              |  Middle
Q268946    |  MODvalue  |  name_fr     |  Middle River                              |  Middle
Q268946    |  MODvalue  |  name_nl     |  Middle River                              |  Middle
Q268946    |  MODvalue  |  name_sv     |  Middle River                              |  Middle
Q15107689  |  MODvalue  |  name_de     |  Birch River                               |  Birch
Q270955    |  MODvalue  |  name_de     |  Bulkley River                             |  Bulkley
Q270955    |  MODvalue  |  name_en     |  Bulkley River                             |  Bulkley
Q270955    |  MODvalue  |  name_sv     |  Bulkley River                             |  Bulkley
Q15135332  |  MODvalue  |  name_de     |  Wolverine River                           |  Wolverine
Q15135332  |  MODvalue  |  name_en     |  Wolverine River                           |  Wolverine
Q15135332  |  MODvalue  |  name_sv     |  Wolverine River                           |  Wolverine
Q268946    |  MODvalue  |  name_de     |  Middle River                              |  Middle
Q268946    |  MODvalue  |  name_en     |  Middle River                              |  Middle
Q268946    |  MODvalue  |  name_fr     |  Middle River                              |  Middle
Q268946    |  MODvalue  |  name_nl     |  Middle River                              |  Middle
Q268946    |  MODvalue  |  name_sv     |  Middle River                              |  Middle
Q22473364  |  MODvalue  |  name_de     |  Badwater River                            |  Badwater
Q22473364  |  MODvalue  |  name_en     |  Badwater River                            |  Badwater
Q22473364  |  MODvalue  |  name_nl     |  Badwater River                            |  Badwater
Q22473364  |  MODvalue  |  name_sv     |  Badwater River                            |  Badwater
Q72063     |  MODvalue  |  name_de     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_en     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_it     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_nl     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_sv     |  Seal River                                |  Seal
Q2155753   |  MODvalue  |  name_en     |  Wheeler River                             |  Wheeler
Q20050589  |  MODvalue  |  name_en     |  De Pas River                              |  De Pas
Q15123008  |  MODvalue  |  name_de     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_en     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_nl     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_sv     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_de     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_en     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_nl     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_sv     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_de     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_en     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_nl     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_sv     |  North Seal River                          |  North Seal
Q270409    |  MODvalue  |  name_de     |  Kitimat River                             |  Kitimat
Q270409    |  MODvalue  |  name_en     |  Kitimat River                             |  Kitimat
Q270409    |  MODvalue  |  name_sv     |  Kitimat River                             |  Kitimat
Q18150029  |  MODvalue  |  name_de     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_en     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_de     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_en     |  Cochrane River                            |  Cochrane
Q22385729  |  MODvalue  |  name_en     |  Alexis River                              |  Alexis
Q22385729  |  MODvalue  |  name_nl     |  Alexis River                              |  Alexis
Q22385729  |  MODvalue  |  name_sv     |  Alexis River                              |  Alexis
Q1276816   |  MODvalue  |  name_de     |  Eagle River                               |  Eagle
Q1276816   |  MODvalue  |  name_en     |  Eagle River                               |  Eagle
Q1276816   |  MODvalue  |  name_de     |  Eagle River                               |  Eagle
Q1276816   |  MODvalue  |  name_en     |  Eagle River                               |  Eagle
Q1276816   |  MODvalue  |  name_de     |  Eagle River                               |  Eagle
Q1276816   |  MODvalue  |  name_en     |  Eagle River                               |  Eagle
Q15391863  |  MODvalue  |  name_de     |  Kanairiktok River                         |  Kanairiktok
Q15391863  |  MODvalue  |  name_de     |  Kanairiktok River                         |  Kanairiktok
Q7063039   |  MODvalue  |  name_en     |  Notikewin River                           |  Notikewin
Q7063039   |  MODvalue  |  name_nl     |  Notikewin River                           |  Notikewin
Q7063039   |  MODvalue  |  name_sv     |  Notikewin River                           |  Notikewin
Q1414492   |  MODvalue  |  name_de     |  Naskaupi River                            |  Naskaupi
Q1414492   |  MODvalue  |  name_en     |  Naskaupi River                            |  Naskaupi
Q1414492   |  MODvalue  |  name_nl     |  Naskaupi River                            |  Naskaupi
Q1414492   |  MODvalue  |  name_sv     |  Naskaupi River                            |  Naskaupi
Q2155722   |  MODvalue  |  name_en     |  George River                              |  George
Q18150029  |  MODvalue  |  name_de     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_en     |  Cochrane River                            |  Cochrane
Q15135332  |  MODvalue  |  name_de     |  Wolverine River                           |  Wolverine
Q15135332  |  MODvalue  |  name_en     |  Wolverine River                           |  Wolverine
Q15135332  |  MODvalue  |  name_sv     |  Wolverine River                           |  Wolverine
Q18150029  |  MODvalue  |  name_de     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_en     |  Cochrane River                            |  Cochrane
Q1414492   |  MODvalue  |  name_de     |  Naskaupi River                            |  Naskaupi
Q1414492   |  MODvalue  |  name_en     |  Naskaupi River                            |  Naskaupi
Q1414492   |  MODvalue  |  name_nl     |  Naskaupi River                            |  Naskaupi
Q1414492   |  MODvalue  |  name_sv     |  Naskaupi River                            |  Naskaupi
Q5187841   |  MODvalue  |  name_de     |  Crooked River                             |  Crooked
Q5187841   |  MODvalue  |  name_en     |  Crooked River                             |  Crooked
Q5187841   |  MODvalue  |  name_sv     |  Crooked River                             |  Crooked
Q15123008  |  MODvalue  |  name_de     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_en     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_nl     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_sv     |  North Seal River                          |  North Seal
Q18150029  |  MODvalue  |  name_de     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_en     |  Cochrane River                            |  Cochrane
Q15108141  |  MODvalue  |  name_de     |  Buffalo River                             |  Buffalo
Q15108141  |  MODvalue  |  name_en     |  Buffalo River                             |  Buffalo
Q269567    |  MODvalue  |  name_de     |  Halfway River                             |  Halfway
Q269567    |  MODvalue  |  name_en     |  Halfway River                             |  Halfway
Q269567    |  MODvalue  |  name_sv     |  Halfway River                             |  Halfway
Q20054135  |  MODvalue  |  name_en     |  Aigneau River                             |  Aigneau
Q20054135  |  MODvalue  |  name_nl     |  Aigneau River                             |  Aigneau
Q20054135  |  NEWvalue  |  name_sv     |                                            |  Rivière Aigneau
Q2155722   |  MODvalue  |  name_en     |  George River                              |  George
Q19934983  |  MODvalue  |  name_en     |  Qikirtaluup Kuunga River                  |  Qikirtaluup Kuunga
Q15108619  |  MODvalue  |  name_de     |  Caribou River                             |  Caribou
Q8075927   |  MODvalue  |  name_en     |  Zymoetz River                             |  Zymoetz
Q8075927   |  MODvalue  |  name_sv     |  Zymoetz River                             |  Zymoetz
Q1139466   |  MODvalue  |  name_de     |  Cree River                                |  Cree
Q1139466   |  MODvalue  |  name_en     |  Cree River                                |  Cree
Q1139466   |  NEWvalue  |  name_ja     |                                            |  クリー川
Q2155722   |  MODvalue  |  name_en     |  George River                              |  George
Q15842603  |  MODvalue  |  name_en     |  Swampy Bay River                          |  Swampy Bay
Q15391863  |  MODvalue  |  name_de     |  Kanairiktok River                         |  Kanairiktok
Q72075     |  MODvalue  |  name_de     |  Thlewiaza River                           |  Thlewiaza
Q72075     |  NEWvalue  |  name_en     |                                            |  Thlewiaza
Q2155722   |  MODvalue  |  name_en     |  George River                              |  George
Q43990     |  MODvalue  |  name_en     |  Caniapiscau River                         |  Caniapiscau
Q2216      |  MODvalue  |  name_de     |  Athabasca River                           |  Athabasca
Q2216      |  MODvalue  |  name_en     |  Athabasca River                           |  Athabasca
Q15391847  |  MODvalue  |  name_de     |  Kaipokok River                            |  Kaipokok
Q270894    |  MODvalue  |  name_de     |  Omineca River                             |  Omineca
Q270894    |  MODvalue  |  name_en     |  Omineca River                             |  Omineca
Q270894    |  MODvalue  |  name_sv     |  Omineca River                             |  Omineca
Q15391863  |  MODvalue  |  name_de     |  Kanairiktok River                         |  Kanairiktok
Q15842603  |  MODvalue  |  name_en     |  Swampy Bay River                          |  Swampy Bay
Q269567    |  MODvalue  |  name_de     |  Halfway River                             |  Halfway
Q269567    |  MODvalue  |  name_en     |  Halfway River                             |  Halfway
Q269567    |  MODvalue  |  name_sv     |  Halfway River                             |  Halfway
Q1074554   |  MODvalue  |  name_de     |  Chipman River                             |  Chipman
Q1074554   |  MODvalue  |  name_en     |  Chipman River                             |  Chipman
Q1074554   |  MODvalue  |  name_nl     |  Chipman River                             |  Chipman
Q1074554   |  MODvalue  |  name_sv     |  Chipman River                             |  Chipman
Q5100295   |  MODvalue  |  name_en     |  Chinchaga River                           |  Chinchaga
Q5100295   |  MODvalue  |  name_sv     |  Chinchaga River                           |  Chinchaga
Q15120122  |  MODvalue  |  name_de     |  Mesilinka River                           |  Mesilinka
Q15120122  |  MODvalue  |  name_en     |  Mesilinka River                           |  Mesilinka
Q15120122  |  MODvalue  |  name_sv     |  Mesilinka River                           |  Mesilinka
Q20054135  |  MODvalue  |  name_en     |  Aigneau River                             |  Aigneau
Q20054135  |  MODvalue  |  name_nl     |  Aigneau River                             |  Aigneau
Q20054135  |  NEWvalue  |  name_sv     |                                            |  Rivière Aigneau
Q270412    |  MODvalue  |  name_de     |  Ospika River                              |  Ospika
Q270412    |  MODvalue  |  name_en     |  Ospika River                              |  Ospika
Q270412    |  MODvalue  |  name_sv     |  Ospika River                              |  Ospika
Q19935808  |  MODvalue  |  name_en     |  Koktac River                              |  Koktac
Q22503588  |  MODvalue  |  name_en     |  Kahntah River                             |  Kahntah
Q22503588  |  MODvalue  |  name_nl     |  Kahntah River                             |  Kahntah
Q22503588  |  MODvalue  |  name_sv     |  Kahntah River                             |  Kahntah
Q2155674   |  MODvalue  |  name_en     |  False River                               |  False
Q217670    |  MODvalue  |  name_en     |  Kogaluc River                             |  Kogaluc
Q268666    |  MODvalue  |  name_de     |  Nass River                                |  Nass
Q268666    |  MODvalue  |  name_en     |  Nass River                                |  Nass
Q268666    |  MODvalue  |  name_nl     |  Nass River                                |  Nass
Q268666    |  MODvalue  |  name_sv     |  Nass River                                |  Nass
Q266899    |  MODvalue  |  name_de     |  Fontas River                              |  Fontas
Q266899    |  MODvalue  |  name_en     |  Fontas River                              |  Fontas
Q266899    |  MODvalue  |  name_sv     |  Fontas River                              |  Fontas
Q280106    |  MODvalue  |  name_de     |  Sikanni Chief River                       |  Sikanni Chief
Q280106    |  MODvalue  |  name_en     |  Sikanni Chief River                       |  Sikanni Chief
Q280106    |  MODvalue  |  name_sv     |  Sikanni Chief River                       |  Sikanni Chief
Q2397964   |  MODvalue  |  name_de     |  Tazin River                               |  Tazin
Q2397964   |  MODvalue  |  name_en     |  Tazin River                               |  Tazin
Q217663    |  MODvalue  |  name_de     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_en     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_nl     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_sv     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_de     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_en     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_nl     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_sv     |  Tha-anne River                            |  Tha-anne
Q1690616   |  MODvalue  |  name_en     |  Qurlutuq River                            |  Qurlutuq
Q22607981  |  MODvalue  |  name_sv     |  Hay River                                 |  Hay
Q15115530  |  MODvalue  |  name_de     |  Ingenika River                            |  Ingenika
Q15115530  |  MODvalue  |  name_en     |  Ingenika River                            |  Ingenika
Q15115530  |  MODvalue  |  name_sv     |  Ingenika River                            |  Ingenika
Q2397964   |  MODvalue  |  name_de     |  Tazin River                               |  Tazin
Q2397964   |  MODvalue  |  name_en     |  Tazin River                               |  Tazin
Q22353147  |  MODvalue  |  name_en     |  Abitau River                              |  Abitau
Q22353147  |  MODvalue  |  name_sv     |  Abitau River                              |  Abitau
Q2155693   |  MODvalue  |  name_en     |  Marralik River                            |  Marralik
Q7649744   |  MODvalue  |  name_de     |  Sustut River                              |  Sustut
Q7649744   |  MODvalue  |  name_en     |  Sustut River                              |  Sustut
Q7649744   |  MODvalue  |  name_sv     |  Sustut River                              |  Sustut
Q217670    |  MODvalue  |  name_en     |  Kogaluc River                             |  Kogaluc
Q126153    |  MODvalue  |  name_en     |  Arnaud River                              |  Arnaud
Q15842573  |  MODvalue  |  name_en     |  Falcoz River                              |  Falcoz
Q217670    |  MODvalue  |  name_en     |  Kogaluc River                             |  Kogaluc
Q217663    |  MODvalue  |  name_de     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_en     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_nl     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_sv     |  Tha-anne River                            |  Tha-anne
Q719436    |  MODvalue  |  name_de     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_en     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_nl     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_sv     |  Kazan River                               |  Kazan
Q15108141  |  MODvalue  |  name_de     |  Buffalo River                             |  Buffalo
Q15108141  |  MODvalue  |  name_en     |  Buffalo River                             |  Buffalo
Q217670    |  MODvalue  |  name_en     |  Kogaluc River                             |  Kogaluc
Q2155693   |  MODvalue  |  name_en     |  Marralik River                            |  Marralik
Q15118712  |  MODvalue  |  name_de     |  Little Buffalo River                      |  Little Buffalo
Q15118712  |  MODvalue  |  name_en     |  Little Buffalo River                      |  Little Buffalo
Q217663    |  MODvalue  |  name_de     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_en     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_nl     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_sv     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_de     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_en     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_nl     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_sv     |  Tha-anne River                            |  Tha-anne
Q260158    |  MODvalue  |  name_de     |  Prophet River                             |  Prophet
Q260158    |  MODvalue  |  name_en     |  Prophet River                             |  Prophet
Q260158    |  MODvalue  |  name_sv     |  Prophet River                             |  Prophet
Q1163523   |  MODvalue  |  name_de     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_en     |  Dubawnt River                             |  Dubawnt
Q22607981  |  MODvalue  |  name_sv     |  Hay River                                 |  Hay
Q22607981  |  MODvalue  |  name_sv     |  Hay River                                 |  Hay
Q217663    |  MODvalue  |  name_de     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_en     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_nl     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_sv     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_de     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_en     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_nl     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_sv     |  Tha-anne River                            |  Tha-anne
Q266899    |  MODvalue  |  name_de     |  Fontas River                              |  Fontas
Q266899    |  MODvalue  |  name_en     |  Fontas River                              |  Fontas
Q266899    |  MODvalue  |  name_sv     |  Fontas River                              |  Fontas
Q268666    |  MODvalue  |  name_de     |  Nass River                                |  Nass
Q268666    |  MODvalue  |  name_en     |  Nass River                                |  Nass
Q268666    |  MODvalue  |  name_nl     |  Nass River                                |  Nass
Q268666    |  MODvalue  |  name_sv     |  Nass River                                |  Nass
Q15107466  |  MODvalue  |  name_de     |  Bell-Irving River                         |  Bell-Irving
Q15107466  |  MODvalue  |  name_en     |  Bell-Irving River                         |  Bell-Irving
Q15107466  |  MODvalue  |  name_sv     |  Bell-Irving River                         |  Bell-Irving
Q15117850  |  MODvalue  |  name_de     |  Kwadacha River                            |  Kwadacha
Q15117850  |  MODvalue  |  name_en     |  Kwadacha River                            |  Kwadacha
Q15117850  |  MODvalue  |  name_sv     |  Kwadacha River                            |  Kwadacha
Q15132109  |  MODvalue  |  name_de     |  Thoa River                                |  Thoa
Q15132109  |  MODvalue  |  name_en     |  Thoa River                                |  Thoa
Q15132109  |  MODvalue  |  name_nl     |  Thoa River                                |  Thoa
Q15132109  |  MODvalue  |  name_sv     |  Thoa River                                |  Thoa
Q270574    |  MODvalue  |  name_de     |  Fort Nelson River                         |  Fort Nelson
Q270574    |  MODvalue  |  name_en     |  Fort Nelson River                         |  Fort Nelson
Q270574    |  MODvalue  |  name_es     |  Fort Nelson River                         |  Fort Nelson
Q270574    |  MODvalue  |  name_nl     |  Fort Nelson River                         |  Fort Nelson
Q270574    |  MODvalue  |  name_sv     |  Fort Nelson River                         |  Fort Nelson
Q265803    |  MODvalue  |  name_de     |  Muskwa River                              |  Muskwa
Q265803    |  MODvalue  |  name_en     |  Muskwa River                              |  Muskwa
Q265803    |  MODvalue  |  name_sv     |  Muskwa River                              |  Muskwa
Q1163523   |  MODvalue  |  name_de     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_en     |  Dubawnt River                             |  Dubawnt
Q1690616   |  MODvalue  |  name_en     |  Qurlutuq River                            |  Qurlutuq
Q22554027  |  MODvalue  |  name_en     |  Kotcho River                              |  Kotcho
Q22554027  |  MODvalue  |  name_nl     |  Kotcho River                              |  Kotcho
Q22554027  |  MODvalue  |  name_sv     |  Kotcho River                              |  Kotcho
Q1163523   |  MODvalue  |  name_de     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_en     |  Dubawnt River                             |  Dubawnt
Q2397964   |  MODvalue  |  name_de     |  Tazin River                               |  Tazin
Q2397964   |  MODvalue  |  name_en     |  Tazin River                               |  Tazin
Q2391021   |  MODvalue  |  name_de     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_en     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_nl     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_sv     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_de     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_en     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_nl     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_sv     |  Taltson River                             |  Taltson
Q719436    |  MODvalue  |  name_de     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_en     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_nl     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_sv     |  Kazan River                               |  Kazan
Q7056518   |  MODvalue  |  name_en     |  North River                               |  North
Q15842574  |  MODvalue  |  name_en     |  Ford River                                |  Ford
Q2391021   |  MODvalue  |  name_de     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_en     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_nl     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_sv     |  Taltson River                             |  Taltson
Q20750417  |  MODvalue  |  name_en     |  Sorehead River                            |  Sorehead
Q20750417  |  NEWvalue  |  name_sv     |                                            |  Rivière Sorehead
Q2391021   |  MODvalue  |  name_de     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_en     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_nl     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_sv     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_de     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_en     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_nl     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_sv     |  Taltson River                             |  Taltson
Q270423    |  MODvalue  |  name_de     |  Gataga River                              |  Gataga
Q270423    |  MODvalue  |  name_en     |  Gataga River                              |  Gataga
Q270423    |  MODvalue  |  name_sv     |  Gataga River                              |  Gataga
Q2391021   |  MODvalue  |  name_de     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_en     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_nl     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_sv     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_de     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_en     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_nl     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_sv     |  Taltson River                             |  Taltson
Q644607    |  MODvalue  |  name_de     |  Unuk River                                |  Unuk
Q644607    |  MODvalue  |  name_en     |  Unuk River                                |  Unuk
Q644607    |  MODvalue  |  name_nl     |  Unuk River                                |  Unuk
Q20671938  |  MODvalue  |  name_en     |  Lefroy River                              |  Lefroy
Q20671938  |  MODvalue  |  name_nl     |  Lefroy River                              |  Lefroy
Q265803    |  MODvalue  |  name_de     |  Muskwa River                              |  Muskwa
Q265803    |  MODvalue  |  name_en     |  Muskwa River                              |  Muskwa
Q265803    |  MODvalue  |  name_sv     |  Muskwa River                              |  Muskwa
Q2391021   |  MODvalue  |  name_de     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_en     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_nl     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_sv     |  Taltson River                             |  Taltson
Q270574    |  MODvalue  |  name_de     |  Fort Nelson River                         |  Fort Nelson
Q270574    |  MODvalue  |  name_en     |  Fort Nelson River                         |  Fort Nelson
Q270574    |  MODvalue  |  name_es     |  Fort Nelson River                         |  Fort Nelson
Q270574    |  MODvalue  |  name_nl     |  Fort Nelson River                         |  Fort Nelson
Q270574    |  MODvalue  |  name_sv     |  Fort Nelson River                         |  Fort Nelson
Q270571    |  MODvalue  |  name_de     |  Petitot River                             |  Petitot
Q270571    |  MODvalue  |  name_en     |  Petitot River                             |  Petitot
Q270571    |  MODvalue  |  name_nl     |  Petitot River                             |  Petitot
Q270571    |  MODvalue  |  name_sv     |  Petitot River                             |  Petitot
Q19847205  |  MODvalue  |  name_en     |  Chukotat River                            |  Chukotat
Q19847205  |  MODvalue  |  name_nl     |  Chukotat River                            |  Chukotat
Q15108141  |  MODvalue  |  name_de     |  Buffalo River                             |  Buffalo
Q15108141  |  MODvalue  |  name_en     |  Buffalo River                             |  Buffalo
Q270571    |  MODvalue  |  name_de     |  Petitot River                             |  Petitot
Q270571    |  MODvalue  |  name_en     |  Petitot River                             |  Petitot
Q270571    |  MODvalue  |  name_nl     |  Petitot River                             |  Petitot
Q270571    |  MODvalue  |  name_sv     |  Petitot River                             |  Petitot
Q268222    |  MODvalue  |  name_de     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_en     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_fr     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_nl     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_sv     |  Kechika River                             |  Kechika
Q15126242  |  MODvalue  |  name_en     |  Lepellé River                             |  Lepellé
Q20050874  |  MODvalue  |  name_en     |  Brochant River                            |  Brochant
Q20050874  |  MODvalue  |  name_nl     |  Brochant River                            |  Brochant
Q719436    |  MODvalue  |  name_de     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_en     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_nl     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_sv     |  Kazan River                               |  Kazan
Q1406237   |  MODvalue  |  name_de     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_en     |  Ferguson River                            |  Ferguson
Q2437592   |  MODvalue  |  name_de     |  Toad River                                |  Toad
Q2437592   |  MODvalue  |  name_en     |  Toad River                                |  Toad
Q2437592   |  MODvalue  |  name_fr     |  Toad River                                |  Toad
Q2437592   |  MODvalue  |  name_sv     |  Toad River                                |  Toad
Q268328    |  MODvalue  |  name_de     |  Iskut River                               |  Iskut
Q268328    |  MODvalue  |  name_en     |  Iskut River                               |  Iskut
Q268328    |  MODvalue  |  name_fr     |  Iskut River                               |  Iskut
Q268328    |  MODvalue  |  name_nl     |  Iskut River                               |  Iskut
Q268328    |  MODvalue  |  name_sv     |  Iskut River                               |  Iskut
Q15126242  |  MODvalue  |  name_en     |  Lepellé River                             |  Lepellé
Q22604623  |  MODvalue  |  name_en     |  Dunedin River                             |  Dunedin
Q22604623  |  MODvalue  |  name_nl     |  Dunedin River                             |  Dunedin
Q22604623  |  MODvalue  |  name_sv     |  Dunedin River                             |  Dunedin
Q15842581  |  MODvalue  |  name_en     |  Koroc River                               |  Koroc
Q268328    |  MODvalue  |  name_de     |  Iskut River                               |  Iskut
Q268328    |  MODvalue  |  name_en     |  Iskut River                               |  Iskut
Q268328    |  MODvalue  |  name_fr     |  Iskut River                               |  Iskut
Q268328    |  MODvalue  |  name_nl     |  Iskut River                               |  Iskut
Q268328    |  MODvalue  |  name_sv     |  Iskut River                               |  Iskut
Q7908009   |  MODvalue  |  name_en     |  Vachon River                              |  Vachon
Q126153    |  MODvalue  |  name_en     |  Arnaud River                              |  Arnaud
Q5364109   |  MODvalue  |  name_en     |  Elk River                                 |  Elk
Q5364109   |  MODvalue  |  name_pl     |  Elk River                                 |  Elk
Q1406237   |  MODvalue  |  name_de     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_en     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_de     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_en     |  Ferguson River                            |  Ferguson
Q20011158  |  MODvalue  |  name_en     |  Buet River                                |  Buet
Q20011158  |  MODvalue  |  name_nl     |  Buet River                                |  Buet
Q20011158  |  MODvalue  |  name_en     |  Buet River                                |  Buet
Q20011158  |  MODvalue  |  name_nl     |  Buet River                                |  Buet
Q7908009   |  MODvalue  |  name_en     |  Vachon River                              |  Vachon
Q2391021   |  MODvalue  |  name_de     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_en     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_nl     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_sv     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_de     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_en     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_nl     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_sv     |  Taltson River                             |  Taltson
Q1406237   |  MODvalue  |  name_de     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_en     |  Ferguson River                            |  Ferguson
Q6349481   |  MODvalue  |  name_de     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_en     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_sv     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_de     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_en     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_sv     |  Kakisa River                              |  Kakisa
Q15125737  |  MODvalue  |  name_de     |  Rabbit River                              |  Rabbit
Q15125737  |  MODvalue  |  name_en     |  Rabbit River                              |  Rabbit
Q268222    |  MODvalue  |  name_de     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_en     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_fr     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_nl     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_sv     |  Kechika River                             |  Kechika
Q1795069   |  MODvalue  |  name_en     |  Kovik River                               |  Kovik
Q15842562  |  MODvalue  |  name_en     |  Alluviaq River                            |  Alluviaq
Q1795069   |  MODvalue  |  name_en     |  Kovik River                               |  Kovik
Q6349481   |  MODvalue  |  name_de     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_en     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_sv     |  Kakisa River                              |  Kakisa
Q1406237   |  MODvalue  |  name_de     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_en     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_de     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_en     |  Ferguson River                            |  Ferguson
Q1795069   |  MODvalue  |  name_en     |  Kovik River                               |  Kovik
Q22635897  |  MODvalue  |  name_sv     |  Muskeg River                              |  Muskeg
Q270571    |  MODvalue  |  name_de     |  Petitot River                             |  Petitot
Q270571    |  MODvalue  |  name_en     |  Petitot River                             |  Petitot
Q270571    |  MODvalue  |  name_nl     |  Petitot River                             |  Petitot
Q270571    |  MODvalue  |  name_sv     |  Petitot River                             |  Petitot
Q7855807   |  MODvalue  |  name_de     |  Turnagain River                           |  Turnagain
Q7855807   |  MODvalue  |  name_en     |  Turnagain River                           |  Turnagain
Q7855807   |  MODvalue  |  name_sv     |  Turnagain River                           |  Turnagain
Q19986116  |  MODvalue  |  name_en     |  Latourette River                          |  Latourette
Q19986116  |  MODvalue  |  name_nl     |  Latourette River                          |  Latourette
Q4878156   |  MODvalue  |  name_de     |  Beaver River                              |  Beaver
Q4878156   |  MODvalue  |  name_en     |  Beaver River                              |  Beaver
Q4878156   |  MODvalue  |  name_sv     |  Beaver River                              |  Beaver
Q22566721  |  MODvalue  |  name_sv     |  La Biche River                            |  La Biche
Q7846618   |  MODvalue  |  name_de     |  Trout River                               |  Trout
Q7846618   |  MODvalue  |  name_en     |  Trout River                               |  Trout
Q7846618   |  MODvalue  |  name_sv     |  Trout River                               |  Trout
Q268222    |  MODvalue  |  name_de     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_en     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_fr     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_nl     |  Kechika River                             |  Kechika
Q268222    |  MODvalue  |  name_sv     |  Kechika River                             |  Kechika
Q7545292   |  MODvalue  |  name_de     |  Smith River                               |  Smith
Q7545292   |  MODvalue  |  name_en     |  Smith River                               |  Smith
Q7545292   |  MODvalue  |  name_sv     |  Smith River                               |  Smith
Q270283    |  MODvalue  |  name_de     |  Dease River                               |  Dease
Q270283    |  MODvalue  |  name_en     |  Dease River                               |  Dease
Q270283    |  MODvalue  |  name_sv     |  Dease River                               |  Dease
Q5903970   |  MODvalue  |  name_de     |  Horn River                                |  Horn
Q5903970   |  MODvalue  |  name_en     |  Horn River                                |  Horn
Q5903970   |  MODvalue  |  name_sv     |  Horn River                                |  Horn
Q22629110  |  MODvalue  |  name_en     |  Hoarfrost River                           |  Hoarfrost
Q22629110  |  MODvalue  |  name_nl     |  Hoarfrost River                           |  Hoarfrost
Q22629110  |  MODvalue  |  name_sv     |  Hoarfrost River                           |  Hoarfrost
Q270502    |  MODvalue  |  name_de     |  Inklin River                              |  Inklin
Q270502    |  MODvalue  |  name_en     |  Inklin River                              |  Inklin
Q270502    |  MODvalue  |  name_sv     |  Inklin River                              |  Inklin
Q268335    |  MODvalue  |  name_de     |  Coal River                                |  Coal
Q268335    |  MODvalue  |  name_en     |  Coal River                                |  Coal
Q268335    |  MODvalue  |  name_sv     |  Coal River                                |  Coal
Q7229424   |  MODvalue  |  name_en     |  Poplar River                              |  Poplar
Q7229424   |  MODvalue  |  name_fr     |  Poplar River                              |  Poplar
Q1163523   |  MODvalue  |  name_de     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_en     |  Dubawnt River                             |  Dubawnt
Q719436    |  MODvalue  |  name_de     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_en     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_nl     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_sv     |  Kazan River                               |  Kazan
Q5903970   |  MODvalue  |  name_de     |  Horn River                                |  Horn
Q5903970   |  MODvalue  |  name_en     |  Horn River                                |  Horn
Q5903970   |  MODvalue  |  name_sv     |  Horn River                                |  Horn
Q5903970   |  MODvalue  |  name_de     |  Horn River                                |  Horn
Q5903970   |  MODvalue  |  name_en     |  Horn River                                |  Horn
Q5903970   |  MODvalue  |  name_sv     |  Horn River                                |  Horn
Q1163523   |  MODvalue  |  name_de     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_en     |  Dubawnt River                             |  Dubawnt
Q187803    |  MODvalue  |  name_de     |  Yellowknife River                         |  Yellowknife
Q187803    |  MODvalue  |  name_en     |  Yellowknife River                         |  Yellowknife
Q187803    |  MODvalue  |  name_sv     |  Yellowknife River                         |  Yellowknife
Q1163523   |  MODvalue  |  name_de     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_en     |  Dubawnt River                             |  Dubawnt
Q187803    |  MODvalue  |  name_de     |  Yellowknife River                         |  Yellowknife
Q187803    |  MODvalue  |  name_en     |  Yellowknife River                         |  Yellowknife
Q187803    |  MODvalue  |  name_sv     |  Yellowknife River                         |  Yellowknife
Q1867521   |  MODvalue  |  name_de     |  Lockhart River                            |  Lockhart
Q1867521   |  MODvalue  |  name_en     |  Lockhart River                            |  Lockhart
Q1867521   |  MODvalue  |  name_sv     |  Lockhart River                            |  Lockhart
Q1163523   |  MODvalue  |  name_de     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_en     |  Dubawnt River                             |  Dubawnt
Q268335    |  MODvalue  |  name_de     |  Coal River                                |  Coal
Q268335    |  MODvalue  |  name_en     |  Coal River                                |  Coal
Q268335    |  MODvalue  |  name_sv     |  Coal River                                |  Coal
Q22468629  |  MODvalue  |  name_en     |  McCrea River                              |  McCrea
Q22468629  |  MODvalue  |  name_nl     |  McCrea River                              |  McCrea
Q22468629  |  MODvalue  |  name_sv     |  McCrea River                              |  McCrea
Q15115326  |  MODvalue  |  name_de     |  Hyland River                              |  Hyland
Q15115326  |  MODvalue  |  name_en     |  Hyland River                              |  Hyland
Q15115326  |  MODvalue  |  name_sv     |  Hyland River                              |  Hyland
Q187803    |  MODvalue  |  name_de     |  Yellowknife River                         |  Yellowknife
Q187803    |  MODvalue  |  name_en     |  Yellowknife River                         |  Yellowknife
Q187803    |  MODvalue  |  name_sv     |  Yellowknife River                         |  Yellowknife
Q2123615   |  MODvalue  |  name_de     |  Quoich River                              |  Quoich
Q2123615   |  NEWvalue  |  name_en     |                                            |  Quoich
Q2123615   |  NEWvalue  |  name_nl     |                                            |  Quoich
Q2123615   |  NEWvalue  |  name_sv     |                                            |  Quoich
Q22468629  |  MODvalue  |  name_en     |  McCrea River                              |  McCrea
Q22468629  |  MODvalue  |  name_nl     |  McCrea River                              |  McCrea
Q22468629  |  MODvalue  |  name_sv     |  McCrea River                              |  McCrea
Q1163523   |  MODvalue  |  name_de     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_en     |  Dubawnt River                             |  Dubawnt
Q15134975  |  MODvalue  |  name_de     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_en     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_nl     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_sv     |  Willowlake River                          |  Willowlake
Q269983    |  MODvalue  |  name_en     |  Little Rancheria River                    |  Little Rancheria
Q269983    |  MODvalue  |  name_sv     |  Little Rancheria River                    |  Little Rancheria
Q2123615   |  MODvalue  |  name_de     |  Quoich River                              |  Quoich
Q2123615   |  NEWvalue  |  name_en     |                                            |  Quoich
Q2123615   |  NEWvalue  |  name_nl     |                                            |  Quoich
Q2123615   |  NEWvalue  |  name_sv     |                                            |  Quoich
Q15134975  |  MODvalue  |  name_de     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_en     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_nl     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_sv     |  Willowlake River                          |  Willowlake
Q2389724   |  MODvalue  |  name_de     |  Taku River                                |  Taku
Q2389724   |  MODvalue  |  name_en     |  Taku River                                |  Taku
Q2389724   |  MODvalue  |  name_nl     |  Taku River                                |  Taku
Q2389724   |  MODvalue  |  name_sv     |  Taku River                                |  Taku
Q5903970   |  MODvalue  |  name_de     |  Horn River                                |  Horn
Q5903970   |  MODvalue  |  name_en     |  Horn River                                |  Horn
Q5903970   |  MODvalue  |  name_sv     |  Horn River                                |  Horn
Q7290792   |  MODvalue  |  name_de     |  Rancheria River                           |  Rancheria
Q7290792   |  MODvalue  |  name_en     |  Rancheria River                           |  Rancheria
Q7290792   |  MODvalue  |  name_sv     |  Rancheria River                           |  Rancheria
Q1867521   |  MODvalue  |  name_de     |  Lockhart River                            |  Lockhart
Q1867521   |  MODvalue  |  name_en     |  Lockhart River                            |  Lockhart
Q1867521   |  MODvalue  |  name_sv     |  Lockhart River                            |  Lockhart
Q2249      |  MODvalue  |  name_de     |  Liard River                               |  Liard
Q2249      |  MODvalue  |  name_en     |  Liard River                               |  Liard
Q2249      |  MODvalue  |  name_sv     |  Liard River                               |  Liard
Q22504785  |  MODvalue  |  name_de     |  Frances River                             |  Frances
Q22504785  |  MODvalue  |  name_en     |  Frances River                             |  Frances
Q22504785  |  MODvalue  |  name_nl     |  Frances River                             |  Frances
Q22504785  |  MODvalue  |  name_sv     |  Frances River                             |  Frances
Q7290792   |  MODvalue  |  name_de     |  Rancheria River                           |  Rancheria
Q7290792   |  MODvalue  |  name_en     |  Rancheria River                           |  Rancheria
Q7290792   |  MODvalue  |  name_sv     |  Rancheria River                           |  Rancheria
Q15128716  |  MODvalue  |  name_de     |  Snare River                               |  Snare
Q1867521   |  MODvalue  |  name_de     |  Lockhart River                            |  Lockhart
Q1867521   |  MODvalue  |  name_en     |  Lockhart River                            |  Lockhart
Q1867521   |  MODvalue  |  name_sv     |  Lockhart River                            |  Lockhart
Q15119414  |  MODvalue  |  name_de     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_en     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_nl     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_sv     |  Marian River                              |  Marian
Q5457781   |  MODvalue  |  name_en     |  Flat River                                |  Flat
Q5457781   |  MODvalue  |  name_nl     |  Flat River                                |  Flat
Q15110758  |  MODvalue  |  name_de     |  Flat River                                |  Flat
Q15134975  |  MODvalue  |  name_de     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_en     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_nl     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_sv     |  Willowlake River                          |  Willowlake
Q15119414  |  MODvalue  |  name_de     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_en     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_nl     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_sv     |  Marian River                              |  Marian
Q15110333  |  MODvalue  |  name_de     |  Emile River                               |  Emile
Q15110333  |  MODvalue  |  name_en     |  Emile River                               |  Emile
Q15110333  |  MODvalue  |  name_nl     |  Emile River                               |  Emile
Q15110333  |  MODvalue  |  name_sv     |  Emile River                               |  Emile
Q2123615   |  MODvalue  |  name_de     |  Quoich River                              |  Quoich
Q2123615   |  NEWvalue  |  name_en     |                                            |  Quoich
Q2123615   |  NEWvalue  |  name_nl     |                                            |  Quoich
Q2123615   |  NEWvalue  |  name_sv     |                                            |  Quoich
Q2372735   |  MODvalue  |  name_de     |  Swift River                               |  Swift
Q2372735   |  MODvalue  |  name_en     |  Swift River                               |  Swift
Q2372735   |  MODvalue  |  name_nl     |  Swift River                               |  Swift
Q2372735   |  MODvalue  |  name_sv     |  Swift River                               |  Swift
Q3439      |  MODvalue  |  name_de     |  North Nahanni River                       |  North Nahanni
Q3439      |  MODvalue  |  name_en     |  North Nahanni River                       |  North Nahanni
Q3439      |  MODvalue  |  name_it     |  North Nahanni River                       |  North Nahanni
Q3439      |  MODvalue  |  name_nl     |  North Nahanni River                       |  North Nahanni
Q3439      |  NEWvalue  |  name_ru     |                                            |  Норт-На­хан­ни
Q3439      |  MODvalue  |  name_sv     |  North Nahanni River                       |  North Nahanni
Q3439      |  MODvalue  |  name_de     |  North Nahanni River                       |  North Nahanni
Q3439      |  MODvalue  |  name_en     |  North Nahanni River                       |  North Nahanni
Q3439      |  MODvalue  |  name_it     |  North Nahanni River                       |  North Nahanni
Q3439      |  MODvalue  |  name_nl     |  North Nahanni River                       |  North Nahanni
Q3439      |  NEWvalue  |  name_ru     |                                            |  Норт-На­хан­ни
Q3439      |  MODvalue  |  name_sv     |  North Nahanni River                       |  North Nahanni
Q15134975  |  MODvalue  |  name_de     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_en     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_nl     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_sv     |  Willowlake River                          |  Willowlake
Q798339    |  MODvalue  |  name_de     |  Back River                                |  Back
Q798339    |  MODvalue  |  name_en     |  Back River                                |  Back
Q798339    |  MODvalue  |  name_nl     |  Back River                                |  Back
Q798339    |  MODvalue  |  name_sv     |  Back River                                |  Back
Q15134975  |  MODvalue  |  name_de     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_en     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_nl     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_sv     |  Willowlake River                          |  Willowlake
Q187803    |  MODvalue  |  name_de     |  Yellowknife River                         |  Yellowknife
Q187803    |  MODvalue  |  name_en     |  Yellowknife River                         |  Yellowknife
Q187803    |  MODvalue  |  name_sv     |  Yellowknife River                         |  Yellowknife
Q1571301   |  MODvalue  |  name_de     |  Soper River                               |  Soper
Q1571301   |  MODvalue  |  name_en     |  Soper River                               |  Soper
Q1571301   |  MODvalue  |  name_nl     |  Soper River                               |  Soper
Q1571301   |  MODvalue  |  name_sv     |  Soper River                               |  Soper
Q15128716  |  MODvalue  |  name_de     |  Snare River                               |  Snare
Q15119414  |  MODvalue  |  name_de     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_en     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_nl     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_sv     |  Marian River                              |  Marian
Q15128716  |  MODvalue  |  name_de     |  Snare River                               |  Snare
Q15126341  |  MODvalue  |  name_de     |  Root River                                |  Root
Q15126341  |  MODvalue  |  name_en     |  Root River                                |  Root
Q15126341  |  MODvalue  |  name_nl     |  Root River                                |  Root
Q15126341  |  MODvalue  |  name_sv     |  Root River                                |  Root
Q2123615   |  MODvalue  |  name_de     |  Quoich River                              |  Quoich
Q2123615   |  NEWvalue  |  name_en     |                                            |  Quoich
Q2123615   |  NEWvalue  |  name_nl     |                                            |  Quoich
Q2123615   |  NEWvalue  |  name_sv     |                                            |  Quoich
Q15128716  |  MODvalue  |  name_de     |  Snare River                               |  Snare
Q15128716  |  MODvalue  |  name_de     |  Snare River                               |  Snare
Q15119414  |  MODvalue  |  name_de     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_en     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_nl     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_sv     |  Marian River                              |  Marian
Q15107756  |  MODvalue  |  name_de     |  Blackwater River                          |  Blackwater
Q15107756  |  MODvalue  |  name_en     |  Blackwater River                          |  Blackwater
Q1332140   |  MODvalue  |  name_de     |  Ellice River                              |  Ellice
Q1332140   |  MODvalue  |  name_en     |  Ellice River                              |  Ellice
Q1332140   |  MODvalue  |  name_nl     |  Ellice River                              |  Ellice
Q1332140   |  MODvalue  |  name_sv     |  Ellice River                              |  Ellice
Q6754521   |  MODvalue  |  name_en     |  Mara River                                |  Mara
Q6754521   |  MODvalue  |  name_sv     |  Mara River                                |  Mara
Q15115769  |  MODvalue  |  name_de     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_en     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_nl     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_sv     |  Johnny Hoe River                          |  Johnny Hoe
Q11849694  |  MODvalue  |  name_de     |  Acasta River                              |  Acasta
Q11849694  |  MODvalue  |  name_en     |  Acasta River                              |  Acasta
Q11849694  |  MODvalue  |  name_sv     |  Acasta River                              |  Acasta
Q16247890  |  MODvalue  |  name_en     |  Kaleet River                              |  Kaleet
Q16247890  |  MODvalue  |  name_sv     |  Kaleet River                              |  Kaleet
Q859207    |  MODvalue  |  name_de     |  Big Salmon River                          |  Big Salmon
Q859207    |  MODvalue  |  name_en     |  Big Salmon River                          |  Big Salmon
Q859207    |  MODvalue  |  name_pl     |  Big Salmon River                          |  Big Salmon
Q23016     |  MODvalue  |  name_de     |  Tatshenshini River                        |  Tatshenshini
Q23016     |  MODvalue  |  name_en     |  Tatshenshini River                        |  Tatshenshini
Q23016     |  MODvalue  |  name_sv     |  Tatshenshini River                        |  Tatshenshini
Q15115769  |  MODvalue  |  name_de     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_en     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_nl     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_sv     |  Johnny Hoe River                          |  Johnny Hoe
Q1031730   |  MODvalue  |  name_de     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_en     |  Camsell river                             |  Camsell
Q1031730   |  MODvalue  |  name_nl     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_sv     |  Camsell River                             |  Camsell
Q22462926  |  MODvalue  |  name_en     |  Aukpar River                              |  Aukpar
Q22462926  |  MODvalue  |  name_nl     |  Aukpar River                              |  Aukpar
Q22462926  |  MODvalue  |  name_sv     |  Aukpar River                              |  Aukpar
Q1898456   |  MODvalue  |  name_de     |  Pelly River                               |  Pelly
Q1898456   |  MODvalue  |  name_en     |  Pelly River                               |  Pelly
Q1898456   |  MODvalue  |  name_nl     |  Pelly River                               |  Pelly
Q1898456   |  MODvalue  |  name_pl     |  Pelly River                               |  Pelly
Q1898456   |  MODvalue  |  name_sv     |  Pelly River                               |  Pelly
Q1591919   |  MODvalue  |  name_de     |  Hayes River                               |  Hayes
Q1591919   |  MODvalue  |  name_en     |  Hayes River                               |  Hayes
Q15107756  |  MODvalue  |  name_de     |  Blackwater River                          |  Blackwater
Q15107756  |  MODvalue  |  name_en     |  Blackwater River                          |  Blackwater
Q1647206   |  MODvalue  |  name_de     |  Perry River                               |  Perry
Q1647206   |  MODvalue  |  name_en     |  Perry River                               |  Perry
Q1647206   |  MODvalue  |  name_fr     |  Perry River                               |  Perry
Q1647206   |  MODvalue  |  name_nl     |  Perry River                               |  Perry
Q1647206   |  MODvalue  |  name_pl     |  Perry River                               |  Perry
Q1647206   |  MODvalue  |  name_sv     |  Perry River                               |  Perry
Q22451403  |  MODvalue  |  name_en     |  Armark River                              |  Armark
Q22451403  |  MODvalue  |  name_nl     |  Armark River                              |  Armark
Q22451403  |  MODvalue  |  name_sv     |  Armark River                              |  Armark
Q15115769  |  MODvalue  |  name_de     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_en     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_nl     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_sv     |  Johnny Hoe River                          |  Johnny Hoe
Q3452      |  MODvalue  |  name_de     |  Redstone River                            |  Redstone
Q3452      |  MODvalue  |  name_en     |  Redstone River                            |  Redstone
Q3452      |  MODvalue  |  name_fr     |  Redstone River                            |  Redstone
Q3452      |  MODvalue  |  name_nl     |  Redstone River                            |  Redstone
Q3452      |  NEWvalue  |  name_ru     |                                            |  Ред­стон
Q3452      |  MODvalue  |  name_de     |  Redstone River                            |  Redstone
Q3452      |  MODvalue  |  name_en     |  Redstone River                            |  Redstone
Q3452      |  MODvalue  |  name_fr     |  Redstone River                            |  Redstone
Q3452      |  MODvalue  |  name_nl     |  Redstone River                            |  Redstone
Q3452      |  NEWvalue  |  name_ru     |                                            |  Ред­стон
Q1591919   |  MODvalue  |  name_de     |  Hayes River                               |  Hayes
Q1591919   |  MODvalue  |  name_en     |  Hayes River                               |  Hayes
Q750009    |  MODvalue  |  name_de     |  Takhini River                             |  Takhini
Q750009    |  MODvalue  |  name_en     |  Takhini River                             |  Takhini
Q750009    |  MODvalue  |  name_pl     |  Takhini River                             |  Takhini
Q750009    |  MODvalue  |  name_sv     |  Takhini River                             |  Takhini
Q1278909   |  MODvalue  |  name_de     |  Ross River                                |  Ross
Q1278909   |  MODvalue  |  name_en     |  Ross River                                |  Ross
Q1278909   |  MODvalue  |  name_nl     |  Ross River                                |  Ross
Q1278909   |  MODvalue  |  name_sv     |  Ross River                                |  Ross
Q15115769  |  MODvalue  |  name_de     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_en     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_nl     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_sv     |  Johnny Hoe River                          |  Johnny Hoe
Q1031730   |  MODvalue  |  name_de     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_en     |  Camsell river                             |  Camsell
Q1031730   |  MODvalue  |  name_nl     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_sv     |  Camsell River                             |  Camsell
Q1591919   |  MODvalue  |  name_de     |  Hayes River                               |  Hayes
Q1591919   |  MODvalue  |  name_en     |  Hayes River                               |  Hayes
Q15115769  |  MODvalue  |  name_de     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_en     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_nl     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_sv     |  Johnny Hoe River                          |  Johnny Hoe
Q3452      |  MODvalue  |  name_de     |  Redstone River                            |  Redstone
Q3452      |  MODvalue  |  name_en     |  Redstone River                            |  Redstone
Q3452      |  MODvalue  |  name_fr     |  Redstone River                            |  Redstone
Q3452      |  MODvalue  |  name_nl     |  Redstone River                            |  Redstone
Q3452      |  NEWvalue  |  name_ru     |                                            |  Ред­стон
Q1031730   |  MODvalue  |  name_de     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_en     |  Camsell river                             |  Camsell
Q1031730   |  MODvalue  |  name_nl     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_sv     |  Camsell River                             |  Camsell
Q15109355  |  MODvalue  |  name_de     |  Dezadeash River                           |  Dezadeash
Q15109355  |  MODvalue  |  name_en     |  Dezadeash River                           |  Dezadeash
Q15109355  |  MODvalue  |  name_nl     |  Dezadeash River                           |  Dezadeash
Q15109355  |  MODvalue  |  name_sv     |  Dezadeash River                           |  Dezadeash
Q1332140   |  MODvalue  |  name_de     |  Ellice River                              |  Ellice
Q1332140   |  MODvalue  |  name_en     |  Ellice River                              |  Ellice
Q1332140   |  MODvalue  |  name_nl     |  Ellice River                              |  Ellice
Q1332140   |  MODvalue  |  name_sv     |  Ellice River                              |  Ellice
Q22454334  |  MODvalue  |  name_en     |  Arrowsmith River                          |  Arrowsmith
Q22454334  |  MODvalue  |  name_nl     |  Arrowsmith River                          |  Arrowsmith
Q22454334  |  MODvalue  |  name_sv     |  Arrowsmith River                          |  Arrowsmith
Q1591919   |  MODvalue  |  name_de     |  Hayes River                               |  Hayes
Q1591919   |  MODvalue  |  name_en     |  Hayes River                               |  Hayes
Q22400924  |  MODvalue  |  name_en     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_nl     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_sv     |  Amadjuak River                            |  Amadjuak
Q22461897  |  MODvalue  |  name_en     |  Aua River                                 |  Aua
Q22461897  |  MODvalue  |  name_nl     |  Aua River                                 |  Aua
Q22461897  |  MODvalue  |  name_sv     |  Aua River                                 |  Aua
Q22628578  |  MODvalue  |  name_en     |  Hiukitak River                            |  Hiukitak
Q22628578  |  MODvalue  |  name_nl     |  Hiukitak River                            |  Hiukitak
Q22628578  |  MODvalue  |  name_sv     |  Hiukitak River                            |  Hiukitak
Q1031730   |  MODvalue  |  name_de     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_en     |  Camsell river                             |  Camsell
Q1031730   |  MODvalue  |  name_nl     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_sv     |  Camsell River                             |  Camsell
Q22400924  |  MODvalue  |  name_en     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_nl     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_sv     |  Amadjuak River                            |  Amadjuak
Q22562651  |  MODvalue  |  name_sv     |  Kuugaarjuk River                          |  Kuugaarjuk
Q15116337  |  MODvalue  |  name_de     |  Kaskawulsh River                          |  Kaskawulsh
Q15116337  |  MODvalue  |  name_en     |  Kaskawulsh River                          |  Kaskawulsh
Q15116337  |  MODvalue  |  name_nl     |  Kaskawulsh River                          |  Kaskawulsh
Q15116337  |  MODvalue  |  name_sv     |  Kaskawulsh River                          |  Kaskawulsh
Q1627362   |  MODvalue  |  name_de     |  Hood River                                |  Hood
Q1627362   |  MODvalue  |  name_en     |  Hood River                                |  Hood
Q1627362   |  NEWvalue  |  name_ru     |                                            |  Худ
Q1627362   |  MODvalue  |  name_sv     |  Hood River                                |  Hood
Q22400924  |  MODvalue  |  name_en     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_nl     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_sv     |  Amadjuak River                            |  Amadjuak
Q22417975  |  MODvalue  |  name_en     |  Angimajuq River                           |  Angimajuq
Q22417975  |  MODvalue  |  name_nl     |  Angimajuq River                           |  Angimajuq
Q22417975  |  MODvalue  |  name_sv     |  Angimajuq River                           |  Angimajuq
Q22400924  |  MODvalue  |  name_en     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_nl     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_sv     |  Amadjuak River                            |  Amadjuak
Q22630419  |  MODvalue  |  name_en     |  Murchison River                           |  Murchison
Q22630419  |  MODvalue  |  name_nl     |  Murchison River                           |  Murchison
Q22630419  |  MODvalue  |  name_sv     |  Murchison River                           |  Murchison
Q15114758  |  MODvalue  |  name_de     |  Hess River                                |  Hess
Q15114758  |  MODvalue  |  name_en     |  Hess River                                |  Hess
Q15114758  |  MODvalue  |  name_nl     |  Hess River                                |  Hess
Q15114758  |  MODvalue  |  name_sv     |  Hess River                                |  Hess
Q7837560   |  MODvalue  |  name_de     |  Tree River                                |  Tree
Q7837560   |  MODvalue  |  name_en     |  Tree River                                |  Tree
Q7837560   |  MODvalue  |  name_sv     |  Tree River                                |  Tree
Q15108615  |  MODvalue  |  name_de     |  Carcajou River                            |  Carcajou
Q15108615  |  MODvalue  |  name_en     |  Carcajou River                            |  Carcajou
Q15108615  |  MODvalue  |  name_nl     |  Carcajou River                            |  Carcajou
Q15108615  |  MODvalue  |  name_sv     |  Carcajou River                            |  Carcajou
Q22454334  |  MODvalue  |  name_en     |  Arrowsmith River                          |  Arrowsmith
Q22454334  |  MODvalue  |  name_nl     |  Arrowsmith River                          |  Arrowsmith
Q22454334  |  MODvalue  |  name_sv     |  Arrowsmith River                          |  Arrowsmith
Q7837560   |  MODvalue  |  name_de     |  Tree River                                |  Tree
Q7837560   |  MODvalue  |  name_en     |  Tree River                                |  Tree
Q7837560   |  MODvalue  |  name_sv     |  Tree River                                |  Tree
Q1326672   |  MODvalue  |  name_de     |  Macmillan River                           |  Macmillan
Q1326672   |  MODvalue  |  name_en     |  Macmillan River                           |  Macmillan
Q1326672   |  MODvalue  |  name_nl     |  Macmillan River                           |  Macmillan
Q1326672   |  MODvalue  |  name_sv     |  Macmillan River                           |  Macmillan
Q4806531   |  MODvalue  |  name_en     |  Asiak River                               |  Asiak
Q4806531   |  MODvalue  |  name_sv     |  Asiak River                               |  Asiak
Q14658488  |  MODvalue  |  name_de     |  Whitefish River                           |  Whitefish
Q14658488  |  MODvalue  |  name_en     |  Whitefish River                           |  Whitefish
Q22630419  |  MODvalue  |  name_en     |  Murchison River                           |  Murchison
Q22630419  |  MODvalue  |  name_nl     |  Murchison River                           |  Murchison
Q22630419  |  MODvalue  |  name_sv     |  Murchison River                           |  Murchison
Q7837560   |  MODvalue  |  name_de     |  Tree River                                |  Tree
Q7837560   |  MODvalue  |  name_en     |  Tree River                                |  Tree
Q7837560   |  MODvalue  |  name_sv     |  Tree River                                |  Tree
Q6441949   |  MODvalue  |  name_en     |  Kugaryuak River                           |  Kugaryuak
Q6441949   |  MODvalue  |  name_sv     |  Kugaryuak River                           |  Kugaryuak
Q22630419  |  MODvalue  |  name_en     |  Murchison River                           |  Murchison
Q22630419  |  MODvalue  |  name_nl     |  Murchison River                           |  Murchison
Q22630419  |  MODvalue  |  name_sv     |  Murchison River                           |  Murchison
Q6388928   |  MODvalue  |  name_de     |  Kendall River                             |  Kendall
Q6388928   |  MODvalue  |  name_en     |  Kendall River                             |  Kendall
Q6388928   |  MODvalue  |  name_nl     |  Kendall River                             |  Kendall
Q6388928   |  MODvalue  |  name_sv     |  Kendall River                             |  Kendall
Q1241570   |  MODvalue  |  name_de     |  Donjek River                              |  Donjek
Q1241570   |  MODvalue  |  name_en     |  Donjek River                              |  Donjek
Q1241570   |  MODvalue  |  name_nl     |  Donjek River                              |  Donjek
Q1241570   |  MODvalue  |  name_sv     |  Donjek River                              |  Donjek
Q15109230  |  MODvalue  |  name_de     |  Dease River                               |  Dease
Q892784    |  MODvalue  |  name_de     |  Bonnet Plume River                        |  Bonnet Plume
Q892784    |  MODvalue  |  name_en     |  Bonnet Plume River                        |  Bonnet Plume
Q892784    |  MODvalue  |  name_sv     |  Bonnet Plume River                        |  Bonnet Plume
Q22420001  |  MODvalue  |  name_en     |  Kingora River                             |  Kingora
Q22420001  |  MODvalue  |  name_nl     |  Kingora River                             |  Kingora
Q22420001  |  MODvalue  |  name_sv     |  Kingora River                             |  Kingora
Q16209683  |  MODvalue  |  name_en     |  Bloody River                              |  Bloody
Q16209683  |  MODvalue  |  name_sv     |  Bloody River                              |  Bloody
Q15112077  |  MODvalue  |  name_de     |  Haldane River                             |  Haldane
Q15112077  |  MODvalue  |  name_en     |  Haldane River                             |  Haldane
Q15112077  |  MODvalue  |  name_nl     |  Haldane River                             |  Haldane
Q15112077  |  MODvalue  |  name_sv     |  Haldane River                             |  Haldane
Q7547066   |  MODvalue  |  name_de     |  Snake River                               |  Snake
Q7547066   |  MODvalue  |  name_en     |  Snake River                               |  Snake
Q7547066   |  MODvalue  |  name_sv     |  Snake River                               |  Snake
Q22596300  |  MODvalue  |  name_en     |  Hantzsch River                            |  Hantzsch
Q22596300  |  MODvalue  |  name_nl     |  Hantzsch River                            |  Hantzsch
Q22596300  |  MODvalue  |  name_sv     |  Hantzsch River                            |  Hantzsch
Q4878160   |  MODvalue  |  name_en     |  Beaver River                              |  Beaver
Q22596300  |  MODvalue  |  name_en     |  Hantzsch River                            |  Hantzsch
Q22596300  |  MODvalue  |  name_nl     |  Hantzsch River                            |  Hantzsch
Q22596300  |  MODvalue  |  name_sv     |  Hantzsch River                            |  Hantzsch
Q7281929   |  MODvalue  |  name_de     |  Rae River                                 |  Rae
Q7281929   |  MODvalue  |  name_en     |  Rae River                                 |  Rae
Q7281929   |  MODvalue  |  name_sv     |  Rae River                                 |  Rae
Q491660    |  MODvalue  |  name_de     |  Anderson River                            |  Anderson
Q491660    |  MODvalue  |  name_en     |  Anderson River                            |  Anderson
Q491660    |  MODvalue  |  name_nl     |  Anderson River                            |  Anderson
Q491660    |  MODvalue  |  name_sv     |  Anderson River                            |  Anderson
Q1529669   |  MODvalue  |  name_de     |  White River                               |  White
Q1529669   |  MODvalue  |  name_en     |  White River                               |  White
Q1529669   |  MODvalue  |  name_fr     |  White River                               |  White
Q1529669   |  MODvalue  |  name_it     |  White River                               |  White
Q1529669   |  MODvalue  |  name_nl     |  White River                               |  White
Q1529669   |  MODvalue  |  name_pl     |  White River                               |  White
Q1529669   |  MODvalue  |  name_de     |  White River                               |  White
Q1529669   |  MODvalue  |  name_en     |  White River                               |  White
Q1529669   |  MODvalue  |  name_fr     |  White River                               |  White
Q1529669   |  MODvalue  |  name_it     |  White River                               |  White
Q1529669   |  MODvalue  |  name_nl     |  White River                               |  White
Q1529669   |  MODvalue  |  name_pl     |  White River                               |  White
Q2583410   |  MODvalue  |  name_de     |  Wind River                                |  Wind
Q2583410   |  MODvalue  |  name_en     |  Wind River                                |  Wind
Q2583410   |  MODvalue  |  name_sv     |  Wind River                                |  Wind
Q22596300  |  MODvalue  |  name_en     |  Hantzsch River                            |  Hantzsch
Q22596300  |  MODvalue  |  name_nl     |  Hantzsch River                            |  Hantzsch
Q22596300  |  MODvalue  |  name_sv     |  Hantzsch River                            |  Hantzsch
Q15120012  |  MODvalue  |  name_de     |  McQuesten River                           |  McQuesten
Q15120012  |  MODvalue  |  name_en     |  McQuesten River                           |  McQuesten
Q15120012  |  MODvalue  |  name_nl     |  McQuesten River                           |  McQuesten
Q15120012  |  MODvalue  |  name_sv     |  McQuesten River                           |  McQuesten
Q7281929   |  MODvalue  |  name_de     |  Rae River                                 |  Rae
Q7281929   |  MODvalue  |  name_en     |  Rae River                                 |  Rae
Q7281929   |  MODvalue  |  name_sv     |  Rae River                                 |  Rae
Q1162665   |  MODvalue  |  name_de     |  Horton River                              |  Horton
Q1162665   |  MODvalue  |  name_en     |  Horton River                              |  Horton
Q1162665   |  MODvalue  |  name_fr     |  Horton River                              |  Horton
Q1162665   |  MODvalue  |  name_nl     |  Horton River                              |  Horton
Q1162665   |  MODvalue  |  name_pl     |  Horton River                              |  Horton
Q7281929   |  MODvalue  |  name_de     |  Rae River                                 |  Rae
Q7281929   |  MODvalue  |  name_en     |  Rae River                                 |  Rae
Q7281929   |  MODvalue  |  name_sv     |  Rae River                                 |  Rae
Q5350280   |  MODvalue  |  name_en     |  Ekalluk River                             |  Ekalluk
Q5350280   |  MODvalue  |  name_sv     |  Ekalluk River                             |  Ekalluk
Q22644608  |  MODvalue  |  name_en     |  Horton River                              |  Horton
Q22644608  |  MODvalue  |  name_nl     |  Horton River                              |  Horton
Q22644608  |  MODvalue  |  name_sv     |  Horton River                              |  Horton
Q286340    |  MODvalue  |  name_de     |  Klondike River                            |  Klondike
Q286340    |  MODvalue  |  name_en     |  Klondike River                            |  Klondike
Q286340    |  MODvalue  |  name_nl     |  Klondike River                            |  Klondike
Q22644608  |  MODvalue  |  name_en     |  Horton River                              |  Horton
Q22644608  |  MODvalue  |  name_nl     |  Horton River                              |  Horton
Q22644608  |  MODvalue  |  name_sv     |  Horton River                              |  Horton
Q491660    |  MODvalue  |  name_de     |  Anderson River                            |  Anderson
Q491660    |  MODvalue  |  name_en     |  Anderson River                            |  Anderson
Q491660    |  MODvalue  |  name_nl     |  Anderson River                            |  Anderson
Q491660    |  MODvalue  |  name_sv     |  Anderson River                            |  Anderson
Q670674    |  MODvalue  |  name_de     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_en     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_fr     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_nl     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_sv     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_de     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_en     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_fr     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_nl     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_sv     |  Hornaday River                            |  Hornaday
Q15112165  |  MODvalue  |  name_de     |  Hart River                                |  Hart
Q15112165  |  MODvalue  |  name_en     |  Hart River                                |  Hart
Q15112165  |  MODvalue  |  name_nl     |  Hart River                                |  Hart
Q15112165  |  MODvalue  |  name_sv     |  Hart River                                |  Hart
Q22659451  |  MODvalue  |  name_en     |  Lord Lindsay River                        |  Lord Lindsay
Q22659451  |  MODvalue  |  name_nl     |  Lord Lindsay River                        |  Lord Lindsay
Q22659451  |  MODvalue  |  name_sv     |  Lord Lindsay River                        |  Lord Lindsay
Q13033971  |  MODvalue  |  name_de     |  Carnwath River                            |  Carnwath
Q13033971  |  MODvalue  |  name_en     |  Carnwath River                            |  Carnwath
Q13033971  |  MODvalue  |  name_nl     |  Carnwath River                            |  Carnwath
Q13033971  |  MODvalue  |  name_sv     |  Carnwath River                            |  Carnwath
Q670674    |  MODvalue  |  name_de     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_en     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_fr     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_nl     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_sv     |  Hornaday River                            |  Hornaday
Q1140808   |  MODvalue  |  name_de     |  Croker River                              |  Croker
Q1140808   |  MODvalue  |  name_en     |  Croker River                              |  Croker
Q1140808   |  MODvalue  |  name_fr     |  Croker River                              |  Croker
Q1140808   |  MODvalue  |  name_nl     |  Croker River                              |  Croker
Q1140808   |  MODvalue  |  name_sv     |  Croker River                              |  Croker
Q15112165  |  MODvalue  |  name_de     |  Hart River                                |  Hart
Q15112165  |  MODvalue  |  name_en     |  Hart River                                |  Hart
Q15112165  |  MODvalue  |  name_nl     |  Hart River                                |  Hart
Q15112165  |  MODvalue  |  name_sv     |  Hart River                                |  Hart
Q7367525   |  MODvalue  |  name_de     |  Roscoe River                              |  Roscoe
Q7367525   |  MODvalue  |  name_en     |  Roscoe River                              |  Roscoe
Q4088437   |  MODvalue  |  name_de     |  Blackstone River                          |  Blackstone
Q22641244  |  MODvalue  |  name_en     |  Gifford River                             |  Gifford
Q22641244  |  MODvalue  |  name_nl     |  Gifford River                             |  Gifford
Q22641244  |  MODvalue  |  name_sv     |  Gifford River                             |  Gifford
Q22461479  |  MODvalue  |  name_en     |  Isortoq River                             |  Isortoq
Q22461479  |  MODvalue  |  name_nl     |  Isortoq River                             |  Isortoq
Q22461479  |  MODvalue  |  name_sv     |  Isortoq River                             |  Isortoq
Q2067014   |  MODvalue  |  name_de     |  Peel River                                |  Peel
Q2067014   |  MODvalue  |  name_en     |  Peel River                                |  Peel
Q2067014   |  MODvalue  |  name_sv     |  Peel River                                |  Peel
Q2067014   |  MODvalue  |  name_de     |  Peel River                                |  Peel
Q2067014   |  MODvalue  |  name_en     |  Peel River                                |  Peel
Q2067014   |  MODvalue  |  name_sv     |  Peel River                                |  Peel
Q6346598   |  MODvalue  |  name_en     |  Kagloryuak River                          |  Kagloryuak
Q6346598   |  MODvalue  |  name_sv     |  Kagloryuak River                          |  Kagloryuak
Q2067014   |  MODvalue  |  name_de     |  Peel River                                |  Peel
Q2067014   |  MODvalue  |  name_en     |  Peel River                                |  Peel
Q2067014   |  MODvalue  |  name_sv     |  Peel River                                |  Peel
Q22559173  |  MODvalue  |  name_nl     |  Kugaluk River                             |  Kugaluk
Q22559173  |  MODvalue  |  name_sv     |  Kugaluk River                             |  Kugaluk
Q1140808   |  MODvalue  |  name_de     |  Croker River                              |  Croker
Q1140808   |  MODvalue  |  name_en     |  Croker River                              |  Croker
Q1140808   |  MODvalue  |  name_fr     |  Croker River                              |  Croker
Q1140808   |  MODvalue  |  name_nl     |  Croker River                              |  Croker
Q1140808   |  MODvalue  |  name_sv     |  Croker River                              |  Croker
Q1140808   |  MODvalue  |  name_de     |  Croker River                              |  Croker
Q1140808   |  MODvalue  |  name_en     |  Croker River                              |  Croker
Q1140808   |  MODvalue  |  name_fr     |  Croker River                              |  Croker
Q1140808   |  MODvalue  |  name_nl     |  Croker River                              |  Croker
Q1140808   |  MODvalue  |  name_sv     |  Croker River                              |  Croker
Q2067014   |  MODvalue  |  name_de     |  Peel River                                |  Peel
Q2067014   |  MODvalue  |  name_en     |  Peel River                                |  Peel
Q2067014   |  MODvalue  |  name_sv     |  Peel River                                |  Peel
Q670674    |  MODvalue  |  name_de     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_en     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_fr     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_nl     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_sv     |  Hornaday River                            |  Hornaday
Q22559173  |  MODvalue  |  name_nl     |  Kugaluk River                             |  Kugaluk
Q22559173  |  MODvalue  |  name_sv     |  Kugaluk River                             |  Kugaluk
Q6346598   |  MODvalue  |  name_en     |  Kagloryuak River                          |  Kagloryuak
Q6346598   |  MODvalue  |  name_sv     |  Kagloryuak River                          |  Kagloryuak
Q6346598   |  MODvalue  |  name_en     |  Kagloryuak River                          |  Kagloryuak
Q6346598   |  MODvalue  |  name_sv     |  Kagloryuak River                          |  Kagloryuak
Q22644608  |  MODvalue  |  name_en     |  Horton River                              |  Horton
Q22644608  |  MODvalue  |  name_nl     |  Horton River                              |  Horton
Q22644608  |  MODvalue  |  name_sv     |  Horton River                              |  Horton
Q1439158   |  MODvalue  |  name_de     |  Fortymile River                           |  Fortymile
Q1439158   |  MODvalue  |  name_en     |  Fortymile River                           |  Fortymile
Q1439158   |  MODvalue  |  name_nl     |  Fortymile River                           |  Fortymile
Q1439158   |  MODvalue  |  name_pl     |  Fortymile River                           |  Fortymile
Q1439158   |  MODvalue  |  name_sv     |  Fortymile River                           |  Fortymile
Q2067014   |  MODvalue  |  name_de     |  Peel River                                |  Peel
Q2067014   |  MODvalue  |  name_en     |  Peel River                                |  Peel
Q2067014   |  MODvalue  |  name_sv     |  Peel River                                |  Peel
Q4331055   |  MODvalue  |  name_de     |  Ogilvie River                             |  Ogilvie
Q4331055   |  MODvalue  |  name_en     |  Ogilvie River                             |  Ogilvie
Q4331055   |  MODvalue  |  name_nl     |  Ogilvie River                             |  Ogilvie
Q4331055   |  MODvalue  |  name_sv     |  Ogilvie River                             |  Ogilvie
Q22644608  |  MODvalue  |  name_en     |  Horton River                              |  Horton
Q22644608  |  MODvalue  |  name_nl     |  Horton River                              |  Horton
Q22644608  |  MODvalue  |  name_sv     |  Horton River                              |  Horton
Q6964092   |  MODvalue  |  name_en     |  Nanook River                              |  Nanook
Q6964092   |  MODvalue  |  name_sv     |  Nanook River                              |  Nanook
Q22562731  |  MODvalue  |  name_sv     |  Kuuk River                                |  Kuuk
Q15110020  |  MODvalue  |  name_de     |  Eagle River                               |  Eagle
Q15110020  |  MODvalue  |  name_en     |  Eagle River                               |  Eagle
Q13033971  |  MODvalue  |  name_de     |  Carnwath River                            |  Carnwath
Q13033971  |  MODvalue  |  name_en     |  Carnwath River                            |  Carnwath
Q13033971  |  MODvalue  |  name_nl     |  Carnwath River                            |  Carnwath
Q13033971  |  MODvalue  |  name_sv     |  Carnwath River                            |  Carnwath
Q4331055   |  MODvalue  |  name_de     |  Ogilvie River                             |  Ogilvie
Q4331055   |  MODvalue  |  name_en     |  Ogilvie River                             |  Ogilvie
Q4331055   |  MODvalue  |  name_nl     |  Ogilvie River                             |  Ogilvie
Q4331055   |  MODvalue  |  name_sv     |  Ogilvie River                             |  Ogilvie
Q22491462  |  MODvalue  |  name_en     |  Jungersen River                           |  Jungersen
Q22491462  |  MODvalue  |  name_nl     |  Jungersen River                           |  Jungersen
Q22491462  |  MODvalue  |  name_sv     |  Jungersen River                           |  Jungersen
Q670674    |  MODvalue  |  name_de     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_en     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_fr     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_nl     |  Hornaday River                            |  Hornaday
Q670674    |  MODvalue  |  name_sv     |  Hornaday River                            |  Hornaday
Q13033971  |  MODvalue  |  name_de     |  Carnwath River                            |  Carnwath
Q13033971  |  MODvalue  |  name_en     |  Carnwath River                            |  Carnwath
Q13033971  |  MODvalue  |  name_nl     |  Carnwath River                            |  Carnwath
Q13033971  |  MODvalue  |  name_sv     |  Carnwath River                            |  Carnwath
Q15134861  |  MODvalue  |  name_de     |  Whitestone River                          |  Whitestone
Q15134861  |  MODvalue  |  name_en     |  Whitestone River                          |  Whitestone
Q22562731  |  MODvalue  |  name_sv     |  Kuuk River                                |  Kuuk
Q15135332  |  MODvalue  |  name_de     |  Wolverine River                           |  Wolverine
Q15135332  |  MODvalue  |  name_en     |  Wolverine River                           |  Wolverine
Q15135332  |  MODvalue  |  name_sv     |  Wolverine River                           |  Wolverine
Q22559173  |  MODvalue  |  name_nl     |  Kugaluk River                             |  Kugaluk
Q22559173  |  MODvalue  |  name_sv     |  Kugaluk River                             |  Kugaluk
Q6964092   |  MODvalue  |  name_en     |  Nanook River                              |  Nanook
Q6964092   |  MODvalue  |  name_sv     |  Nanook River                              |  Nanook
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q22517624  |  MODvalue  |  name_nl     |  Miner River                               |  Miner
Q22517624  |  MODvalue  |  name_sv     |  Miner River                               |  Miner
Q22562704  |  MODvalue  |  name_sv     |  Kuujjua River                             |  Kuujjua
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q6425758   |  MODvalue  |  name_en     |  Kogalu River                              |  Kogalu
Q6425758   |  MODvalue  |  name_nl     |  Kogalu River                              |  Kogalu
Q6425758   |  MODvalue  |  name_sv     |  Kogalu River                              |  Kogalu
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q22562704  |  MODvalue  |  name_sv     |  Kuujjua River                             |  Kuujjua
Q15107467  |  MODvalue  |  name_de     |  Bell River                                |  Bell
Q15107467  |  MODvalue  |  name_en     |  Bell River                                |  Bell
Q15107467  |  MODvalue  |  name_de     |  Bell River                                |  Bell
Q15107467  |  MODvalue  |  name_en     |  Bell River                                |  Bell
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3350185   |  MODvalue  |  name_de     |  Old Crow River                            |  Old Crow
Q3350185   |  MODvalue  |  name_en     |  Old Crow River                            |  Old Crow
Q3350185   |  MODvalue  |  name_es     |  Old Crow River                            |  Old Crow
Q3350185   |  MODvalue  |  name_nl     |  Old Crow River                            |  Old Crow
Q3350185   |  MODvalue  |  name_sv     |  Old Crow River                            |  Old Crow
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q22467918  |  MODvalue  |  name_en     |  Babbage River                             |  Babbage
Q22467918  |  MODvalue  |  name_nl     |  Babbage River                             |  Babbage
Q22467918  |  MODvalue  |  name_sv     |  Babbage River                             |  Babbage
Q1419623   |  MODvalue  |  name_de     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_en     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_nl     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_sv     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_de     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_en     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_nl     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_sv     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_de     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_en     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_nl     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_sv     |  Firth River                               |  Firth
Q1922086   |  MODvalue  |  name_de     |  Mersey River                              |  Mersey
Q1922086   |  MODvalue  |  name_en     |  Mersey River                              |  Mersey
Q1922086   |  MODvalue  |  name_sv     |  Mersey River                              |  Mersey
Q6460763   |  MODvalue  |  name_de     |  LaHave River                              |  LaHave
Q6460763   |  MODvalue  |  name_en     |  LaHave River                              |  LaHave
Q6460763   |  MODvalue  |  name_fr     |  Fleuve La Hève                            |  fleuve La Hève
Q6460763   |  MODvalue  |  name_nl     |  LaHave River                              |  LaHave
Q6460763   |  MODvalue  |  name_sv     |  LaHave River                              |  LaHave
Q3433623   |  MODvalue  |  name_de     |  Annapolis River                           |  Annapolis
Q3433623   |  MODvalue  |  name_en     |  Annapolis River                           |  Annapolis
Q3433623   |  MODvalue  |  name_sv     |  Annapolis River                           |  Annapolis
Q1894790   |  MODvalue  |  name_de     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_en     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_fr     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_nl     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_sv     |  Margaree River                            |  Margaree
Q6872235   |  MODvalue  |  name_en     |  Mira River                                |  Mira
Q1894790   |  MODvalue  |  name_de     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_en     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_fr     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_nl     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_sv     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_de     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_en     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_fr     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_nl     |  Margaree River                            |  Margaree
Q1894790   |  MODvalue  |  name_sv     |  Margaree River                            |  Margaree
Q6872235   |  MODvalue  |  name_en     |  Mira River                                |  Mira
Q7414617   |  MODvalue  |  name_en     |  San Juan River                            |  San Juan
Q827529    |  MODvalue  |  name_de     |  Cowichan River                            |  Cowichan
Q827529    |  MODvalue  |  name_en     |  Cowichan River                            |  Cowichan
Q827529    |  MODvalue  |  name_fr     |  Cowichan River                            |  Cowichan
Q827529    |  MODvalue  |  name_nl     |  Cowichan River                            |  Cowichan
Q827529    |  MODvalue  |  name_sv     |  Cowichan River                            |  Cowichan
Q7559226   |  MODvalue  |  name_en     |  Somass River                              |  Somass
Q7559226   |  MODvalue  |  name_sv     |  Somass River                              |  Somass
Q15842579  |  MODvalue  |  name_en     |  Jupiter river                             |  Jupiter
Q1534621   |  MODvalue  |  name_de     |  Gold River                                |  Gold
Q14874728  |  MODvalue  |  name_en     |  Nimpkish River                            |  Nimpkish
Q14874728  |  MODvalue  |  name_sv     |  Nimpkish River                            |  Nimpkish
Q3116570   |  MODvalue  |  name_en     |  Grey River                                |  Grey
Q3116570   |  MODvalue  |  name_fr     |  Grey River                                |  Grey
Q3116570   |  MODvalue  |  name_nl     |  Grey River                                |  Grey
Q3116570   |  MODvalue  |  name_sv     |  Grey River                                |  Grey
Q994493    |  MODvalue  |  name_de     |  Victoria River                            |  Victoria
Q994493    |  MODvalue  |  name_en     |  Victoria River                            |  Victoria
Q994493    |  MODvalue  |  name_fr     |  Victoria River                            |  Victoria
Q994493    |  MODvalue  |  name_nl     |  Victoria River                            |  Victoria
Q994493    |  MODvalue  |  name_sv     |  Victoria River                            |  Victoria
Q14874728  |  MODvalue  |  name_en     |  Nimpkish River                            |  Nimpkish
Q14874728  |  MODvalue  |  name_sv     |  Nimpkish River                            |  Nimpkish
Q2214785   |  MODvalue  |  name_de     |  Salmon River                              |  Salmon
Q2214785   |  MODvalue  |  name_en     |  Salmon River                              |  Salmon
Q4081164   |  MODvalue  |  name_en     |  Bay du Nord River                         |  Bay du Nord
Q4081164   |  MODvalue  |  name_sv     |  Bay du Nord River                         |  Bay du Nord
Q1636789   |  MODvalue  |  name_de     |  Humber River                              |  Humber
Q1636789   |  MODvalue  |  name_en     |  Humber River                              |  Humber
Q1636789   |  MODvalue  |  name_sv     |  Humber River                              |  Humber
Q7703132   |  MODvalue  |  name_en     |  Terra Nova River                          |  Terra Nova
Q7703132   |  MODvalue  |  name_sv     |  Terra Nova River                          |  Terra Nova
Q1113275   |  MODvalue  |  name_de     |  Main River                                |  Main
Q1113275   |  MODvalue  |  name_en     |  Main River                                |  Main
Q1113275   |  MODvalue  |  name_nl     |  Main River                                |  Main
Q1113275   |  MODvalue  |  name_sv     |  Main River                                |  Main
Q1324855   |  MODvalue  |  name_de     |  Gander River                              |  Gander
Q1324855   |  MODvalue  |  name_en     |  Gander River                              |  Gander
Q1324855   |  MODvalue  |  name_nl     |  Gander River                              |  Gander
Q1324855   |  MODvalue  |  name_sv     |  Gander River                              |  Gander
Q291233    |  MODvalue  |  name_de     |  Churchill River                           |  Churchill
Q291233    |  MODvalue  |  name_en     |  Churchill River                           |  Churchill
Q291233    |  MODvalue  |  name_fr     |  Fleuve Churchill                          |  fleuve Churchill
Q291233    |  MODvalue  |  name_nl     |  Churchill River                           |  Churchill
Q2226      |  MODvalue  |  name_de     |  Slave River                               |  Slave
Q2226      |  MODvalue  |  name_en     |  Slave River                               |  Slave
Q2226      |  MODvalue  |  name_nl     |  Slave River                               |  Slave
Q2226      |  MODvalue  |  name_sv     |  Slave River                               |  Slave
Q4931473   |  MODvalue  |  name_en     |  Boas River                                |  Boas
Q4931473   |  MODvalue  |  name_sv     |  Boas River                                |  Boas
Q4931473   |  MODvalue  |  name_en     |  Boas River                                |  Boas
Q4931473   |  MODvalue  |  name_sv     |  Boas River                                |  Boas
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q859175    |  MODvalue  |  name_de     |  Big River                                 |  Big
Q859175    |  MODvalue  |  name_en     |  Big River                                 |  Big
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_de     |  Mackenzie River                           |  Mackenzie
Q3411      |  MODvalue  |  name_en     |  Mackenzie River                           |  Mackenzie
Q7795847   |  MODvalue  |  name_en     |  Thomsen River                             |  Thomsen
Q7795847   |  MODvalue  |  name_en     |  Thomsen River                             |  Thomsen
Q7795847   |  MODvalue  |  name_en     |  Thomsen River                             |  Thomsen
Q22563404  |  MODvalue  |  name_en     |  Davies River                              |  Davies
Q22563404  |  MODvalue  |  name_nl     |  Davies River                              |  Davies
Q22563404  |  MODvalue  |  name_sv     |  Davies River                              |  Davies
Q22584057  |  MODvalue  |  name_en     |  Haakon River                              |  Haakon
Q22584057  |  MODvalue  |  name_nl     |  Haakon River                              |  Haakon
Q22584057  |  MODvalue  |  name_sv     |  Haakon River                              |  Haakon
Q7378585   |  MODvalue  |  name_en     |  Ruggles River                             |  Ruggles
Q7378585   |  MODvalue  |  name_sv     |  Ruggles River                             |  Ruggles
Q2330973   |  MODvalue  |  name_en     |  Tehuantepec River                         |  Tehuantepec
Q2330973   |  MODvalue  |  name_nl     |  Tehuantepec River                         |  Tehuantepec
Q4107580   |  MODvalue  |  name_en     |  Verde River                               |  Verde
Q847785    |  MODvalue  |  name_de     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_en     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_nl     |  Colorado River                            |  Colorado
Q5351071   |  MODvalue  |  name_en     |  El Corte River                            |  El Corte
Q476664    |  MODvalue  |  name_en     |  Sarabia River                             |  Sarabia
Q2332765   |  MODvalue  |  name_en     |  San Pedro River                           |  San Pedro
Q2332765   |  MODvalue  |  name_en     |  San Pedro River                           |  San Pedro
Q1494095   |  MODvalue  |  name_en     |  Hondo River                               |  Hondo
Q1494095   |  MODvalue  |  name_en     |  Hondo River                               |  Hondo
Q1494095   |  MODvalue  |  name_en     |  Hondo River                               |  Hondo
Q583044    |  MODvalue  |  name_en     |  Papaloapan River                          |  Papaloapan
Q1129218   |  MODvalue  |  name_en     |  Balsas River                              |  Balsas
Q1494095   |  MODvalue  |  name_en     |  Hondo River                               |  Hondo
Q2152125   |  MODvalue  |  name_en     |  Jamapa River                              |  Jamapa
Q6115751   |  MODvalue  |  name_en     |  Tecolutla River                           |  Tecolutla
Q5055533   |  MODvalue  |  name_en     |  Cazones River                             |  Cazones
Q827561    |  MODvalue  |  name_en     |  Ameca River                               |  Ameca
Q948470    |  MODvalue  |  name_en     |  Baluarte River                            |  Baluarte
Q7414617   |  MODvalue  |  name_en     |  San Juan River                            |  San Juan
Q7414617   |  MODvalue  |  name_en     |  San Juan River                            |  San Juan
Q3458794   |  MODvalue  |  name_en     |  Sinaloa River                             |  Sinaloa
Q3458794   |  MODvalue  |  name_en     |  Sinaloa River                             |  Sinaloa
Q7414617   |  MODvalue  |  name_en     |  San Juan River                            |  San Juan
Q2749928   |  MODvalue  |  name_en     |  Caloosahatchee River                      |  Caloosahatchee
Q2749928   |  MODvalue  |  name_nl     |  Caloosahatchee River                      |  Caloosahatchee
Q2749928   |  MODvalue  |  name_sv     |  Caloosahatchee River                      |  Caloosahatchee
Q2749928   |  MODvalue  |  name_en     |  Caloosahatchee River                      |  Caloosahatchee
Q2749928   |  MODvalue  |  name_nl     |  Caloosahatchee River                      |  Caloosahatchee
Q2749928   |  MODvalue  |  name_sv     |  Caloosahatchee River                      |  Caloosahatchee
Q847785    |  MODvalue  |  name_de     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_en     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_nl     |  Colorado River                            |  Colorado
Q3373802   |  MODvalue  |  name_en     |  Peace River                               |  Peace
Q3373802   |  MODvalue  |  name_fr     |  Peace River                               |  Peace
Q3373802   |  MODvalue  |  name_nl     |  Peace River                               |  Peace
Q7589737   |  MODvalue  |  name_de     |  St. Lucie River                           |  St. Lucie
Q7589737   |  MODvalue  |  name_en     |  St. Lucie River                           |  St. Lucie
Q2748200   |  MODvalue  |  name_en     |  Kissimmee River                           |  Kissimmee
Q2748200   |  MODvalue  |  name_sv     |  Kissimmee River                           |  Kissimmee
Q7414617   |  MODvalue  |  name_en     |  San Juan River                            |  San Juan
Q2451378   |  MODvalue  |  name_en     |  San Pedro River                           |  San Pedro
Q2451378   |  MODvalue  |  name_hu     |  San Pedro River                           |  San Pedro
Q2451378   |  MODvalue  |  name_nl     |  San Pedro River                           |  San Pedro
Q1468723   |  MODvalue  |  name_de     |  Nueces River                              |  Nueces
Q1468723   |  MODvalue  |  name_en     |  Nueces River                              |  Nueces
Q1468723   |  MODvalue  |  name_nl     |  Nueces River                              |  Nueces
Q7414617   |  MODvalue  |  name_en     |  San Juan River                            |  San Juan
Q4107580   |  MODvalue  |  name_en     |  Verde River                               |  Verde
Q1468723   |  MODvalue  |  name_de     |  Nueces River                              |  Nueces
Q1468723   |  MODvalue  |  name_en     |  Nueces River                              |  Nueces
Q1468723   |  MODvalue  |  name_nl     |  Nueces River                              |  Nueces
Q2451378   |  MODvalue  |  name_en     |  San Pedro River                           |  San Pedro
Q2451378   |  MODvalue  |  name_hu     |  San Pedro River                           |  San Pedro
Q2451378   |  MODvalue  |  name_nl     |  San Pedro River                           |  San Pedro
Q1468723   |  MODvalue  |  name_de     |  Nueces River                              |  Nueces
Q1468723   |  MODvalue  |  name_en     |  Nueces River                              |  Nueces
Q1468723   |  MODvalue  |  name_nl     |  Nueces River                              |  Nueces
Q3569503   |  MODvalue  |  name_en     |  Withlacoochee River                       |  Withlacoochee
Q3433689   |  MODvalue  |  name_en     |  Frio River                                |  Frio
Q3433689   |  MODvalue  |  name_en     |  Frio River                                |  Frio
Q1552614   |  MODvalue  |  name_de     |  Guadalupe River                           |  Guadalupe
Q1552614   |  MODvalue  |  name_en     |  Guadalupe River                           |  Guadalupe
Q1552614   |  MODvalue  |  name_fr     |  Guadalupe River                           |  Guadalupe
Q1751381   |  MODvalue  |  name_de     |  San Antonio River                         |  San Antonio
Q1751381   |  MODvalue  |  name_en     |  San Antonio River                         |  San Antonio
Q1751381   |  MODvalue  |  name_fr     |  San Antonio River                         |  San Antonio
Q1751381   |  MODvalue  |  name_nl     |  San Antonio River                         |  San Antonio
Q1552614   |  MODvalue  |  name_de     |  Guadalupe River                           |  Guadalupe
Q1552614   |  MODvalue  |  name_en     |  Guadalupe River                           |  Guadalupe
Q1552614   |  MODvalue  |  name_fr     |  Guadalupe River                           |  Guadalupe
Q847785    |  MODvalue  |  name_de     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_en     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_nl     |  Colorado River                            |  Colorado
Q3433742   |  MODvalue  |  name_en     |  Medina River                              |  Medina
Q3433742   |  MODvalue  |  name_hu     |  Medina River                              |  Medina
Q3433742   |  MODvalue  |  name_sv     |  Medina River                              |  Medina
Q3433689   |  MODvalue  |  name_en     |  Frio River                                |  Frio
Q1552614   |  MODvalue  |  name_de     |  Guadalupe River                           |  Guadalupe
Q1552614   |  MODvalue  |  name_en     |  Guadalupe River                           |  Guadalupe
Q1552614   |  MODvalue  |  name_fr     |  Guadalupe River                           |  Guadalupe
Q964437    |  MODvalue  |  name_de     |  Neches River                              |  Neches
Q964437    |  MODvalue  |  name_en     |  Neches River                              |  Neches
Q964437    |  MODvalue  |  name_nl     |  Neches River                              |  Neches
Q3348721   |  MODvalue  |  name_en     |  Ochlockonee River                         |  Ochlockonee
Q3433661   |  MODvalue  |  name_en     |  Calcasieu River                           |  Calcasieu
Q1866844   |  MODvalue  |  name_de     |  Llano River                               |  Llano
Q1866844   |  MODvalue  |  name_en     |  Llano River                               |  Llano
Q10595101  |  MODvalue  |  name_en     |  Navasota River                            |  Navasota
Q10595101  |  MODvalue  |  name_sv     |  Navasota River                            |  Navasota
Q1534710   |  MODvalue  |  name_en     |  Sonora River                              |  Sonora
Q1534710   |  MODvalue  |  name_nl     |  Sonora River                              |  Sonora
Q55262     |  MODvalue  |  name_de     |  Pascagoula River                          |  Pascagoula
Q55262     |  MODvalue  |  name_en     |  Pascagoula River                          |  Pascagoula
Q55262     |  MODvalue  |  name_nl     |  Pascagoula River                          |  Pascagoula
Q4272077   |  MODvalue  |  name_en     |  Choctawhatchee River                      |  Choctawhatchee
Q3569502   |  MODvalue  |  name_en     |  Withlacoochee River                       |  Withlacoochee
Q2830643   |  MODvalue  |  name_en     |  Alapaha River                             |  Alapaha
Q847785    |  MODvalue  |  name_de     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_en     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_nl     |  Colorado River                            |  Colorado
Q1866844   |  MODvalue  |  name_de     |  Llano River                               |  Llano
Q1866844   |  MODvalue  |  name_en     |  Llano River                               |  Llano
Q1866844   |  MODvalue  |  name_de     |  Llano River                               |  Llano
Q1866844   |  MODvalue  |  name_en     |  Llano River                               |  Llano
Q4736170   |  MODvalue  |  name_en     |  Altar River                               |  Altar
Q847785    |  MODvalue  |  name_de     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_en     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_nl     |  Colorado River                            |  Colorado
Q6651678   |  MODvalue  |  name_en     |  Little River                              |  Little
Q6651678   |  MODvalue  |  name_en     |  Little River                              |  Little
Q1969490   |  MODvalue  |  name_de     |  Trinity River                             |  Trinity
Q1969490   |  MODvalue  |  name_en     |  Trinity River                             |  Trinity
Q1969490   |  MODvalue  |  name_nl     |  Trinity River                             |  Trinity
Q1969490   |  MODvalue  |  name_pl     |  Trinity River                             |  Trinity
Q1428859   |  MODvalue  |  name_de     |  Flint River                               |  Flint
Q1428859   |  MODvalue  |  name_en     |  Flint River                               |  Flint
Q1428859   |  MODvalue  |  name_it     |  Flint River                               |  Flint
Q2386134   |  MODvalue  |  name_en     |  Satilla River                             |  Satilla
Q4762748   |  MODvalue  |  name_en     |  Angelina River                            |  Angelina
Q964437    |  MODvalue  |  name_de     |  Neches River                              |  Neches
Q964437    |  MODvalue  |  name_en     |  Neches River                              |  Neches
Q964437    |  MODvalue  |  name_nl     |  Neches River                              |  Neches
Q847785    |  MODvalue  |  name_de     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_en     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_nl     |  Colorado River                            |  Colorado
Q1810486   |  MODvalue  |  name_de     |  Leaf River                                |  Leaf
Q1810486   |  MODvalue  |  name_en     |  Leaf River                                |  Leaf
Q1072169   |  MODvalue  |  name_de     |  Chickasawhay River                        |  Chickasawhay
Q1072169   |  MODvalue  |  name_en     |  Chickasawhay River                        |  Chickasawhay
Q1072169   |  MODvalue  |  name_fr     |  Chickasawhay River                        |  Chickasawhay
Q1072169   |  MODvalue  |  name_nl     |  Chickasawhay River                        |  Chickasawhay
Q7157190   |  MODvalue  |  name_en     |  Pea River                                 |  Pea
Q5159475   |  MODvalue  |  name_en     |  Conecuh River                             |  Conecuh
Q4272077   |  MODvalue  |  name_en     |  Choctawhatchee River                      |  Choctawhatchee
Q26856906  |  MODvalue  |  name_en     |  Agua Prieta River                         |  Agua Prieta
Q26856906  |  MODvalue  |  name_en     |  Agua Prieta River                         |  Agua Prieta
Q846627    |  MODvalue  |  name_de     |  Ocmulgee River                            |  Ocmulgee
Q846627    |  MODvalue  |  name_en     |  Ocmulgee River                            |  Ocmulgee
Q846627    |  MODvalue  |  name_nl     |  Ocmulgee River                            |  Ocmulgee
Q130012    |  MODvalue  |  name_en     |  Ogeechee River                            |  Ogeechee
Q1042217   |  MODvalue  |  name_en     |  Big Black River                           |  Big Black
Q16899736  |  MODvalue  |  name_en     |  San Simon River                           |  San Simon
Q5656629   |  MODvalue  |  name_en     |  Hardy River                               |  Hardy
Q2933076   |  MODvalue  |  name_en     |  Cahaba River                              |  Cahaba
Q1201857   |  MODvalue  |  name_de     |  Yazoo River                               |  Yazoo
Q1201857   |  MODvalue  |  name_en     |  Yazoo River                               |  Yazoo
Q1201857   |  MODvalue  |  name_nl     |  Yazoo River                               |  Yazoo
Q1424101   |  MODvalue  |  name_de     |  Tallapoosa River                          |  Tallapoosa
Q1424101   |  MODvalue  |  name_en     |  Tallapoosa River                          |  Tallapoosa
Q727892    |  MODvalue  |  name_en     |  Black Warrior River                       |  Black Warrior
Q5338455   |  MODvalue  |  name_en     |  Edisto River                              |  Edisto
Q5338455   |  MODvalue  |  name_nl     |  Edisto River                              |  Edisto
Q8054249   |  MODvalue  |  name_en     |  Yockanookany River                        |  Yockanookany
Q1424101   |  MODvalue  |  name_de     |  Tallapoosa River                          |  Tallapoosa
Q1424101   |  MODvalue  |  name_en     |  Tallapoosa River                          |  Tallapoosa
Q7525853   |  MODvalue  |  name_en     |  Sipsey River                              |  Sipsey
Q7636531   |  MODvalue  |  name_en     |  Sulphur River                             |  Sulphur
Q7405843   |  MODvalue  |  name_en     |  Salt Fork Brazos River                    |  Salt Fork Brazos
Q2041614   |  MODvalue  |  name_de     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_en     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_nl     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_pl     |  Ouachita River                            |  Ouachita
Q2618310   |  MODvalue  |  name_en     |  Saline River                              |  Saline
Q6651659   |  MODvalue  |  name_en     |  Little River                              |  Little
Q14680386  |  MODvalue  |  name_en     |  Hassayampa River                          |  Hassayampa
Q4431935   |  MODvalue  |  name_en     |  South River                               |  South
Q4431935   |  MODvalue  |  name_nl     |  South River                               |  South
Q1341271   |  MODvalue  |  name_de     |  Salt River                                |  Salt
Q1341271   |  MODvalue  |  name_en     |  Salt River                                |  Salt
Q1341271   |  MODvalue  |  name_it     |  Salt River                                |  Salt
Q1341271   |  MODvalue  |  name_nl     |  Salt River                                |  Salt
Q1341271   |  NEWvalue  |  name_pl     |                                            |  Salt
Q8665483   |  MODvalue  |  name_en     |  Black River                               |  Black
Q8665483   |  MODvalue  |  name_fr     |  Black River                               |  Black
Q2390504   |  MODvalue  |  name_de     |  Tallahatchie River                        |  Tallahatchie
Q2390504   |  MODvalue  |  name_en     |  Tallahatchie River                        |  Tallahatchie
Q2599098   |  MODvalue  |  name_de     |  Yalobusha River                           |  Yalobusha
Q2599098   |  MODvalue  |  name_en     |  Yalobusha River                           |  Yalobusha
Q2599098   |  MODvalue  |  name_fr     |  Yalobusha River                           |  Yalobusha
Q2599098   |  MODvalue  |  name_nl     |  Yalobusha River                           |  Yalobusha
Q4107580   |  MODvalue  |  name_en     |  Verde River                               |  Verde
Q1341271   |  MODvalue  |  name_de     |  Salt River                                |  Salt
Q1341271   |  MODvalue  |  name_en     |  Salt River                                |  Salt
Q1341271   |  MODvalue  |  name_it     |  Salt River                                |  Salt
Q1341271   |  MODvalue  |  name_nl     |  Salt River                                |  Salt
Q1341271   |  NEWvalue  |  name_pl     |                                            |  Salt
Q6933808   |  MODvalue  |  name_en     |  Mulberry Fork of the Black Warrior River  |  Mulberry Fork of the Black Warrior
Q6666097   |  MODvalue  |  name_en     |  Locust Fork of the Black Warrior River    |  Locust Fork of the Black Warrior
Q7958732   |  MODvalue  |  name_en     |  Waccamaw River                            |  Waccamaw
Q6651668   |  MODvalue  |  name_en     |  Little River                              |  Little
Q9372502   |  MODvalue  |  name_en     |  Wichita River                             |  Wichita
Q9372502   |  MODvalue  |  name_nl     |  Wichita River                             |  Wichita
Q1341271   |  MODvalue  |  name_de     |  Salt River                                |  Salt
Q1341271   |  MODvalue  |  name_en     |  Salt River                                |  Salt
Q1341271   |  MODvalue  |  name_it     |  Salt River                                |  Salt
Q1341271   |  MODvalue  |  name_nl     |  Salt River                                |  Salt
Q1341271   |  NEWvalue  |  name_pl     |                                            |  Salt
Q9372502   |  MODvalue  |  name_en     |  Wichita River                             |  Wichita
Q9372502   |  MODvalue  |  name_nl     |  Wichita River                             |  Wichita
Q6651298   |  MODvalue  |  name_en     |  Little Pee Dee River                      |  Little Pee Dee
Q6651298   |  MODvalue  |  name_nl     |  Little Pee Dee River                      |  Little Pee Dee
Q9372502   |  MODvalue  |  name_en     |  Wichita River                             |  Wichita
Q9372502   |  MODvalue  |  name_nl     |  Wichita River                             |  Wichita
Q3566675   |  MODvalue  |  name_en     |  Wateree River                             |  Wateree
Q3566675   |  MODvalue  |  name_nl     |  Wateree River                             |  Wateree
Q6651668   |  MODvalue  |  name_en     |  Little River                              |  Little
Q2599098   |  MODvalue  |  name_de     |  Yalobusha River                           |  Yalobusha
Q2599098   |  MODvalue  |  name_en     |  Yalobusha River                           |  Yalobusha
Q2599098   |  MODvalue  |  name_fr     |  Yalobusha River                           |  Yalobusha
Q2599098   |  MODvalue  |  name_nl     |  Yalobusha River                           |  Yalobusha
Q7525851   |  MODvalue  |  name_en     |  Sipsey Fork of the Black Warrior River    |  Sipsey Fork of the Black Warrior
Q6933808   |  MODvalue  |  name_en     |  Mulberry Fork of the Black Warrior River  |  Mulberry Fork of the Black Warrior
Q6708487   |  MODvalue  |  name_en     |  Lynches River                             |  Lynches
Q6708487   |  MODvalue  |  name_nl     |  Lynches River                             |  Lynches
Q851368    |  MODvalue  |  name_de     |  Oconee River                              |  Oconee
Q851368    |  MODvalue  |  name_en     |  Oconee River                              |  Oconee
Q851368    |  MODvalue  |  name_nl     |  Oconee River                              |  Oconee
Q16999546  |  MODvalue  |  name_en     |  New River                                 |  New
Q1152278   |  MODvalue  |  name_de     |  Little Colorado River                     |  Little Colorado
Q1152278   |  MODvalue  |  name_en     |  Little Colorado River                     |  Little Colorado
Q1152278   |  MODvalue  |  name_nl     |  Little Colorado River                     |  Little Colorado
Q7406275   |  MODvalue  |  name_en     |  Saluda River                              |  Saluda
Q7406275   |  MODvalue  |  name_nl     |  Saluda River                              |  Saluda
Q968071    |  MODvalue  |  name_de     |  Etowah River                              |  Etowah
Q968071    |  MODvalue  |  name_en     |  Etowah River                              |  Etowah
Q1034421   |  MODvalue  |  name_de     |  Cape Fear River                           |  Cape Fear
Q1034421   |  MODvalue  |  name_en     |  Cape Fear River                           |  Cape Fear
Q1034421   |  MODvalue  |  name_nl     |  Cape Fear River                           |  Cape Fear
Q2993598   |  MODvalue  |  name_de     |  Washita River                             |  Washita
Q2993598   |  MODvalue  |  name_en     |  Washita River                             |  Washita
Q2993598   |  MODvalue  |  name_pl     |  Washita River                             |  Washita
Q862650    |  MODvalue  |  name_de     |  Bill Williams River                       |  Bill Williams
Q862650    |  MODvalue  |  name_en     |  Bill Williams River                       |  Bill Williams
Q862650    |  MODvalue  |  name_nl     |  Bill Williams River                       |  Bill Williams
Q968071    |  MODvalue  |  name_de     |  Etowah River                              |  Etowah
Q968071    |  MODvalue  |  name_en     |  Etowah River                              |  Etowah
Q2024844   |  MODvalue  |  name_de     |  Oostanaula River                          |  Oostanaula
Q2024844   |  MODvalue  |  name_en     |  Oostanaula River                          |  Oostanaula
Q2024844   |  MODvalue  |  name_fr     |  Oostanaula River                          |  Oostanaula
Q2024844   |  MODvalue  |  name_nl     |  Oostanaula River                          |  Oostanaula
Q6651668   |  MODvalue  |  name_en     |  Little River                              |  Little
Q859220    |  MODvalue  |  name_de     |  Big Sandy River                           |  Big Sandy
Q859220    |  MODvalue  |  name_en     |  Big Sandy River                           |  Big Sandy
Q7419695   |  MODvalue  |  name_en     |  Santa Maria River                         |  Santa Maria
Q7406275   |  MODvalue  |  name_en     |  Saluda River                              |  Saluda
Q7406275   |  MODvalue  |  name_nl     |  Saluda River                              |  Saluda
Q7055420   |  MODvalue  |  name_en     |  North Fork Red River                      |  North Fork Red
Q1050460   |  MODvalue  |  name_de     |  Catawba River                             |  Catawba
Q1050460   |  MODvalue  |  name_en     |  Catawba River                             |  Catawba
Q1050460   |  MODvalue  |  name_nl     |  Catawba River                             |  Catawba
Q859220    |  MODvalue  |  name_de     |  Big Sandy River                           |  Big Sandy
Q859220    |  MODvalue  |  name_en     |  Big Sandy River                           |  Big Sandy
Q5158226   |  MODvalue  |  name_en     |  Conasauga River                           |  Conasauga
Q2041614   |  MODvalue  |  name_de     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_en     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_nl     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_pl     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_de     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_en     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_nl     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_pl     |  Ouachita River                            |  Ouachita
Q5681137   |  MODvalue  |  name_en     |  Hatchie River                             |  Hatchie
Q1152278   |  MODvalue  |  name_de     |  Little Colorado River                     |  Little Colorado
Q1152278   |  MODvalue  |  name_en     |  Little Colorado River                     |  Little Colorado
Q1152278   |  MODvalue  |  name_nl     |  Little Colorado River                     |  Little Colorado
Q5015966   |  MODvalue  |  name_en     |  Cache River                               |  Cache
Q4450532   |  MODvalue  |  name_en     |  Tallulah River                            |  Tallulah
Q5364109   |  MODvalue  |  name_en     |  Elk River                                 |  Elk
Q5364109   |  MODvalue  |  name_pl     |  Elk River                                 |  Elk
Q1152278   |  MODvalue  |  name_de     |  Little Colorado River                     |  Little Colorado
Q1152278   |  MODvalue  |  name_en     |  Little Colorado River                     |  Little Colorado
Q1152278   |  MODvalue  |  name_nl     |  Little Colorado River                     |  Little Colorado
Q4384912   |  MODvalue  |  name_en     |  Puerco River                              |  Puerco
Q24761469  |  MODvalue  |  name_en     |  Petit Jean River                          |  Petit Jean
Q3138706   |  MODvalue  |  name_en     |  Hiwassee River                            |  Hiwassee
Q1606944   |  MODvalue  |  name_de     |  Neuse River                               |  Neuse
Q1606944   |  MODvalue  |  name_en     |  Neuse River                               |  Neuse
Q1606944   |  MODvalue  |  name_fr     |  Neuse River                               |  Neuse
Q1050460   |  MODvalue  |  name_de     |  Catawba River                             |  Catawba
Q1050460   |  MODvalue  |  name_en     |  Catawba River                             |  Catawba
Q1050460   |  MODvalue  |  name_nl     |  Catawba River                             |  Catawba
Q597753    |  MODvalue  |  name_de     |  Canadian River                            |  Canadian
Q597753    |  MODvalue  |  name_en     |  Canadian River                            |  Canadian
Q597753    |  MODvalue  |  name_nl     |  Canadian River                            |  Canadian
Q597753    |  MODvalue  |  name_pl     |  Canadian River                            |  Canadian
Q5364109   |  MODvalue  |  name_en     |  Elk River                                 |  Elk
Q5364109   |  MODvalue  |  name_pl     |  Elk River                                 |  Elk
Q1126662   |  MODvalue  |  name_de     |  Kern River                                |  Kern
Q1126662   |  MODvalue  |  name_en     |  Kern River                                |  Kern
Q1126662   |  MODvalue  |  name_fr     |  Kern River                                |  Kern
Q1126662   |  MODvalue  |  name_nl     |  Kern River                                |  Kern
Q478303    |  MODvalue  |  name_de     |  French Broad River                        |  French Broad
Q478303    |  MODvalue  |  name_en     |  French Broad River                        |  French Broad
Q478303    |  MODvalue  |  name_nl     |  French Broad River                        |  French Broad
Q7193324   |  MODvalue  |  name_en     |  Pigeon River                              |  Pigeon
Q7193324   |  MODvalue  |  name_nl     |  Pigeon River                              |  Pigeon
Q1126662   |  MODvalue  |  name_de     |  Kern River                                |  Kern
Q1126662   |  MODvalue  |  name_en     |  Kern River                                |  Kern
Q1126662   |  MODvalue  |  name_fr     |  Kern River                                |  Kern
Q1126662   |  MODvalue  |  name_nl     |  Kern River                                |  Kern
Q516393    |  MODvalue  |  name_en     |  Neosho River                              |  Neosho
Q943521    |  MODvalue  |  name_en     |  Verdigris River                           |  Verdigris
Q943521    |  MODvalue  |  name_nl     |  Verdigris River                           |  Verdigris
Q1092055   |  MODvalue  |  name_de     |  Cimarron River                            |  Cimarron
Q1092055   |  MODvalue  |  name_en     |  Cimarron River                            |  Cimarron
Q1092055   |  MODvalue  |  name_nl     |  Cimarron River                            |  Cimarron
Q1101503   |  MODvalue  |  name_de     |  Clinch River                              |  Clinch
Q1101503   |  MODvalue  |  name_en     |  Clinch River                              |  Clinch
Q1101503   |  MODvalue  |  name_nl     |  Clinch River                              |  Clinch
Q1101503   |  MODvalue  |  name_de     |  Clinch River                              |  Clinch
Q1101503   |  MODvalue  |  name_en     |  Clinch River                              |  Clinch
Q1101503   |  MODvalue  |  name_nl     |  Clinch River                              |  Clinch
Q1339067   |  MODvalue  |  name_de     |  Emory River                               |  Emory
Q1339067   |  MODvalue  |  name_en     |  Emory River                               |  Emory
Q1775363   |  MODvalue  |  name_de     |  Nolichucky River                          |  Nolichucky
Q1775363   |  MODvalue  |  name_en     |  Nolichucky River                          |  Nolichucky
Q1775363   |  MODvalue  |  name_nl     |  Nolichucky River                          |  Nolichucky
Q7074971   |  MODvalue  |  name_en     |  Obion River                               |  Obion
Q5469813   |  MODvalue  |  name_en     |  Forked Deer River                         |  Forked Deer
Q7074971   |  MODvalue  |  name_en     |  Obion River                               |  Obion
Q478303    |  MODvalue  |  name_de     |  French Broad River                        |  French Broad
Q478303    |  MODvalue  |  name_en     |  French Broad River                        |  French Broad
Q478303    |  MODvalue  |  name_nl     |  French Broad River                        |  French Broad
Q478303    |  MODvalue  |  name_de     |  French Broad River                        |  French Broad
Q478303    |  MODvalue  |  name_en     |  French Broad River                        |  French Broad
Q478303    |  MODvalue  |  name_nl     |  French Broad River                        |  French Broad
Q1775363   |  MODvalue  |  name_de     |  Nolichucky River                          |  Nolichucky
Q1775363   |  MODvalue  |  name_en     |  Nolichucky River                          |  Nolichucky
Q1775363   |  MODvalue  |  name_nl     |  Nolichucky River                          |  Nolichucky
Q2913438   |  MODvalue  |  name_de     |  Eno River                                 |  Eno
Q2913438   |  MODvalue  |  name_en     |  Eno River                                 |  Eno
Q38930502  |  REDIRECT  |  wikidataid  |  Q38930502                                 |  Q34781055
Q516393    |  MODvalue  |  name_en     |  Neosho River                              |  Neosho
Q2008746   |  MODvalue  |  name_de     |  Obed River                                |  Obed
Q2008746   |  MODvalue  |  name_en     |  Obed River                                |  Obed
Q2008746   |  MODvalue  |  name_nl     |  Obed River                                |  Obed
Q5457781   |  MODvalue  |  name_en     |  Flat River                                |  Flat
Q5457781   |  MODvalue  |  name_nl     |  Flat River                                |  Flat
Q597753    |  MODvalue  |  name_de     |  Canadian River                            |  Canadian
Q597753    |  MODvalue  |  name_en     |  Canadian River                            |  Canadian
Q597753    |  MODvalue  |  name_nl     |  Canadian River                            |  Canadian
Q597753    |  MODvalue  |  name_pl     |  Canadian River                            |  Canadian
Q5015966   |  MODvalue  |  name_en     |  Cache River                               |  Cache
Q5195078   |  MODvalue  |  name_en     |  Current River                             |  Current
Q841782    |  MODvalue  |  name_de     |  Chowan River                              |  Chowan
Q841782    |  MODvalue  |  name_en     |  Chowan River                              |  Chowan
Q841782    |  MODvalue  |  name_nl     |  Chowan River                              |  Chowan
Q1159151   |  MODvalue  |  name_de     |  Dan River                                 |  Dan
Q1159151   |  MODvalue  |  name_en     |  Dan River                                 |  Dan
Q1159151   |  MODvalue  |  name_fr     |  Dan River                                 |  Dan
Q1159151   |  MODvalue  |  name_hu     |  Dan River                                 |  Dan
Q1159151   |  MODvalue  |  name_nl     |  Dan River                                 |  Dan
Q1101503   |  MODvalue  |  name_de     |  Clinch River                              |  Clinch
Q1101503   |  MODvalue  |  name_en     |  Clinch River                              |  Clinch
Q1101503   |  MODvalue  |  name_nl     |  Clinch River                              |  Clinch
Q1264687   |  MODvalue  |  name_de     |  Kings River                               |  Kings
Q1264687   |  MODvalue  |  name_en     |  Kings River                               |  Kings
Q1264687   |  MODvalue  |  name_nl     |  Kings River                               |  Kings
Q206710    |  MODvalue  |  name_de     |  Powell River                              |  Powell
Q206710    |  MODvalue  |  name_en     |  Powell River                              |  Powell
Q6809486   |  MODvalue  |  name_de     |  Meherrin River                            |  Meherrin
Q6809486   |  MODvalue  |  name_en     |  Meherrin River                            |  Meherrin
Q6809486   |  MODvalue  |  name_nl     |  Meherrin River                            |  Meherrin
Q841782    |  MODvalue  |  name_de     |  Chowan River                              |  Chowan
Q841782    |  MODvalue  |  name_en     |  Chowan River                              |  Chowan
Q841782    |  MODvalue  |  name_nl     |  Chowan River                              |  Chowan
Q4878160   |  MODvalue  |  name_en     |  Beaver River                              |  Beaver
Q2304481   |  MODvalue  |  name_de     |  South Fork Holston River                  |  South Fork Holston
Q2304481   |  MODvalue  |  name_en     |  South Fork Holston River                  |  South Fork Holston
Q2319307   |  MODvalue  |  name_en     |  Owens River                               |  Owens
Q2319307   |  NEWvalue  |  name_it     |                                            |  Owens
Q2319307   |  MODvalue  |  name_nl     |  Owens River                               |  Owens
Q1676970   |  MODvalue  |  name_de     |  Virgin River                              |  Virgin
Q1676970   |  MODvalue  |  name_en     |  Virgin River                              |  Virgin
Q1676970   |  MODvalue  |  name_it     |  Virgin River                              |  Virgin
Q1676970   |  MODvalue  |  name_nl     |  Virgin River                              |  Virgin
Q7074899   |  MODvalue  |  name_en     |  Obey River                                |  Obey
Q7063766   |  MODvalue  |  name_en     |  Nottoway River                            |  Nottoway
Q7063766   |  MODvalue  |  name_nl     |  Nottoway River                            |  Nottoway
Q2215316   |  MODvalue  |  name_de     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_en     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_fr     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_it     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_nl     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q4878160   |  MODvalue  |  name_en     |  Beaver River                              |  Beaver
Q2215316   |  MODvalue  |  name_de     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_en     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_fr     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_it     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_nl     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q4515856   |  MODvalue  |  name_en     |  Chikaskia River                           |  Chikaskia
Q1931858   |  MODvalue  |  name_de     |  Middle Fork Holston River                 |  Middle Fork Holston
Q2615286   |  MODvalue  |  name_en     |  Animas River                              |  Animas
Q943521    |  MODvalue  |  name_en     |  Verdigris River                           |  Verdigris
Q943521    |  MODvalue  |  name_nl     |  Verdigris River                           |  Verdigris
Q2215316   |  MODvalue  |  name_de     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_en     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_fr     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_it     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q2215316   |  MODvalue  |  name_nl     |  Salt Fork Arkansas River                  |  Salt Fork Arkansas
Q1916292   |  MODvalue  |  name_de     |  Medicine Lodge River                      |  Medicine Lodge
Q1916292   |  MODvalue  |  name_en     |  Medicine Lodge River                      |  Medicine Lodge
Q1916292   |  MODvalue  |  name_fr     |  Medicine Lodge River                      |  Medicine Lodge
Q1916292   |  MODvalue  |  name_nl     |  Medicine Lodge River                      |  Medicine Lodge
Q1092055   |  MODvalue  |  name_de     |  Cimarron River                            |  Cimarron
Q1092055   |  MODvalue  |  name_en     |  Cimarron River                            |  Cimarron
Q1092055   |  MODvalue  |  name_nl     |  Cimarron River                            |  Cimarron
Q516393    |  MODvalue  |  name_en     |  Neosho River                              |  Neosho
Q4863378   |  MODvalue  |  name_en     |  Barren River                              |  Barren
Q4863378   |  MODvalue  |  name_nl     |  Barren River                              |  Barren
Q1108022   |  MODvalue  |  name_de     |  Saint Francis River                       |  Saint Francis
Q1108022   |  MODvalue  |  name_en     |  St. Francis River                         |  St. Francis
Q1108022   |  MODvalue  |  name_nl     |  St. Francis River                         |  St. Francis
Q1108022   |  MODvalue  |  name_pl     |  Saint Francis River                       |  Saint Francis
Q4113850   |  MODvalue  |  name_en     |  Purgatoire River                          |  Purgatoire
Q652618    |  MODvalue  |  name_de     |  Duck River                                |  Duck
Q652618    |  MODvalue  |  name_en     |  Duck River                                |  Duck
Q652618    |  MODvalue  |  name_pl     |  Duck River                                |  Duck
Q5250264   |  MODvalue  |  name_en     |  Deep River                                |  Deep
Q5250264   |  MODvalue  |  name_nl     |  Deep River                                |  Deep
Q5999623   |  MODvalue  |  name_en     |  Illinois River                            |  Illinois
Q841725    |  MODvalue  |  name_de     |  Tar River                                 |  Tar
Q841725    |  MODvalue  |  name_en     |  Tar River                                 |  Tar
Q841725    |  MODvalue  |  name_fr     |  Tar River                                 |  Tar
Q841725    |  MODvalue  |  name_nl     |  Tar River                                 |  Tar
Q597753    |  MODvalue  |  name_de     |  Canadian River                            |  Canadian
Q597753    |  MODvalue  |  name_en     |  Canadian River                            |  Canadian
Q597753    |  MODvalue  |  name_nl     |  Canadian River                            |  Canadian
Q597753    |  MODvalue  |  name_pl     |  Canadian River                            |  Canadian
Q1050460   |  MODvalue  |  name_de     |  Catawba River                             |  Catawba
Q1050460   |  MODvalue  |  name_en     |  Catawba River                             |  Catawba
Q1050460   |  MODvalue  |  name_nl     |  Catawba River                             |  Catawba
Q1544647   |  MODvalue  |  name_de     |  Green River                               |  Green
Q1544647   |  MODvalue  |  name_en     |  Green River                               |  Green
Q1544647   |  MODvalue  |  name_pl     |  Green River                               |  Green
Q1544647   |  MODvalue  |  name_de     |  Green River                               |  Green
Q1544647   |  MODvalue  |  name_en     |  Green River                               |  Green
Q1544647   |  MODvalue  |  name_pl     |  Green River                               |  Green
Q1544647   |  MODvalue  |  name_de     |  Green River                               |  Green
Q1544647   |  MODvalue  |  name_en     |  Green River                               |  Green
Q1544647   |  MODvalue  |  name_pl     |  Green River                               |  Green
Q886078    |  MODvalue  |  name_de     |  Bluestone River                           |  Bluestone
Q886078    |  MODvalue  |  name_en     |  Bluestone River                           |  Bluestone
Q886078    |  MODvalue  |  name_fr     |  Bluestone River                           |  Bluestone
Q886078    |  MODvalue  |  name_nl     |  Bluestone River                           |  Bluestone
Q886078    |  MODvalue  |  name_de     |  Bluestone River                           |  Bluestone
Q886078    |  MODvalue  |  name_en     |  Bluestone River                           |  Bluestone
Q886078    |  MODvalue  |  name_fr     |  Bluestone River                           |  Bluestone
Q886078    |  MODvalue  |  name_nl     |  Bluestone River                           |  Bluestone
Q1470035   |  MODvalue  |  name_de     |  Merced River                              |  Merced
Q1470035   |  MODvalue  |  name_en     |  Merced River                              |  Merced
Q1470035   |  MODvalue  |  name_nl     |  Merced River                              |  Merced
Q1470035   |  NEWvalue  |  name_pl     |                                            |  Merced
Q1236386   |  MODvalue  |  name_de     |  Dolores River                             |  Dolores
Q1236386   |  MODvalue  |  name_en     |  Dolores River                             |  Dolores
Q1921090   |  MODvalue  |  name_de     |  Meramec River                             |  Meramec
Q1921090   |  MODvalue  |  name_en     |  Meramec River                             |  Meramec
Q1921090   |  MODvalue  |  name_nl     |  Meramec River                             |  Meramec
Q606566    |  MODvalue  |  name_en     |  Licking River                             |  Licking
Q606566    |  MODvalue  |  name_pl     |  Licking River                             |  Licking
Q2258289   |  MODvalue  |  name_en     |  York River                                |  York
Q2258289   |  MODvalue  |  name_fr     |  York River                                |  York
Q2258289   |  MODvalue  |  name_it     |  York River                                |  York
Q859080    |  MODvalue  |  name_de     |  Big Muddy River                           |  Big Muddy
Q859080    |  MODvalue  |  name_en     |  Big Muddy River                           |  Big Muddy
Q859080    |  MODvalue  |  name_fr     |  Big Muddy River                           |  Big Muddy
Q859080    |  MODvalue  |  name_nl     |  Big Muddy River                           |  Big Muddy
Q2340104   |  MODvalue  |  name_de     |  Guyandotte River                          |  Guyandotte
Q2340104   |  MODvalue  |  name_en     |  Guyandotte River                          |  Guyandotte
Q2340104   |  MODvalue  |  name_pl     |  Guyandotte River                          |  Guyandotte
Q1807419   |  MODvalue  |  name_de     |  Tuolumne River                            |  Tuolumne
Q1807419   |  MODvalue  |  name_en     |  Tuolumne River                            |  Tuolumne
Q2054792   |  MODvalue  |  name_en     |  Pamunkey River                            |  Pamunkey
Q2054792   |  MODvalue  |  name_fr     |  Pamunkey River                            |  Pamunkey
Q2054792   |  MODvalue  |  name_it     |  Pamunkey River                            |  Pamunkey
Q1544689   |  MODvalue  |  name_de     |  Greenbrier River                          |  Greenbrier
Q1544689   |  MODvalue  |  name_en     |  Greenbrier River                          |  Greenbrier
Q1544689   |  MODvalue  |  name_fr     |  Greenbrier River                          |  Greenbrier
Q1544689   |  MODvalue  |  name_nl     |  Greenbrier River                          |  Greenbrier
Q745070    |  MODvalue  |  name_en     |  Salt River                                |  Salt
Q745070    |  MODvalue  |  name_pl     |  Salt River                                |  Salt
Q12061518  |  MODvalue  |  name_en     |  Maury River                               |  Maury
Q1262279   |  MODvalue  |  name_de     |  Sevier River                              |  Sevier
Q1262279   |  MODvalue  |  name_en     |  Sevier River                              |  Sevier
Q1262279   |  MODvalue  |  name_nl     |  Sevier River                              |  Sevier
Q2126786   |  MODvalue  |  name_de     |  White River                               |  White
Q2126786   |  MODvalue  |  name_en     |  White River                               |  White
Q2126786   |  MODvalue  |  name_fr     |  White River                               |  White
Q2126786   |  MODvalue  |  name_nl     |  White River                               |  White
Q2126786   |  MODvalue  |  name_pl     |  White River                               |  White
Q6117354   |  MODvalue  |  name_en     |  Jackson River                             |  Jackson
Q6117354   |  MODvalue  |  name_nl     |  Jackson River                             |  Jackson
Q6652407   |  MODvalue  |  name_de     |  Little Wabash River                       |  Little Wabash
Q6652407   |  MODvalue  |  name_en     |  Little Wabash River                       |  Little Wabash
Q1228216   |  MODvalue  |  name_de     |  Dirty Devil River                         |  Dirty Devil
Q1228216   |  MODvalue  |  name_en     |  Dirty Devil River                         |  Dirty Devil
Q1228216   |  MODvalue  |  name_nl     |  Dirty Devil River                         |  Dirty Devil
Q1228216   |  MODvalue  |  name_de     |  Dirty Devil River                         |  Dirty Devil
Q1228216   |  MODvalue  |  name_en     |  Dirty Devil River                         |  Dirty Devil
Q1228216   |  MODvalue  |  name_nl     |  Dirty Devil River                         |  Dirty Devil
Q745070    |  MODvalue  |  name_en     |  Salt River                                |  Salt
Q745070    |  MODvalue  |  name_pl     |  Salt River                                |  Salt
Q3256709   |  MODvalue  |  name_en     |  Little Osage River                        |  Little Osage
Q7568327   |  MODvalue  |  name_en     |  South River                               |  South
Q606566    |  MODvalue  |  name_en     |  Licking River                             |  Licking
Q606566    |  MODvalue  |  name_pl     |  Licking River                             |  Licking
Q1333499   |  MODvalue  |  name_de     |  Rappahannock River                        |  Rappahannock
Q1333499   |  MODvalue  |  name_en     |  Rappahannock River                        |  Rappahannock
Q1333499   |  MODvalue  |  name_pl     |  Rappahannock River                        |  Rappahannock
Q786533    |  MODvalue  |  name_de     |  Mokelumne River                           |  Mokelumne
Q786533    |  MODvalue  |  name_en     |  Mokelumne River                           |  Mokelumne
Q786533    |  MODvalue  |  name_nl     |  Mokelumne River                           |  Mokelumne
Q5175833   |  MODvalue  |  name_en     |  Cottonwood River                          |  Cottonwood
Q1130341   |  MODvalue  |  name_de     |  Fremont River                             |  Fremont
Q1130341   |  MODvalue  |  name_en     |  Fremont River                             |  Fremont
Q1130341   |  MODvalue  |  name_nl     |  Fremont River                             |  Fremont
Q5364110   |  MODvalue  |  name_de     |  Elk River                                 |  Elk
Q5364110   |  MODvalue  |  name_en     |  Elk River                                 |  Elk
Q1333499   |  MODvalue  |  name_de     |  Rappahannock River                        |  Rappahannock
Q1333499   |  MODvalue  |  name_en     |  Rappahannock River                        |  Rappahannock
Q1333499   |  MODvalue  |  name_pl     |  Rappahannock River                        |  Rappahannock
Q2126786   |  MODvalue  |  name_de     |  White River                               |  White
Q2126786   |  MODvalue  |  name_en     |  White River                               |  White
Q2126786   |  MODvalue  |  name_fr     |  White River                               |  White
Q2126786   |  MODvalue  |  name_nl     |  White River                               |  White
Q2126786   |  MODvalue  |  name_pl     |  White River                               |  White
Q2030974   |  MODvalue  |  name_de     |  Russian River                             |  Russian
Q2030974   |  MODvalue  |  name_en     |  Russian River                             |  Russian
Q2030974   |  MODvalue  |  name_fr     |  Russian River                             |  Russian
Q2030974   |  MODvalue  |  name_nl     |  Russian River                             |  Russian
Q2030974   |  MODvalue  |  name_pl     |  Russian River                             |  Russian
Q558645    |  MODvalue  |  name_de     |  Gunnison River                            |  Gunnison
Q558645    |  MODvalue  |  name_en     |  Gunnison River                            |  Gunnison
Q558645    |  MODvalue  |  name_nl     |  Gunnison River                            |  Gunnison
Q671902    |  MODvalue  |  name_de     |  Little Kanawha River                      |  Little Kanawha
Q671902    |  MODvalue  |  name_en     |  Little Kanawha River                      |  Little Kanawha
Q671902    |  MODvalue  |  name_sv     |  Little Kanawha River                      |  Little Kanawha
Q2618310   |  MODvalue  |  name_en     |  Saline River                              |  Saline
Q177627    |  MODvalue  |  name_de     |  Smoky Hill River                          |  Smoky Hill
Q177627    |  MODvalue  |  name_en     |  Smoky Hill River                          |  Smoky Hill
Q4983118   |  MODvalue  |  name_en     |  Buckhannon River                          |  Buckhannon
Q177627    |  MODvalue  |  name_de     |  Smoky Hill River                          |  Smoky Hill
Q177627    |  MODvalue  |  name_en     |  Smoky Hill River                          |  Smoky Hill
Q4113728   |  MODvalue  |  name_en     |  Solomon River                             |  Solomon
Q777907    |  MODvalue  |  name_de     |  Shenandoah River                          |  Shenandoah
Q777907    |  MODvalue  |  name_en     |  Shenandoah River                          |  Shenandoah
Q1262279   |  MODvalue  |  name_de     |  Sevier River                              |  Sevier
Q1262279   |  MODvalue  |  name_en     |  Sevier River                              |  Sevier
Q1262279   |  MODvalue  |  name_nl     |  Sevier River                              |  Sevier
Q1068697   |  MODvalue  |  name_de     |  Cheat River                               |  Cheat
Q1068697   |  MODvalue  |  name_en     |  Cheat River                               |  Cheat
Q1068697   |  MODvalue  |  name_fr     |  Cheat River                               |  Cheat
Q1068697   |  MODvalue  |  name_nl     |  Cheat River                               |  Cheat
Q1068697   |  MODvalue  |  name_sv     |  Cheat River                               |  Cheat
Q246570    |  MODvalue  |  name_de     |  Great Miami River                         |  Great Miami
Q246570    |  MODvalue  |  name_en     |  Great Miami River                         |  Great Miami
Q246570    |  MODvalue  |  name_nl     |  Great Miami River                         |  Great Miami
Q246570    |  MODvalue  |  name_sv     |  Great Miami River                         |  Great Miami
Q14683517  |  MODvalue  |  name_en     |  North Yuba River                          |  North Yuba
Q14711868  |  MODvalue  |  name_en     |  San Pitch River                           |  San Pitch
Q4905162   |  MODvalue  |  name_en     |  Big Blue River                            |  Big Blue
Q5307508   |  MODvalue  |  name_en     |  Driftwood River                           |  Driftwood
Q750839    |  MODvalue  |  name_de     |  Platte River                              |  Platte
Q750839    |  MODvalue  |  name_en     |  Platte River                              |  Platte
Q3695896   |  MODvalue  |  name_en     |  Chariton River                            |  Chariton
Q1470734   |  MODvalue  |  name_de     |  Youghiogheny River                        |  Youghiogheny
Q1470734   |  MODvalue  |  name_en     |  Youghiogheny River                        |  Youghiogheny
Q1470734   |  MODvalue  |  name_fr     |  Youghiogheny River                        |  Youghiogheny
Q1470734   |  MODvalue  |  name_nl     |  Youghiogheny River                        |  Youghiogheny
Q4905160   |  MODvalue  |  name_en     |  Big Blue River                            |  Big Blue
Q4905160   |  MODvalue  |  name_nl     |  Big Blue River                            |  Big Blue
Q1542869   |  MODvalue  |  name_de     |  Grand River                               |  Grand
Q1542869   |  MODvalue  |  name_en     |  Grand River                               |  Grand
Q1542869   |  MODvalue  |  name_fr     |  Grand River                               |  Grand
Q1542869   |  MODvalue  |  name_it     |  Grand River                               |  Grand
Q1542869   |  MODvalue  |  name_nl     |  Grand River                               |  Grand
Q21197106  |  MODvalue  |  name_en     |  North Fork Solomon River                  |  North Fork Solomon
Q21197106  |  MODvalue  |  name_en     |  North Fork Solomon River                  |  North Fork Solomon
Q4905162   |  MODvalue  |  name_en     |  Big Blue River                            |  Big Blue
Q6649195   |  MODvalue  |  name_en     |  Little Blue River                         |  Little Blue
Q4905162   |  MODvalue  |  name_en     |  Big Blue River                            |  Big Blue
Q1807373   |  MODvalue  |  name_de     |  Sangamon River                            |  Sangamon
Q1807373   |  MODvalue  |  name_en     |  Sangamon River                            |  Sangamon
Q1807373   |  MODvalue  |  name_nl     |  Sangamon River                            |  Sangamon
Q5595036   |  MODvalue  |  name_de     |  Grand River                               |  Grand
Q5595036   |  MODvalue  |  name_en     |  Grand River                               |  Grand
Q7795771   |  MODvalue  |  name_de     |  Thompson River                            |  Thompson
Q7795771   |  MODvalue  |  name_en     |  Thompson River                            |  Thompson
Q605122    |  MODvalue  |  name_de     |  Schuylkill River                          |  Schuylkill
Q605122    |  MODvalue  |  name_en     |  Schuylkill River                          |  Schuylkill
Q605122    |  MODvalue  |  name_ja     |  英：Schuylkill River                        |  英：Schuylkill
Q605122    |  MODvalue  |  name_nl     |  Schuylkill River                          |  Schuylkill
Q7046635   |  MODvalue  |  name_en     |  Nodaway River                             |  Nodaway
Q3567786   |  MODvalue  |  name_en     |  White River                               |  White
Q3567786   |  MODvalue  |  name_fr     |  White River                               |  White
Q14683506  |  NEWvalue  |  name_de     |                                            |  North Fork Eel
Q14683506  |  MODvalue  |  name_en     |  North Fork Eel River                      |  North Fork Eel
Q7299385   |  MODvalue  |  name_en     |  Raystown Branch Juniata River             |  Raystown Branch Juniata
Q7921614   |  MODvalue  |  name_de     |  Vermilion River                           |  Vermilion
Q7921614   |  MODvalue  |  name_en     |  Vermilion River                           |  Vermilion
Q673908    |  MODvalue  |  name_de     |  Republican River                          |  Republican
Q673908    |  MODvalue  |  name_en     |  Republican River                          |  Republican
Q673908    |  MODvalue  |  name_nl     |  Republican River                          |  Republican
Q6841425   |  MODvalue  |  name_de     |  Middle Fork Vermilion River               |  Middle Fork Vermilion
Q6841425   |  MODvalue  |  name_en     |  Middle Fork Vermilion River               |  Middle Fork Vermilion
Q1138366   |  MODvalue  |  name_de     |  Walhonding River                          |  Walhonding
Q1138366   |  MODvalue  |  name_en     |  Walhonding River                          |  Walhonding
Q1138366   |  MODvalue  |  name_fr     |  Walhonding River                          |  Walhonding
Q1138366   |  MODvalue  |  name_nl     |  Walhonding River                          |  Walhonding
Q1138366   |  NEWvalue  |  name_zh     |                                            |  沃尔洪丁河
Q2599279   |  MODvalue  |  name_de     |  Yampa River                               |  Yampa
Q2599279   |  MODvalue  |  name_en     |  Yampa River                               |  Yampa
Q2599279   |  MODvalue  |  name_fr     |  Yampa River                               |  Yampa
Q2599279   |  MODvalue  |  name_nl     |  Yampa River                               |  Yampa
Q3966983   |  MODvalue  |  name_en     |  Spoon River                               |  Spoon
Q3966983   |  MODvalue  |  name_nl     |  Spoon River                               |  Spoon
Q1138366   |  MODvalue  |  name_de     |  Walhonding River                          |  Walhonding
Q1138366   |  MODvalue  |  name_en     |  Walhonding River                          |  Walhonding
Q1138366   |  MODvalue  |  name_fr     |  Walhonding River                          |  Walhonding
Q1138366   |  MODvalue  |  name_nl     |  Walhonding River                          |  Walhonding
Q1138366   |  NEWvalue  |  name_zh     |                                            |  沃尔洪丁河
Q1124709   |  MODvalue  |  name_de     |  Conemaugh River                           |  Conemaugh
Q1124709   |  MODvalue  |  name_en     |  Conemaugh River                           |  Conemaugh
Q1124709   |  MODvalue  |  name_nl     |  Conemaugh River                           |  Conemaugh
Q1647544   |  MODvalue  |  name_de     |  Mohican River                             |  Mohican
Q1647544   |  MODvalue  |  name_en     |  Mohican River                             |  Mohican
Q1647544   |  MODvalue  |  name_fr     |  Mohican River                             |  Mohican
Q1647544   |  MODvalue  |  name_nl     |  Mohican River                             |  Mohican
Q476488    |  MODvalue  |  name_de     |  Juniata River                             |  Juniata
Q476488    |  MODvalue  |  name_en     |  Juniata River                             |  Juniata
Q476488    |  MODvalue  |  name_fr     |  Juniata River                             |  Juniata
Q476488    |  MODvalue  |  name_nl     |  Juniata River                             |  Juniata
Q476488    |  MODvalue  |  name_pl     |  Juniata River                             |  Juniata
Q476488    |  MODvalue  |  name_sv     |  Juniata River                             |  Juniata
Q2628381   |  MODvalue  |  name_en     |  Jordan River                              |  Jordan
Q2599279   |  MODvalue  |  name_de     |  Yampa River                               |  Yampa
Q2599279   |  MODvalue  |  name_en     |  Yampa River                               |  Yampa
Q2599279   |  MODvalue  |  name_fr     |  Yampa River                               |  Yampa
Q2599279   |  MODvalue  |  name_nl     |  Yampa River                               |  Yampa
Q1865825   |  MODvalue  |  name_de     |  Little Snake River                        |  Little Snake
Q1865825   |  MODvalue  |  name_en     |  Little Snake River                        |  Little Snake
Q6416767   |  MODvalue  |  name_de     |  Kiskiminetas River                        |  Kiskiminetas
Q6416767   |  MODvalue  |  name_en     |  Kiskiminetas River                        |  Kiskiminetas
Q14704466  |  MODvalue  |  name_de     |  Nishnabotna River                         |  Nishnabotna
Q14704466  |  MODvalue  |  name_en     |  Nishnabotna River                         |  Nishnabotna
Q1713780   |  MODvalue  |  name_de     |  St. Marys River                           |  St. Marys
Q1713780   |  MODvalue  |  name_en     |  St. Marys River                           |  St. Marys
Q1713780   |  NEWvalue  |  name_fr     |                                            |  Rivière Sainte-Marie
Q1136667   |  MODvalue  |  name_de     |  Tippecanoe River                          |  Tippecanoe
Q1136667   |  MODvalue  |  name_en     |  Tippecanoe River                          |  Tippecanoe
Q1136667   |  MODvalue  |  name_nl     |  Tippecanoe River                          |  Tippecanoe
Q866712    |  MODvalue  |  name_de     |  Laramie River                             |  Laramie
Q866712    |  MODvalue  |  name_en     |  Laramie River                             |  Laramie
Q866712    |  MODvalue  |  name_fr     |  Laramie River                             |  Laramie
Q866712    |  MODvalue  |  name_nl     |  Laramie River                             |  Laramie
Q866712    |  MODvalue  |  name_sv     |  Laramie River                             |  Laramie
Q4920789   |  MODvalue  |  name_en     |  Black Fork Mohican River                  |  Black Fork Mohican
Q7537031   |  MODvalue  |  name_de     |  Skunk River                               |  Skunk
Q7537031   |  MODvalue  |  name_en     |  Skunk River                               |  Skunk
Q813500    |  MODvalue  |  name_de     |  Beaver River                              |  Beaver
Q813500    |  MODvalue  |  name_en     |  Beaver River                              |  Beaver
Q813500    |  MODvalue  |  name_nl     |  Beaver River                              |  Beaver
Q674618    |  MODvalue  |  name_de     |  Sandusky River                            |  Sandusky
Q674618    |  MODvalue  |  name_en     |  Sandusky River                            |  Sandusky
Q674618    |  MODvalue  |  name_hu     |  Sandusky River                            |  Sandusky
Q674618    |  MODvalue  |  name_nl     |  Sandusky River                            |  Sandusky
Q674618    |  MODvalue  |  name_pl     |  Sandusky River                            |  Sandusky
Q7272287   |  MODvalue  |  name_en     |  Quinn River                               |  Quinn
Q3695896   |  MODvalue  |  name_en     |  Chariton River                            |  Chariton
Q1288110   |  MODvalue  |  name_de     |  Shenango River                            |  Shenango
Q1288110   |  MODvalue  |  name_en     |  Shenango River                            |  Shenango
Q1288110   |  MODvalue  |  name_nl     |  Shenango River                            |  Shenango
Q1969490   |  MODvalue  |  name_de     |  Trinity River                             |  Trinity
Q1969490   |  MODvalue  |  name_en     |  Trinity River                             |  Trinity
Q1969490   |  MODvalue  |  name_nl     |  Trinity River                             |  Trinity
Q1969490   |  MODvalue  |  name_pl     |  Trinity River                             |  Trinity
Q282052    |  MODvalue  |  name_de     |  Maumee River                              |  Maumee
Q282052    |  MODvalue  |  name_en     |  Maumee River                              |  Maumee
Q282052    |  MODvalue  |  name_nl     |  Maumee River                              |  Maumee
Q282052    |  MODvalue  |  name_pl     |  Maumee River                              |  Maumee
Q1138574   |  MODvalue  |  name_de     |  St. Joseph River                          |  St. Joseph
Q1138574   |  MODvalue  |  name_en     |  St. Joseph River                          |  St. Joseph
Q1146724   |  MODvalue  |  name_de     |  Cuyahoga River                            |  Cuyahoga
Q1146724   |  MODvalue  |  name_en     |  Cuyahoga River                            |  Cuyahoga
Q1146724   |  MODvalue  |  name_nl     |  Cuyahoga River                            |  Cuyahoga
Q1146724   |  MODvalue  |  name_pl     |  Cuyahoga River                            |  Cuyahoga
Q1146724   |  MODvalue  |  name_sv     |  Cuyahoga River                            |  Cuyahoga
Q1631368   |  MODvalue  |  name_de     |  Housatonic River                          |  Housatonic
Q1631368   |  MODvalue  |  name_en     |  Housatonic River                          |  Housatonic
Q1631368   |  MODvalue  |  name_nl     |  Housatonic River                          |  Housatonic
Q1631368   |  NEWvalue  |  name_zh     |                                            |  豪萨托尼河
Q1852004   |  MODvalue  |  name_de     |  Rock River                                |  Rock
Q1852004   |  MODvalue  |  name_en     |  Rock River                                |  Rock
Q1852004   |  MODvalue  |  name_it     |  Rock River                                |  Rock
Q1852004   |  MODvalue  |  name_nl     |  Rock River                                |  Rock
Q1852004   |  MODvalue  |  name_pl     |  Rock River                                |  Rock
Q1852004   |  MODvalue  |  name_pt     |  Rock River                                |  Rock
Q2042749   |  MODvalue  |  name_de     |  Owyhee River                              |  Owyhee
Q2042749   |  MODvalue  |  name_en     |  Owyhee River                              |  Owyhee
Q2042749   |  MODvalue  |  name_nl     |  Owyhee River                              |  Owyhee
Q2926582   |  MODvalue  |  name_en     |  Bruneau River                             |  Bruneau
Q7808710   |  MODvalue  |  name_en     |  Tioga River                               |  Tioga
Q3433802   |  MODvalue  |  name_de     |  St. Joseph River                          |  St. Joseph
Q3433802   |  MODvalue  |  name_en     |  St. Joseph River                          |  St. Joseph
Q3433802   |  MODvalue  |  name_nl     |  St. Joseph River                          |  St. Joseph
Q2548910   |  MODvalue  |  name_de     |  Wapsipinicon River                        |  Wapsipinicon
Q2548910   |  MODvalue  |  name_en     |  Wapsipinicon River                        |  Wapsipinicon
Q2548910   |  MODvalue  |  name_nl     |  Wapsipinicon River                        |  Wapsipinicon
Q1672169   |  MODvalue  |  name_de     |  Iowa River                                |  Iowa
Q1672169   |  MODvalue  |  name_en     |  Iowa River                                |  Iowa
Q1672169   |  MODvalue  |  name_nl     |  Iowa River                                |  Iowa
Q1646498   |  MODvalue  |  name_de     |  Little Sioux River                        |  Little Sioux
Q1646498   |  MODvalue  |  name_en     |  Little Sioux River                        |  Little Sioux
Q880926    |  MODvalue  |  name_de     |  Blackstone River                          |  Blackstone
Q880926    |  MODvalue  |  name_en     |  Blackstone River                          |  Blackstone
Q880926    |  MODvalue  |  name_fr     |  Blackstone River                          |  Blackstone
Q880926    |  MODvalue  |  name_nl     |  Blackstone River                          |  Blackstone
Q1422687   |  MODvalue  |  name_de     |  Genesee River                             |  Genesee
Q1422687   |  MODvalue  |  name_en     |  Genesee River                             |  Genesee
Q1422687   |  MODvalue  |  name_nl     |  Genesee River                             |  Genesee
Q1422687   |  MODvalue  |  name_sv     |  Genesee River                             |  Genesee
Q900828    |  MODvalue  |  name_en     |  Chemung River                             |  Chemung
Q900828    |  MODvalue  |  name_nl     |  Chemung River                             |  Chemung
Q5096490   |  MODvalue  |  name_de     |  Chicopee River                            |  Chicopee
Q5096490   |  MODvalue  |  name_en     |  Chicopee River                            |  Chicopee
Q5141388   |  MODvalue  |  name_en     |  Cohocton River                            |  Cohocton
Q7969256   |  MODvalue  |  name_en     |  Ware River                                |  Ware
Q667197    |  MODvalue  |  name_de     |  Swift River                               |  Swift
Q667197    |  MODvalue  |  name_en     |  Swift River                               |  Swift
Q667197    |  MODvalue  |  name_nl     |  Swift River                               |  Swift
Q615010    |  MODvalue  |  name_de     |  Kalamazoo River                           |  Kalamazoo
Q615010    |  MODvalue  |  name_en     |  Kalamazoo River                           |  Kalamazoo
Q615010    |  MODvalue  |  name_nl     |  Kalamazoo River                           |  Kalamazoo
Q1444096   |  MODvalue  |  name_de     |  Sweetwater River                          |  Sweetwater
Q1444096   |  MODvalue  |  name_en     |  Sweetwater River                          |  Sweetwater
Q1444096   |  MODvalue  |  name_nl     |  Sweetwater River                          |  Sweetwater
Q1444096   |  MODvalue  |  name_pl     |  Sweetwater River                          |  Sweetwater
Q1444096   |  MODvalue  |  name_sv     |  Sweetwater River                          |  Sweetwater
Q1444096   |  NEWvalue  |  name_zh     |                                            |  甘霖河
Q1444096   |  MODvalue  |  name_de     |  Sweetwater River                          |  Sweetwater
Q1444096   |  MODvalue  |  name_en     |  Sweetwater River                          |  Sweetwater
Q1444096   |  MODvalue  |  name_nl     |  Sweetwater River                          |  Sweetwater
Q1444096   |  MODvalue  |  name_pl     |  Sweetwater River                          |  Sweetwater
Q1444096   |  MODvalue  |  name_sv     |  Sweetwater River                          |  Sweetwater
Q1444096   |  NEWvalue  |  name_zh     |                                            |  甘霖河
Q1124558   |  MODvalue  |  name_de     |  Niobrara River                            |  Niobrara
Q1124558   |  MODvalue  |  name_en     |  Niobrara River                            |  Niobrara
Q1124558   |  MODvalue  |  name_nl     |  Niobrara River                            |  Niobrara
Q3506776   |  MODvalue  |  name_en     |  Sycan River                               |  Sycan
Q1430371   |  MODvalue  |  name_de     |  Floyd River                               |  Floyd
Q1430371   |  MODvalue  |  name_en     |  Floyd River                               |  Floyd
Q1430371   |  MODvalue  |  name_fr     |  Floyd River                               |  Floyd
Q1430371   |  MODvalue  |  name_nl     |  Floyd River                               |  Floyd
Q859274    |  MODvalue  |  name_de     |  Big Sioux River                           |  Big Sioux
Q859274    |  MODvalue  |  name_en     |  Big Sioux River                           |  Big Sioux
Q859274    |  MODvalue  |  name_nl     |  Big Sioux River                           |  Big Sioux
Q2581283   |  MODvalue  |  name_de     |  Williamson River                          |  Williamson
Q2581283   |  MODvalue  |  name_en     |  Williamson River                          |  Williamson
Q2581283   |  MODvalue  |  name_nl     |  Williamson River                          |  Williamson
Q4086416   |  MODvalue  |  name_en     |  Big Wood River                            |  Big Wood
Q1852004   |  MODvalue  |  name_de     |  Rock River                                |  Rock
Q1852004   |  MODvalue  |  name_en     |  Rock River                                |  Rock
Q1852004   |  MODvalue  |  name_it     |  Rock River                                |  Rock
Q1852004   |  MODvalue  |  name_nl     |  Rock River                                |  Rock
Q1852004   |  MODvalue  |  name_pl     |  Rock River                                |  Rock
Q1852004   |  MODvalue  |  name_pt     |  Rock River                                |  Rock
Q1422687   |  MODvalue  |  name_de     |  Genesee River                             |  Genesee
Q1422687   |  MODvalue  |  name_en     |  Genesee River                             |  Genesee
Q1422687   |  MODvalue  |  name_nl     |  Genesee River                             |  Genesee
Q1422687   |  MODvalue  |  name_sv     |  Genesee River                             |  Genesee
Q6942769   |  MODvalue  |  name_de     |  Muskegon River                            |  Muskegon
Q6942769   |  MODvalue  |  name_en     |  Muskegon River                            |  Muskegon
Q1326803   |  MODvalue  |  name_de     |  Umpqua River                              |  Umpqua
Q1326803   |  MODvalue  |  name_en     |  Umpqua River                              |  Umpqua
Q374888    |  MODvalue  |  name_de     |  Shiawassee River                          |  Shiawassee
Q374888    |  MODvalue  |  name_en     |  Shiawassee River                          |  Shiawassee
Q3529640   |  MODvalue  |  name_de     |  Tittabawassee River                       |  Tittabawassee
Q3529640   |  MODvalue  |  name_en     |  Tittabawassee River                       |  Tittabawassee
Q455185    |  MODvalue  |  name_de     |  Saginaw River                             |  Saginaw
Q455185    |  MODvalue  |  name_en     |  Saginaw River                             |  Saginaw
Q455185    |  MODvalue  |  name_nl     |  Saginaw River                             |  Saginaw
Q968475    |  MODvalue  |  name_de     |  Black River                               |  Black
Q968475    |  MODvalue  |  name_en     |  Black River                               |  Black
Q968475    |  MODvalue  |  name_nl     |  Black River                               |  Black
Q1748794   |  MODvalue  |  name_de     |  Winnipesaukee River                       |  Winnipesaukee
Q1748794   |  MODvalue  |  name_en     |  Winnipesaukee River                       |  Winnipesaukee
Q1748794   |  MODvalue  |  name_fr     |  Winnipesaukee River                       |  Winnipesaukee
Q1748794   |  MODvalue  |  name_nl     |  Winnipesaukee River                       |  Winnipesaukee
Q2210898   |  MODvalue  |  name_de     |  Saco River                                |  Saco
Q2210898   |  MODvalue  |  name_en     |  Saco River                                |  Saco
Q2210898   |  MODvalue  |  name_fr     |  Saco River                                |  Saco
Q2210898   |  MODvalue  |  name_nl     |  Saco River                                |  Saco
Q859274    |  MODvalue  |  name_de     |  Big Sioux River                           |  Big Sioux
Q859274    |  MODvalue  |  name_en     |  Big Sioux River                           |  Big Sioux
Q859274    |  MODvalue  |  name_nl     |  Big Sioux River                           |  Big Sioux
Q4905972   |  MODvalue  |  name_en     |  Big Lost River                            |  Big Lost
Q891080    |  MODvalue  |  name_de     |  Boise River                               |  Boise
Q891080    |  MODvalue  |  name_en     |  Boise River                               |  Boise
Q891080    |  MODvalue  |  name_nl     |  Boise River                               |  Boise
Q594295    |  MODvalue  |  name_de     |  Malheur River                             |  Malheur
Q594295    |  MODvalue  |  name_en     |  Malheur River                             |  Malheur
Q891080    |  MODvalue  |  name_de     |  Boise River                               |  Boise
Q891080    |  MODvalue  |  name_en     |  Boise River                               |  Boise
Q891080    |  MODvalue  |  name_nl     |  Boise River                               |  Boise
Q815836    |  MODvalue  |  name_de     |  Belle Fourche River                       |  Belle Fourche
Q815836    |  MODvalue  |  name_en     |  Belle Fourche River                       |  Belle Fourche
Q815836    |  MODvalue  |  name_nl     |  Belle Fourche River                       |  Belle Fourche
Q815836    |  MODvalue  |  name_pl     |  Belle Fourche River                       |  Belle Fourche
Q815836    |  MODvalue  |  name_sv     |  Belle Fourche River                       |  Belle Fourche
Q2042749   |  MODvalue  |  name_de     |  Owyhee River                              |  Owyhee
Q2042749   |  MODvalue  |  name_en     |  Owyhee River                              |  Owyhee
Q2042749   |  MODvalue  |  name_nl     |  Owyhee River                              |  Owyhee
Q2096785   |  MODvalue  |  name_de     |  Powder River                              |  Powder
Q2096785   |  MODvalue  |  name_en     |  Powder River                              |  Powder
Q2096785   |  MODvalue  |  name_nl     |  Powder River                              |  Powder
Q2096785   |  MODvalue  |  name_pl     |  Powder River                              |  Powder
Q2096785   |  MODvalue  |  name_sv     |  Powder River                              |  Powder
Q387103    |  MODvalue  |  name_de     |  Deschutes River                           |  Deschutes
Q387103    |  MODvalue  |  name_en     |  Deschutes River                           |  Deschutes
Q387103    |  MODvalue  |  name_fr     |  Deschutes River                           |  Deschutes
Q387103    |  MODvalue  |  name_nl     |  Deschutes River                           |  Deschutes
Q594295    |  MODvalue  |  name_de     |  Malheur River                             |  Malheur
Q594295    |  MODvalue  |  name_en     |  Malheur River                             |  Malheur
Q1147392   |  MODvalue  |  name_de     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_en     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_fr     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_nl     |  Fox River                                 |  Fox
Q3373254   |  MODvalue  |  name_en     |  Payette River                             |  Payette
Q3930308   |  MODvalue  |  name_de     |  Raquette River                            |  Raquette
Q3930308   |  MODvalue  |  name_en     |  Raquette River                            |  Raquette
Q3930308   |  MODvalue  |  name_fr     |  Raquette River                            |  rivière Raquette
Q3930308   |  MODvalue  |  name_nl     |  Raquette River                            |  Raquette
Q514154    |  MODvalue  |  name_de     |  Androscoggin River                        |  Androscoggin
Q514154    |  MODvalue  |  name_en     |  Androscoggin River                        |  Androscoggin
Q514154    |  MODvalue  |  name_fr     |  Androscoggin River                        |  Androscoggin
Q514154    |  MODvalue  |  name_nl     |  Androscoggin River                        |  Androscoggin
Q968475    |  MODvalue  |  name_de     |  Black River                               |  Black
Q968475    |  MODvalue  |  name_en     |  Black River                               |  Black
Q968475    |  MODvalue  |  name_nl     |  Black River                               |  Black
Q2210898   |  MODvalue  |  name_de     |  Saco River                                |  Saco
Q2210898   |  MODvalue  |  name_en     |  Saco River                                |  Saco
Q2210898   |  MODvalue  |  name_fr     |  Saco River                                |  Saco
Q2210898   |  MODvalue  |  name_nl     |  Saco River                                |  Saco
Q1147392   |  MODvalue  |  name_de     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_en     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_fr     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_nl     |  Fox River                                 |  Fox
Q4101376   |  MODvalue  |  name_en     |  Bad River                                 |  Bad
Q4101376   |  MODvalue  |  name_nl     |  Bad River                                 |  Bad
Q4101376   |  MODvalue  |  name_sv     |  Bad River                                 |  Bad
Q14687265  |  MODvalue  |  name_en     |  Pahsimeroi River                          |  Pahsimeroi
Q7055419   |  MODvalue  |  name_en     |  North Fork Payette River                  |  North Fork Payette
Q535450    |  MODvalue  |  name_de     |  Crooked River                             |  Crooked
Q535450    |  MODvalue  |  name_en     |  Crooked River                             |  Crooked
Q535450    |  MODvalue  |  name_nl     |  Crooked River                             |  Crooked
Q941928    |  MODvalue  |  name_de     |  Wolf River                                |  Wolf
Q941928    |  MODvalue  |  name_en     |  Wolf River                                |  Wolf
Q941928    |  MODvalue  |  name_nl     |  Wolf River                                |  Wolf
Q4148407   |  MODvalue  |  name_en     |  Greybull River                            |  Greybull
Q941928    |  MODvalue  |  name_de     |  Wolf River                                |  Wolf
Q941928    |  MODvalue  |  name_en     |  Wolf River                                |  Wolf
Q941928    |  MODvalue  |  name_nl     |  Wolf River                                |  Wolf
Q1164787   |  MODvalue  |  name_de     |  Winooski River                            |  Winooski
Q1164787   |  MODvalue  |  name_en     |  Winooski River                            |  Winooski
Q6749927   |  MODvalue  |  name_de     |  Manistee River                            |  Manistee
Q6749927   |  MODvalue  |  name_en     |  Manistee River                            |  Manistee
Q6749927   |  MODvalue  |  name_nl     |  Manistee River                            |  Manistee
Q2963877   |  MODvalue  |  name_de     |  Chippewa River                            |  Chippewa
Q2963877   |  MODvalue  |  name_en     |  Chippewa River                            |  Chippewa
Q2963877   |  MODvalue  |  name_pl     |  Chippewa River                            |  Chippewa
Q4818973   |  MODvalue  |  name_de     |  Au Sable River                            |  Au Sable
Q4818973   |  MODvalue  |  name_en     |  Au Sable River                            |  Au Sable
Q919146    |  MODvalue  |  name_de     |  Shoshone River                            |  Shoshone
Q919146    |  MODvalue  |  name_en     |  Shoshone River                            |  Shoshone
Q919146    |  MODvalue  |  name_pl     |  Shoshone River                            |  Shoshone
Q387103    |  MODvalue  |  name_de     |  Deschutes River                           |  Deschutes
Q387103    |  MODvalue  |  name_en     |  Deschutes River                           |  Deschutes
Q387103    |  MODvalue  |  name_fr     |  Deschutes River                           |  Deschutes
Q387103    |  MODvalue  |  name_nl     |  Deschutes River                           |  Deschutes
Q6482141   |  MODvalue  |  name_de     |  Lamoille River                            |  Lamoille
Q6482141   |  MODvalue  |  name_en     |  Lamoille River                            |  Lamoille
Q945954    |  MODvalue  |  name_de     |  Penobscot River                           |  Penobscot
Q945954    |  MODvalue  |  name_en     |  Penobscot River                           |  Penobscot
Q945954    |  MODvalue  |  name_nl     |  Penobscot River                           |  Penobscot
Q927116    |  MODvalue  |  name_de     |  Little Missouri River                     |  Little Missouri
Q927116    |  MODvalue  |  name_en     |  Little Missouri River                     |  Little Missouri
Q927116    |  MODvalue  |  name_nl     |  Little Missouri River                     |  Little Missouri
Q7304926   |  MODvalue  |  name_en     |  Red Rock River                            |  Red Rock
Q7304926   |  MODvalue  |  name_nl     |  Red Rock River                            |  Red Rock
Q952643    |  MODvalue  |  name_de     |  Santiam River                             |  Santiam
Q952643    |  MODvalue  |  name_en     |  Santiam River                             |  Santiam
Q7303872   |  MODvalue  |  name_en     |  Red Cedar River                           |  Red Cedar
Q2963877   |  MODvalue  |  name_de     |  Chippewa River                            |  Chippewa
Q2963877   |  MODvalue  |  name_en     |  Chippewa River                            |  Chippewa
Q2963877   |  MODvalue  |  name_pl     |  Chippewa River                            |  Chippewa
Q7294193   |  MODvalue  |  name_en     |  Rapid River                               |  Rapid
Q1787489   |  MODvalue  |  name_de     |  Tongue River                              |  Tongue
Q1787489   |  MODvalue  |  name_en     |  Tongue River                              |  Tongue
Q1787489   |  MODvalue  |  name_nl     |  Tongue River                              |  Tongue
Q1787489   |  MODvalue  |  name_pl     |  Tongue River                              |  Tongue
Q1787489   |  MODvalue  |  name_sv     |  Tongue River                              |  Tongue
Q7171400   |  MODvalue  |  name_de     |  Peshtigo River                            |  Peshtigo
Q7171400   |  MODvalue  |  name_en     |  Peshtigo River                            |  Peshtigo
Q4878247   |  MODvalue  |  name_en     |  Beaverhead River                          |  Beaverhead
Q1367713   |  MODvalue  |  name_de     |  Moreau River                              |  Moreau
Q1367713   |  MODvalue  |  name_en     |  Moreau River                              |  Moreau
Q1367713   |  MODvalue  |  name_fr     |  Moreau River                              |  Moreau
Q1367713   |  MODvalue  |  name_nl     |  Moreau River                              |  Moreau
Q858903    |  MODvalue  |  name_de     |  Big Hole River                            |  Big Hole
Q858903    |  MODvalue  |  name_en     |  Big Hole River                            |  Big Hole
Q858903    |  MODvalue  |  name_fr     |  Big Hole River                            |  Big Hole
Q858903    |  MODvalue  |  name_nl     |  Big Hole River                            |  Big Hole
Q7054245   |  MODvalue  |  name_en     |  North Branch Dead River                   |  North Branch Dead
Q5245370   |  MODvalue  |  name_en     |  Dead River                                |  Dead
Q3115025   |  MODvalue  |  name_en     |  Grande Ronde River                        |  Grande Ronde
Q2963877   |  MODvalue  |  name_de     |  Chippewa River                            |  Chippewa
Q2963877   |  MODvalue  |  name_en     |  Chippewa River                            |  Chippewa
Q2963877   |  MODvalue  |  name_pl     |  Chippewa River                            |  Chippewa
Q661667    |  MODvalue  |  name_en     |  Flambeau River                            |  Flambeau
Q14715290  |  MODvalue  |  name_en     |  Moose River                               |  Moose
Q945954    |  MODvalue  |  name_de     |  Penobscot River                           |  Penobscot
Q945954    |  MODvalue  |  name_en     |  Penobscot River                           |  Penobscot
Q945954    |  MODvalue  |  name_nl     |  Penobscot River                           |  Penobscot
Q6789623   |  MODvalue  |  name_en     |  Mattawamkeag River                        |  Mattawamkeag
Q7448888   |  MODvalue  |  name_en     |  Selway River                              |  Selway
Q284790    |  MODvalue  |  name_de     |  Jefferson River                           |  Jefferson
Q284790    |  MODvalue  |  name_en     |  Jefferson River                           |  Jefferson
Q284790    |  MODvalue  |  name_nl     |  Jefferson River                           |  Jefferson
Q284790    |  MODvalue  |  name_sv     |  Jefferson River                           |  Jefferson
Q7567278   |  MODvalue  |  name_en     |  South Fork of the Grand River             |  South Fork of the Grand
Q7984539   |  MODvalue  |  name_de     |  West Branch Penobscot River               |  West Branch Penobscot
Q7984539   |  MODvalue  |  name_en     |  West Branch Penobscot River               |  West Branch Penobscot
Q5327920   |  MODvalue  |  name_en     |  East Branch Penobscot River               |  East Branch Penobscot
Q1542869   |  MODvalue  |  name_de     |  Grand River                               |  Grand
Q1542869   |  MODvalue  |  name_en     |  Grand River                               |  Grand
Q1542869   |  MODvalue  |  name_fr     |  Grand River                               |  Grand
Q1542869   |  MODvalue  |  name_it     |  Grand River                               |  Grand
Q1542869   |  MODvalue  |  name_nl     |  Grand River                               |  Grand
Q7055396   |  MODvalue  |  name_en     |  North Fork of the Grand River             |  North Fork of the Grand
Q7566384   |  MODvalue  |  name_en     |  South Branch Penobscot River              |  South Branch Penobscot
Q7984539   |  MODvalue  |  name_de     |  West Branch Penobscot River               |  West Branch Penobscot
Q7984539   |  MODvalue  |  name_en     |  West Branch Penobscot River               |  West Branch Penobscot
Q1099574   |  MODvalue  |  name_de     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_en     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_nl     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_sv     |  Clearwater River                          |  Clearwater
Q7984539   |  MODvalue  |  name_de     |  West Branch Penobscot River               |  West Branch Penobscot
Q7984539   |  MODvalue  |  name_en     |  West Branch Penobscot River               |  West Branch Penobscot
Q334812    |  MODvalue  |  name_en     |  Bitterroot River                          |  Bitterroot
Q3311500   |  MODvalue  |  name_en     |  Michigamme River                          |  Michigamme
Q1138229   |  MODvalue  |  name_de     |  Cowlitz River                             |  Cowlitz
Q1138229   |  MODvalue  |  name_en     |  Cowlitz River                             |  Cowlitz
Q1138229   |  MODvalue  |  name_fr     |  Cowlitz River                             |  Cowlitz
Q1138229   |  MODvalue  |  name_nl     |  Cowlitz River                             |  Cowlitz
Q1033473   |  MODvalue  |  name_de     |  Cannonball River                          |  Cannonball
Q1033473   |  MODvalue  |  name_en     |  Cannonball River                          |  Cannonball
Q1033473   |  MODvalue  |  name_nl     |  Cannonball River                          |  Cannonball
Q1033473   |  MODvalue  |  name_sv     |  Cannonball River                          |  Cannonball
Q1033473   |  MODvalue  |  name_de     |  Cannonball River                          |  Cannonball
Q1033473   |  MODvalue  |  name_en     |  Cannonball River                          |  Cannonball
Q1033473   |  MODvalue  |  name_nl     |  Cannonball River                          |  Cannonball
Q1033473   |  MODvalue  |  name_sv     |  Cannonball River                          |  Cannonball
Q25238192  |  MODvalue  |  name_en     |  Middle Fork Clearwater River              |  Middle Fork Clearwater
Q6665167   |  MODvalue  |  name_en     |  Lochsa River                              |  Lochsa
Q1099574   |  MODvalue  |  name_de     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_en     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_nl     |  Clearwater River                          |  Clearwater
Q1099574   |  MODvalue  |  name_sv     |  Clearwater River                          |  Clearwater
Q4849121   |  MODvalue  |  name_en     |  Baker Branch Saint John River             |  Baker Branch Saint John
Q675651    |  MODvalue  |  name_de     |  Otter Tail River                          |  Otter Tail
Q675651    |  MODvalue  |  name_en     |  Otter Tail River                          |  Otter Tail
Q675651    |  MODvalue  |  name_nl     |  Otter Tail River                          |  Otter Tail
Q1861254   |  MODvalue  |  name_de     |  Yakima River                              |  Yakima
Q1861254   |  MODvalue  |  name_en     |  Yakima River                              |  Yakima
Q1861254   |  MODvalue  |  name_nl     |  Yakima River                              |  Yakima
Q1955484   |  MODvalue  |  name_de     |  Musselshell River                         |  Musselshell
Q1955484   |  MODvalue  |  name_en     |  Musselshell River                         |  Musselshell
Q1955484   |  MODvalue  |  name_nl     |  Musselshell River                         |  Musselshell
Q1800895   |  MODvalue  |  name_de     |  Allagash River                            |  Allagash
Q1800895   |  MODvalue  |  name_en     |  Allagash River                            |  Allagash
Q1800895   |  MODvalue  |  name_fr     |  Allagash River                            |  Allagash
Q1800895   |  MODvalue  |  name_nl     |  Allagash River                            |  Allagash
Q247160    |  MODvalue  |  name_de     |  Aroostook River                           |  Aroostook
Q247160    |  MODvalue  |  name_en     |  Aroostook River                           |  Aroostook
Q247160    |  MODvalue  |  name_nl     |  Aroostook River                           |  Aroostook
Q2278535   |  MODvalue  |  name_de     |  Sheyenne River                            |  Sheyenne
Q2278535   |  MODvalue  |  name_en     |  Sheyenne River                            |  Sheyenne
Q2278535   |  MODvalue  |  name_fr     |  Sheyenne River                            |  Sheyenne
Q2278535   |  MODvalue  |  name_nl     |  Sheyenne River                            |  Sheyenne
Q259157    |  MODvalue  |  name_de     |  Chehalis River                            |  Chehalis
Q259157    |  MODvalue  |  name_en     |  Chehalis River                            |  Chehalis
Q259157    |  MODvalue  |  name_nl     |  Chehalis River                            |  Chehalis
Q675651    |  MODvalue  |  name_de     |  Otter Tail River                          |  Otter Tail
Q675651    |  MODvalue  |  name_en     |  Otter Tail River                          |  Otter Tail
Q675651    |  MODvalue  |  name_nl     |  Otter Tail River                          |  Otter Tail
Q1800895   |  MODvalue  |  name_de     |  Allagash River                            |  Allagash
Q1800895   |  MODvalue  |  name_en     |  Allagash River                            |  Allagash
Q1800895   |  MODvalue  |  name_fr     |  Allagash River                            |  Allagash
Q1800895   |  MODvalue  |  name_nl     |  Allagash River                            |  Allagash
Q1592419   |  MODvalue  |  name_de     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_en     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_fr     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_nl     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_sv     |  Heart River                               |  Heart
Q2467701   |  MODvalue  |  name_en     |  Palouse River                             |  Palouse
Q2467701   |  MODvalue  |  name_nl     |  Palouse River                             |  Palouse
Q1592419   |  MODvalue  |  name_de     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_en     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_fr     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_nl     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_sv     |  Heart River                               |  Heart
Q6114866   |  MODvalue  |  name_en     |  Blackfoot River                           |  Blackfoot
Q2467701   |  MODvalue  |  name_en     |  Palouse River                             |  Palouse
Q2467701   |  MODvalue  |  name_nl     |  Palouse River                             |  Palouse
Q2467701   |  MODvalue  |  name_en     |  Palouse River                             |  Palouse
Q2467701   |  MODvalue  |  name_nl     |  Palouse River                             |  Palouse
Q3567786   |  MODvalue  |  name_en     |  White River                               |  White
Q3567786   |  MODvalue  |  name_fr     |  White River                               |  White
Q2196805   |  MODvalue  |  name_en     |  Saint Joe River                           |  Saint Joe
Q2196805   |  MODvalue  |  name_nl     |  Saint Joe River                           |  Saint Joe
Q8563405   |  MODvalue  |  name_en     |  Fish River                                |  Fish
Q3411110   |  MODvalue  |  name_en     |  Puyallup River                            |  Puyallup
Q3411110   |  MODvalue  |  name_nl     |  Puyallup River                            |  Puyallup
Q1390482   |  MODvalue  |  name_de     |  Quinault River                            |  Quinault
Q1390482   |  MODvalue  |  name_en     |  Quinault River                            |  Quinault
Q1390482   |  MODvalue  |  name_nl     |  Quinault River                            |  Quinault
Q334544    |  MODvalue  |  name_en     |  South Fork Flathead River                 |  South Fork Flathead
Q3503758   |  MODvalue  |  name_de     |  Sun River                                 |  Sun
Q3503758   |  MODvalue  |  name_en     |  Sun River                                 |  Sun
Q3503758   |  MODvalue  |  name_fr     |  Sun River                                 |  Sun
Q3503758   |  MODvalue  |  name_nl     |  Sun River                                 |  Sun
Q2295983   |  MODvalue  |  name_de     |  Snoqualmie River                          |  Snoqualmie
Q2295983   |  MODvalue  |  name_en     |  Snoqualmie River                          |  Snoqualmie
Q1275618   |  MODvalue  |  name_de     |  Spokane River                             |  Spokane
Q1275618   |  MODvalue  |  name_en     |  Spokane River                             |  Spokane
Q1275618   |  MODvalue  |  name_nl     |  Spokane River                             |  Spokane
Q2328855   |  MODvalue  |  name_en     |  Nazas River                               |  Nazas
Q2328855   |  MODvalue  |  name_en     |  Nazas River                               |  Nazas
Q3458794   |  MODvalue  |  name_en     |  Sinaloa River                             |  Sinaloa
Q5267445   |  MODvalue  |  name_en     |  Devils River                              |  Devils
Q1969490   |  MODvalue  |  name_de     |  Trinity River                             |  Trinity
Q1969490   |  MODvalue  |  name_en     |  Trinity River                             |  Trinity
Q1969490   |  MODvalue  |  name_nl     |  Trinity River                             |  Trinity
Q1969490   |  MODvalue  |  name_pl     |  Trinity River                             |  Trinity
Q8665483   |  MODvalue  |  name_en     |  Black River                               |  Black
Q8665483   |  MODvalue  |  name_fr     |  Black River                               |  Black
Q2343949   |  MODvalue  |  name_en     |  Santa Cruz River                          |  Santa Cruz
Q2451378   |  MODvalue  |  name_en     |  San Pedro River                           |  San Pedro
Q2451378   |  MODvalue  |  name_hu     |  San Pedro River                           |  San Pedro
Q2451378   |  MODvalue  |  name_nl     |  San Pedro River                           |  San Pedro
Q4762748   |  MODvalue  |  name_en     |  Angelina River                            |  Angelina
Q2041614   |  MODvalue  |  name_de     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_en     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_nl     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_pl     |  Ouachita River                            |  Ouachita
Q3486452   |  MODvalue  |  name_de     |  Skykomish River                           |  Skykomish
Q3486452   |  MODvalue  |  name_en     |  Skykomish River                           |  Skykomish
Q2619028   |  MODvalue  |  name_de     |  Snohomish River                           |  Snohomish
Q2619028   |  MODvalue  |  name_en     |  Snohomish River                           |  Snohomish
Q2619028   |  MODvalue  |  name_nl     |  Snohomish River                           |  Snohomish
Q595366    |  MODvalue  |  name_de     |  Marias River                              |  Marias
Q595366    |  MODvalue  |  name_en     |  Marias River                              |  Marias
Q595366    |  MODvalue  |  name_nl     |  Marias River                              |  Marias
Q595366    |  MODvalue  |  name_sv     |  Marias River                              |  Marias
Q334781    |  MODvalue  |  name_en     |  Middle Fork Flathead River                |  Middle Fork Flathead
Q217739    |  MODvalue  |  name_de     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_en     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_nl     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_pl     |  Milk River                                |  Milk
Q487925    |  MODvalue  |  name_de     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_en     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_nl     |  Souris River                              |  Souris
Q487925    |  MODvalue  |  name_sv     |  Souris River                              |  Souris
Q7229424   |  MODvalue  |  name_en     |  Poplar River                              |  Poplar
Q7229424   |  MODvalue  |  name_fr     |  Poplar River                              |  Poplar
Q271058    |  MODvalue  |  name_de     |  Okanogan River                            |  Okanogan
Q271058    |  MODvalue  |  name_en     |  Okanogan River                            |  Okanogan
Q271058    |  MODvalue  |  name_nl     |  Okanogan River                            |  Okanogan
Q7242886   |  MODvalue  |  name_en     |  Priest River                              |  Priest
Q334544    |  MODvalue  |  name_en     |  South Fork Flathead River                 |  South Fork Flathead
Q217739    |  MODvalue  |  name_de     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_en     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_nl     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_pl     |  Milk River                                |  Milk
Q595366    |  MODvalue  |  name_de     |  Marias River                              |  Marias
Q595366    |  MODvalue  |  name_en     |  Marias River                              |  Marias
Q595366    |  MODvalue  |  name_nl     |  Marias River                              |  Marias
Q595366    |  MODvalue  |  name_sv     |  Marias River                              |  Marias
Q305408    |  MODvalue  |  name_de     |  Skagit River                              |  Skagit
Q305408    |  MODvalue  |  name_en     |  Skagit River                              |  Skagit
Q305408    |  MODvalue  |  name_nl     |  Skagit River                              |  Skagit
Q7859083   |  MODvalue  |  name_en     |  Two Medicine River                        |  Two Medicine
Q217739    |  MODvalue  |  name_de     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_en     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_nl     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_pl     |  Milk River                                |  Milk
Q177469    |  MODvalue  |  name_de     |  Frenchman River                           |  Frenchman
Q177469    |  MODvalue  |  name_en     |  Frenchman River                           |  Frenchman
Q177469    |  MODvalue  |  name_nl     |  Frenchman River                           |  Frenchman
Q177469    |  MODvalue  |  name_sv     |  Frenchman River                           |  Frenchman
Q217739    |  MODvalue  |  name_de     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_en     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_nl     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_pl     |  Milk River                                |  Milk
Q270484    |  MODvalue  |  name_de     |  Kettle River                              |  Kettle
Q270484    |  MODvalue  |  name_en     |  Kettle River                              |  Kettle
Q270484    |  MODvalue  |  name_nl     |  Kettle River                              |  Kettle
Q217739    |  MODvalue  |  name_de     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_en     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_nl     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_pl     |  Milk River                                |  Milk
Q7229424   |  MODvalue  |  name_en     |  Poplar River                              |  Poplar
Q7229424   |  MODvalue  |  name_fr     |  Poplar River                              |  Poplar
Q217739    |  MODvalue  |  name_de     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_en     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_nl     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_pl     |  Milk River                                |  Milk
Q270484    |  MODvalue  |  name_de     |  Kettle River                              |  Kettle
Q270484    |  MODvalue  |  name_en     |  Kettle River                              |  Kettle
Q270484    |  MODvalue  |  name_nl     |  Kettle River                              |  Kettle
Q2068478   |  MODvalue  |  name_de     |  Pembina River                             |  Pembina
Q2068478   |  MODvalue  |  name_en     |  Pembina River                             |  Pembina
Q3442448   |  MODvalue  |  name_de     |  Roseau River                              |  Roseau
Q3442448   |  MODvalue  |  name_en     |  Roseau River                              |  Roseau
Q3442448   |  MODvalue  |  name_nl     |  Roseau River                              |  Roseau
Q7590512   |  MODvalue  |  name_en     |  St. Mary River                            |  St. Mary
Q304833    |  MODvalue  |  name_de     |  Similkameen River                         |  Similkameen
Q304833    |  MODvalue  |  name_en     |  Similkameen River                         |  Similkameen
Q304833    |  MODvalue  |  name_sv     |  Similkameen River                         |  Similkameen
Q271058    |  MODvalue  |  name_de     |  Okanogan River                            |  Okanogan
Q271058    |  MODvalue  |  name_en     |  Okanogan River                            |  Okanogan
Q271058    |  MODvalue  |  name_nl     |  Okanogan River                            |  Okanogan
Q644607    |  MODvalue  |  name_de     |  Unuk River                                |  Unuk
Q644607    |  MODvalue  |  name_en     |  Unuk River                                |  Unuk
Q644607    |  MODvalue  |  name_nl     |  Unuk River                                |  Unuk
Q4453762   |  MODvalue  |  name_en     |  Taylor River                              |  Taylor
Q177627    |  MODvalue  |  name_de     |  Smoky Hill River                          |  Smoky Hill
Q177627    |  MODvalue  |  name_en     |  Smoky Hill River                          |  Smoky Hill
Q2126786   |  MODvalue  |  name_de     |  White River                               |  White
Q2126786   |  MODvalue  |  name_en     |  White River                               |  White
Q2126786   |  MODvalue  |  name_fr     |  White River                               |  White
Q2126786   |  MODvalue  |  name_nl     |  White River                               |  White
Q2126786   |  MODvalue  |  name_pl     |  White River                               |  White
Q466699    |  MODvalue  |  name_de     |  American River                            |  American
Q466699    |  MODvalue  |  name_en     |  American River                            |  American
Q466699    |  MODvalue  |  name_fr     |  American River                            |  American
Q466699    |  MODvalue  |  name_nl     |  American River                            |  American
Q1334957   |  MODvalue  |  name_de     |  Embarras River                            |  Embarras
Q1334957   |  MODvalue  |  name_en     |  Embarras River                            |  Embarras
Q7055372   |  MODvalue  |  name_en     |  North Fork American River                 |  North Fork American
Q3263961   |  MODvalue  |  name_en     |  Loup River                                |  Loup
Q1672169   |  MODvalue  |  name_de     |  Iowa River                                |  Iowa
Q1672169   |  MODvalue  |  name_en     |  Iowa River                                |  Iowa
Q1672169   |  MODvalue  |  name_nl     |  Iowa River                                |  Iowa
Q4369036   |  MODvalue  |  name_en     |  Pawcatuck River                           |  Pawcatuck
Q1440192   |  MODvalue  |  name_de     |  Fox River                                 |  Fox
Q1440192   |  MODvalue  |  name_en     |  Fox River                                 |  Fox
Q8637      |  MODvalue  |  name_de     |  Des Plaines River                         |  Des Plaines
Q8637      |  MODvalue  |  name_en     |  Des Plaines River                         |  Des Plaines
Q8637      |  MODvalue  |  name_nl     |  Des Plaines River                         |  Des Plaines
Q2126786   |  MODvalue  |  name_de     |  White River                               |  White
Q2126786   |  MODvalue  |  name_en     |  White River                               |  White
Q2126786   |  MODvalue  |  name_fr     |  White River                               |  White
Q2126786   |  MODvalue  |  name_nl     |  White River                               |  White
Q2126786   |  MODvalue  |  name_pl     |  White River                               |  White
Q1681774   |  MODvalue  |  name_de     |  Turkey River                              |  Turkey
Q1681774   |  MODvalue  |  name_en     |  Turkey River                              |  Turkey
Q1164631   |  MODvalue  |  name_de     |  Hoh River                                 |  Hoh
Q1164631   |  MODvalue  |  name_en     |  Hoh River                                 |  Hoh
Q1164631   |  MODvalue  |  name_fr     |  Hoh River                                 |  Hoh
Q1164631   |  MODvalue  |  name_nl     |  Hoh River                                 |  Hoh
Q7304452   |  MODvalue  |  name_de     |  Red Lake River                            |  Red Lake
Q7304452   |  MODvalue  |  name_en     |  Red Lake River                            |  Red Lake
Q546105    |  MODvalue  |  name_de     |  Aniakchak River                           |  Aniakchak
Q546105    |  MODvalue  |  name_en     |  Aniakchak River                           |  Aniakchak
Q788438    |  MODvalue  |  name_en     |  Ugashik River                             |  Ugashik
Q788438    |  MODvalue  |  name_nl     |  Ugashik River                             |  Ugashik
Q3049132   |  MODvalue  |  name_de     |  Egegik River                              |  Egegik
Q3049132   |  MODvalue  |  name_en     |  Egegik River                              |  Egegik
Q3197034   |  MODvalue  |  name_en     |  King Salmon River                         |  King Salmon
Q2389724   |  MODvalue  |  name_de     |  Taku River                                |  Taku
Q2389724   |  MODvalue  |  name_en     |  Taku River                                |  Taku
Q2389724   |  MODvalue  |  name_nl     |  Taku River                                |  Taku
Q2389724   |  MODvalue  |  name_sv     |  Taku River                                |  Taku
Q3062302   |  MODvalue  |  name_de     |  Naknek River                              |  Naknek
Q3062302   |  MODvalue  |  name_en     |  Naknek River                              |  Naknek
Q2005508   |  MODvalue  |  name_de     |  Nushagak River                            |  Nushagak
Q2005508   |  MODvalue  |  name_en     |  Nushagak River                            |  Nushagak
Q2005508   |  MODvalue  |  name_nl     |  Nushagak River                            |  Nushagak
Q641592    |  MODvalue  |  name_de     |  Alagnak River                             |  Alagnak
Q641592    |  MODvalue  |  name_en     |  Alagnak River                             |  Alagnak
Q641592    |  MODvalue  |  name_nl     |  Alagnak River                             |  Alagnak
Q1642304   |  MODvalue  |  name_de     |  Nonvianuk River                           |  Nonvianuk
Q641592    |  MODvalue  |  name_de     |  Alagnak River                             |  Alagnak
Q641592    |  MODvalue  |  name_en     |  Alagnak River                             |  Alagnak
Q641592    |  MODvalue  |  name_nl     |  Alagnak River                             |  Alagnak
Q1131889   |  MODvalue  |  name_de     |  Togiak River                              |  Togiak
Q1131889   |  MODvalue  |  name_en     |  Togiak River                              |  Togiak
Q271001    |  MODvalue  |  name_de     |  Chilkat River                             |  Chilkat
Q271001    |  MODvalue  |  name_en     |  Chilkat River                             |  Chilkat
Q271001    |  MODvalue  |  name_nl     |  Chilkat River                             |  Chilkat
Q271001    |  MODvalue  |  name_sv     |  Chilkat River                             |  Chilkat
Q3198421   |  MODvalue  |  name_en     |  Kokwok River                              |  Kokwok
Q2005508   |  MODvalue  |  name_de     |  Nushagak River                            |  Nushagak
Q2005508   |  MODvalue  |  name_en     |  Nushagak River                            |  Nushagak
Q2005508   |  MODvalue  |  name_nl     |  Nushagak River                            |  Nushagak
Q2005508   |  MODvalue  |  name_de     |  Nushagak River                            |  Nushagak
Q2005508   |  MODvalue  |  name_en     |  Nushagak River                            |  Nushagak
Q2005508   |  MODvalue  |  name_nl     |  Nushagak River                            |  Nushagak
Q1293534   |  MODvalue  |  name_de     |  Mulchatna River                           |  Mulchatna
Q1293534   |  MODvalue  |  name_en     |  Mulchatna River                           |  Mulchatna
Q1293534   |  MODvalue  |  name_nl     |  Mulchatna River                           |  Mulchatna
Q3192622   |  MODvalue  |  name_de     |  Kanektok River                            |  Kanektok
Q3192622   |  MODvalue  |  name_en     |  Kanektok River                            |  Kanektok
Q3339115   |  MODvalue  |  name_en     |  Newhalen River                            |  Newhalen
Q3339115   |  MODvalue  |  name_nl     |  Newhalen River                            |  Newhalen
Q2005786   |  MODvalue  |  name_de     |  Nuyakuk River                             |  Nuyakuk
Q2005786   |  MODvalue  |  name_en     |  Nuyakuk River                             |  Nuyakuk
Q2005786   |  MODvalue  |  name_nl     |  Nuyakuk River                             |  Nuyakuk
Q2005508   |  MODvalue  |  name_de     |  Nushagak River                            |  Nushagak
Q2005508   |  MODvalue  |  name_en     |  Nushagak River                            |  Nushagak
Q2005508   |  MODvalue  |  name_nl     |  Nushagak River                            |  Nushagak
Q1794942   |  MODvalue  |  name_de     |  Kwethluk River                            |  Kwethluk
Q1072928   |  MODvalue  |  name_de     |  Chilikadrotna River                       |  Chilikadrotna
Q1072928   |  MODvalue  |  name_en     |  Chilikadrotna River                       |  Chilikadrotna
Q1072928   |  MODvalue  |  name_nl     |  Chilikadrotna River                       |  Chilikadrotna
Q1293534   |  MODvalue  |  name_de     |  Mulchatna River                           |  Mulchatna
Q1293534   |  MODvalue  |  name_en     |  Mulchatna River                           |  Mulchatna
Q1293534   |  MODvalue  |  name_nl     |  Mulchatna River                           |  Mulchatna
Q1624702   |  MODvalue  |  name_de     |  Holitna River                             |  Holitna
Q1624702   |  MODvalue  |  name_en     |  Holitna River                             |  Holitna
Q1624702   |  MODvalue  |  name_nl     |  Holitna River                             |  Holitna
Q1074901   |  MODvalue  |  name_de     |  Chitina River                             |  Chitina
Q1074901   |  MODvalue  |  name_en     |  Chitina River                             |  Chitina
Q1074901   |  MODvalue  |  name_nl     |  Chitina River                             |  Chitina
Q2947733   |  MODvalue  |  name_de     |  Chakachatna River                         |  Chakachatna
Q2947733   |  MODvalue  |  name_en     |  Chakachatna River                         |  Chakachatna
Q2947733   |  MODvalue  |  name_nl     |  Chakachatna River                         |  Chakachatna
Q45910906  |  MODvalue  |  name_de     |  Hoholitna River                           |  Hoholitna
Q45910906  |  MODvalue  |  name_en     |  Hoholitna River                           |  Hoholitna
Q1370855   |  MODvalue  |  name_de     |  Stony River                               |  Stony
Q1370855   |  MODvalue  |  name_en     |  Stony River                               |  Stony
Q546088    |  MODvalue  |  name_de     |  Aniak River                               |  Aniak
Q546088    |  MODvalue  |  name_en     |  Aniak River                               |  Aniak
Q546088    |  MODvalue  |  name_nl     |  Aniak River                               |  Aniak
Q1074901   |  MODvalue  |  name_de     |  Chitina River                             |  Chitina
Q1074901   |  MODvalue  |  name_en     |  Chitina River                             |  Chitina
Q1074901   |  MODvalue  |  name_nl     |  Chitina River                             |  Chitina
Q47336656  |  MODvalue  |  name_de     |  Beluga River                              |  Beluga
Q47336656  |  MODvalue  |  name_en     |  Beluga River                              |  Beluga
Q3486413   |  MODvalue  |  name_de     |  Skwentna River                            |  Skwentna
Q3486413   |  MODvalue  |  name_en     |  Skwentna River                            |  Skwentna
Q667197    |  MODvalue  |  name_de     |  Swift River                               |  Swift
Q667197    |  MODvalue  |  name_en     |  Swift River                               |  Swift
Q667197    |  MODvalue  |  name_nl     |  Swift River                               |  Swift
Q1468104   |  MODvalue  |  name_de     |  Matanuska River                           |  Matanuska
Q1468104   |  MODvalue  |  name_en     |  Matanuska River                           |  Matanuska
Q1468104   |  MODvalue  |  name_nl     |  Matanuska River                           |  Matanuska
Q1624702   |  MODvalue  |  name_de     |  Holitna River                             |  Holitna
Q1624702   |  MODvalue  |  name_en     |  Holitna River                             |  Holitna
Q1624702   |  MODvalue  |  name_nl     |  Holitna River                             |  Holitna
Q2600106   |  MODvalue  |  name_de     |  Yentna River                              |  Yentna
Q2600106   |  MODvalue  |  name_en     |  Yentna River                              |  Yentna
Q2600106   |  MODvalue  |  name_nl     |  Yentna River                              |  Yentna
Q1529669   |  MODvalue  |  name_de     |  White River                               |  White
Q1529669   |  MODvalue  |  name_en     |  White River                               |  White
Q1529669   |  MODvalue  |  name_fr     |  White River                               |  White
Q1529669   |  MODvalue  |  name_it     |  White River                               |  White
Q1529669   |  MODvalue  |  name_nl     |  White River                               |  White
Q1529669   |  MODvalue  |  name_pl     |  White River                               |  White
Q1321272   |  MODvalue  |  name_de     |  Klutina River                             |  Klutina
Q1321272   |  MODvalue  |  name_en     |  Klutina River                             |  Klutina
Q1321272   |  MODvalue  |  name_nl     |  Klutina River                             |  Klutina
Q859175    |  MODvalue  |  name_de     |  Big River                                 |  Big
Q859175    |  MODvalue  |  name_en     |  Big River                                 |  Big
Q2397984   |  MODvalue  |  name_de     |  Tazlina River                             |  Tazlina
Q2397984   |  MODvalue  |  name_en     |  Tazlina River                             |  Tazlina
Q305100    |  MODvalue  |  name_de     |  Andreafsky River                          |  Andreafsky
Q305100    |  MODvalue  |  name_en     |  Andreafsky River                          |  Andreafsky
Q305100    |  MODvalue  |  name_nl     |  Andreafsky River                          |  Andreafsky
Q305100    |  MODvalue  |  name_de     |  Andreafsky River                          |  Andreafsky
Q305100    |  MODvalue  |  name_en     |  Andreafsky River                          |  Andreafsky
Q305100    |  MODvalue  |  name_nl     |  Andreafsky River                          |  Andreafsky
Q1656844   |  MODvalue  |  name_de     |  Iditarod River                            |  Iditarod
Q1656844   |  MODvalue  |  name_en     |  Iditarod River                            |  Iditarod
Q1656844   |  MODvalue  |  name_nl     |  Iditarod River                            |  Iditarod
Q753980    |  MODvalue  |  name_de     |  Atchuelinguk River                        |  Atchuelinguk
Q753980    |  MODvalue  |  name_en     |  Atchuelinguk River                        |  Atchuelinguk
Q753980    |  MODvalue  |  name_nl     |  Atchuelinguk River                        |  Atchuelinguk
Q1664161   |  MODvalue  |  name_de     |  Innoko River                              |  Innoko
Q1664161   |  MODvalue  |  name_en     |  Innoko River                              |  Innoko
Q1664161   |  MODvalue  |  name_nl     |  Innoko River                              |  Innoko
Q1961991   |  MODvalue  |  name_de     |  Nabesna River                             |  Nabesna
Q1961991   |  MODvalue  |  name_en     |  Nabesna River                             |  Nabesna
Q1961991   |  MODvalue  |  name_nl     |  Nabesna River                             |  Nabesna
Q948529    |  MODvalue  |  name_de     |  Gulkana River                             |  Gulkana
Q948529    |  MODvalue  |  name_en     |  Gulkana River                             |  Gulkana
Q948529    |  MODvalue  |  name_nl     |  Gulkana River                             |  Gulkana
Q1491600   |  MODvalue  |  name_de     |  Gakona River                              |  Gakona
Q1491600   |  MODvalue  |  name_en     |  Gakona River                              |  Gakona
Q1491600   |  MODvalue  |  name_nl     |  Gakona River                              |  Gakona
Q1321280   |  MODvalue  |  name_de     |  Talkeetna River                           |  Talkeetna
Q1321280   |  MODvalue  |  name_en     |  Talkeetna River                           |  Talkeetna
Q1089418   |  MODvalue  |  name_de     |  Chulitna River                            |  Chulitna
Q1089418   |  MODvalue  |  name_en     |  Chulitna River                            |  Chulitna
Q1074843   |  MODvalue  |  name_de     |  Chistochina River                         |  Chistochina
Q1074843   |  MODvalue  |  name_en     |  Chistochina River                         |  Chistochina
Q948529    |  MODvalue  |  name_de     |  Gulkana River                             |  Gulkana
Q948529    |  MODvalue  |  name_en     |  Gulkana River                             |  Gulkana
Q948529    |  MODvalue  |  name_nl     |  Gulkana River                             |  Gulkana
Q612981    |  MODvalue  |  name_de     |  Anvik River                               |  Anvik
Q612981    |  MODvalue  |  name_en     |  Anvik River                               |  Anvik
Q612981    |  MODvalue  |  name_nl     |  Anvik River                               |  Anvik
Q15278162  |  MODvalue  |  name_de     |  Slana River                               |  Slana
Q15278162  |  MODvalue  |  name_en     |  Slana River                               |  Slana
Q60065     |  MODvalue  |  name_de     |  Susitna River                             |  Susitna
Q60065     |  MODvalue  |  name_en     |  Susitna River                             |  Susitna
Q3030256   |  MODvalue  |  name_de     |  Dishna River                              |  Dishna
Q3030256   |  MODvalue  |  name_en     |  Dishna River                              |  Dishna
Q1664161   |  MODvalue  |  name_de     |  Innoko River                              |  Innoko
Q1664161   |  MODvalue  |  name_en     |  Innoko River                              |  Innoko
Q1664161   |  MODvalue  |  name_nl     |  Innoko River                              |  Innoko
Q1184924   |  MODvalue  |  name_de     |  Delta River                               |  Delta
Q1184924   |  MODvalue  |  name_en     |  Delta River                               |  Delta
Q1664161   |  MODvalue  |  name_de     |  Innoko River                              |  Innoko
Q1664161   |  MODvalue  |  name_en     |  Innoko River                              |  Innoko
Q1664161   |  MODvalue  |  name_nl     |  Innoko River                              |  Innoko
Q1762110   |  MODvalue  |  name_de     |  Tetlin River                              |  Tetlin
Q1977371   |  MODvalue  |  name_de     |  Nenana River                              |  Nenana
Q1977371   |  MODvalue  |  name_en     |  Nenana River                              |  Nenana
Q1977371   |  MODvalue  |  name_nl     |  Nenana River                              |  Nenana
Q14680121  |  MODvalue  |  name_de     |  McKinley River                            |  McKinley
Q14680121  |  MODvalue  |  name_en     |  McKinley River                            |  McKinley
Q14680121  |  MODvalue  |  name_fr     |  McKinley River                            |  McKinley
Q14680013  |  NEWvalue  |  name_de     |                                            |  Herron
Q14680013  |  MODvalue  |  name_en     |  Herron River                              |  Herron
Q1430047   |  MODvalue  |  name_de     |  Nowitna River                             |  Nowitna
Q1430047   |  MODvalue  |  name_en     |  Nowitna River                             |  Nowitna
Q1430047   |  MODvalue  |  name_nl     |  Nowitna River                             |  Nowitna
Q14679986  |  NEWvalue  |  name_de     |                                            |  Foraker
Q14679986  |  MODvalue  |  name_en     |  Foraker River                             |  Foraker
Q1244433   |  MODvalue  |  name_de     |  Kantishna River                           |  Kantishna
Q1244433   |  MODvalue  |  name_en     |  Kantishna River                           |  Kantishna
Q1244433   |  MODvalue  |  name_nl     |  Kantishna River                           |  Kantishna
Q763999    |  MODvalue  |  name_de     |  Unalakleet River                          |  Unalakleet
Q763999    |  MODvalue  |  name_en     |  Unalakleet River                          |  Unalakleet
Q1670844   |  MODvalue  |  name_de     |  Teklanika River                           |  Teklanika
Q1670844   |  MODvalue  |  name_en     |  Teklanika River                           |  Teklanika
Q3110723   |  MODvalue  |  name_en     |  Goodpaster River                          |  Goodpaster
Q1439158   |  MODvalue  |  name_de     |  Fortymile River                           |  Fortymile
Q1439158   |  MODvalue  |  name_en     |  Fortymile River                           |  Fortymile
Q1439158   |  MODvalue  |  name_nl     |  Fortymile River                           |  Fortymile
Q1439158   |  MODvalue  |  name_pl     |  Fortymile River                           |  Fortymile
Q1439158   |  MODvalue  |  name_sv     |  Fortymile River                           |  Fortymile
Q3469654   |  MODvalue  |  name_de     |  Salcha River                              |  Salcha
Q3469654   |  MODvalue  |  name_en     |  Salcha River                              |  Salcha
Q1977371   |  MODvalue  |  name_de     |  Nenana River                              |  Nenana
Q1977371   |  MODvalue  |  name_en     |  Nenana River                              |  Nenana
Q1977371   |  MODvalue  |  name_nl     |  Nenana River                              |  Nenana
Q1066756   |  MODvalue  |  name_de     |  Charley River                             |  Charley
Q1066756   |  MODvalue  |  name_en     |  Charley River                             |  Charley
Q1066756   |  MODvalue  |  name_nl     |  Charley River                             |  Charley
Q1069837   |  MODvalue  |  name_de     |  Chena River                               |  Chena
Q1069837   |  MODvalue  |  name_en     |  Chena River                               |  Chena
Q1069837   |  MODvalue  |  name_nl     |  Chena River                               |  Chena
Q3530614   |  MODvalue  |  name_de     |  Tolovana River                            |  Tolovana
Q3199429   |  MODvalue  |  name_en     |  Koyuk River                               |  Koyuk
Q3199429   |  MODvalue  |  name_nl     |  Koyuk River                               |  Koyuk
Q2961511   |  MODvalue  |  name_de     |  Chatanika River                           |  Chatanika
Q2961511   |  MODvalue  |  name_en     |  Chatanika River                           |  Chatanika
Q2961511   |  MODvalue  |  name_nl     |  Chatanika River                           |  Chatanika
Q1794782   |  MODvalue  |  name_de     |  Kuzitrin River                            |  Kuzitrin
Q1794782   |  MODvalue  |  name_en     |  Kuzitrin River                            |  Kuzitrin
Q1794782   |  MODvalue  |  name_nl     |  Kuzitrin River                            |  Kuzitrin
Q1794782   |  MODvalue  |  name_de     |  Kuzitrin River                            |  Kuzitrin
Q1794782   |  MODvalue  |  name_en     |  Kuzitrin River                            |  Kuzitrin
Q1794782   |  MODvalue  |  name_nl     |  Kuzitrin River                            |  Kuzitrin
Q1966848   |  MODvalue  |  name_de     |  Nation River                              |  Nation
Q1966848   |  MODvalue  |  name_en     |  Nation River                              |  Nation
Q1623353   |  MODvalue  |  name_de     |  Hogatza River                             |  Hogatza
Q1623353   |  MODvalue  |  name_en     |  Hogatza River                             |  Hogatza
Q1623353   |  MODvalue  |  name_nl     |  Hogatza River                             |  Hogatza
Q968475    |  MODvalue  |  name_de     |  Black River                               |  Black
Q968475    |  MODvalue  |  name_en     |  Black River                               |  Black
Q968475    |  MODvalue  |  name_nl     |  Black River                               |  Black
Q1622755   |  MODvalue  |  name_de     |  Hodzana River                             |  Hodzana
Q1622755   |  MODvalue  |  name_en     |  Hodzana River                             |  Hodzana
Q1622755   |  MODvalue  |  name_nl     |  Hodzana River                             |  Hodzana
Q686347    |  MODvalue  |  name_de     |  Selawik River                             |  Selawik
Q686347    |  MODvalue  |  name_en     |  Selawik River                             |  Selawik
Q686347    |  MODvalue  |  name_nl     |  Selawik River                             |  Selawik
Q968475    |  MODvalue  |  name_de     |  Black River                               |  Black
Q968475    |  MODvalue  |  name_en     |  Black River                               |  Black
Q968475    |  MODvalue  |  name_nl     |  Black River                               |  Black
Q826196    |  MODvalue  |  name_de     |  Alatna River                              |  Alatna
Q826196    |  MODvalue  |  name_en     |  Alatna River                              |  Alatna
Q826196    |  MODvalue  |  name_nl     |  Alatna River                              |  Alatna
Q955645    |  MODvalue  |  name_de     |  Chandalar River                           |  Chandalar
Q955645    |  MODvalue  |  name_en     |  Chandalar River                           |  Chandalar
Q955645    |  MODvalue  |  name_nl     |  Chandalar River                           |  Chandalar
Q686347    |  MODvalue  |  name_de     |  Selawik River                             |  Selawik
Q686347    |  MODvalue  |  name_en     |  Selawik River                             |  Selawik
Q686347    |  MODvalue  |  name_nl     |  Selawik River                             |  Selawik
Q2277693   |  MODvalue  |  name_de     |  Sheenjek River                            |  Sheenjek
Q2277693   |  MODvalue  |  name_en     |  Sheenjek River                            |  Sheenjek
Q2277693   |  MODvalue  |  name_nl     |  Sheenjek River                            |  Sheenjek
Q932937    |  MODvalue  |  name_de     |  John River                                |  John
Q932937    |  MODvalue  |  name_en     |  John River                                |  John
Q932937    |  MODvalue  |  name_nl     |  John River                                |  John
Q2315080   |  MODvalue  |  name_de     |  Squirrel River                            |  Squirrel
Q2315080   |  MODvalue  |  name_en     |  Squirrel River                            |  Squirrel
Q16895078  |  MODvalue  |  name_en     |  Middle Fork Koyukuk River                 |  Middle Fork Koyukuk
Q1517486   |  MODvalue  |  name_de     |  Noatak River                              |  Noatak
Q1517486   |  MODvalue  |  name_en     |  Noatak River                              |  Noatak
Q1517486   |  MODvalue  |  name_nl     |  Noatak River                              |  Noatak
Q1108030   |  MODvalue  |  name_de     |  Coleen River                              |  Coleen
Q1108030   |  MODvalue  |  name_en     |  Coleen River                              |  Coleen
Q1108030   |  MODvalue  |  name_nl     |  Coleen River                              |  Coleen
Q955645    |  MODvalue  |  name_de     |  Chandalar River                           |  Chandalar
Q955645    |  MODvalue  |  name_en     |  Chandalar River                           |  Chandalar
Q955645    |  MODvalue  |  name_nl     |  Chandalar River                           |  Chandalar
Q2214785   |  MODvalue  |  name_de     |  Salmon River                              |  Salmon
Q2214785   |  MODvalue  |  name_en     |  Salmon River                              |  Salmon
Q1675300   |  MODvalue  |  name_de     |  Itkillik River                            |  Itkillik
Q1675300   |  MODvalue  |  name_en     |  Itkillik River                            |  Itkillik
Q1675300   |  MODvalue  |  name_nl     |  Itkillik River                            |  Itkillik
Q3200297   |  MODvalue  |  name_en     |  Kukpuk River                              |  Kukpuk
Q3200297   |  MODvalue  |  name_nl     |  Kukpuk River                              |  Kukpuk
Q3350185   |  MODvalue  |  name_de     |  Old Crow River                            |  Old Crow
Q3350185   |  MODvalue  |  name_en     |  Old Crow River                            |  Old Crow
Q3350185   |  MODvalue  |  name_es     |  Old Crow River                            |  Old Crow
Q3350185   |  MODvalue  |  name_nl     |  Old Crow River                            |  Old Crow
Q3350185   |  MODvalue  |  name_sv     |  Old Crow River                            |  Old Crow
Q3200297   |  MODvalue  |  name_en     |  Kukpuk River                              |  Kukpuk
Q3200297   |  MODvalue  |  name_nl     |  Kukpuk River                              |  Kukpuk
Q3200296   |  MODvalue  |  name_en     |  Kukpowruk River                           |  Kukpowruk
Q3200296   |  MODvalue  |  name_nl     |  Kukpowruk River                           |  Kukpowruk
Q484545    |  MODvalue  |  name_de     |  Anaktuvuk River                           |  Anaktuvuk
Q484545    |  MODvalue  |  name_en     |  Anaktuvuk River                           |  Anaktuvuk
Q484545    |  MODvalue  |  name_nl     |  Anaktuvuk River                           |  Anaktuvuk
Q1778953   |  MODvalue  |  name_de     |  Kokolik River                             |  Kokolik
Q1778953   |  MODvalue  |  name_en     |  Kokolik River                             |  Kokolik
Q1778953   |  MODvalue  |  name_nl     |  Kokolik River                             |  Kokolik
Q1419623   |  MODvalue  |  name_de     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_en     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_nl     |  Firth River                               |  Firth
Q1419623   |  MODvalue  |  name_sv     |  Firth River                               |  Firth
Q930455    |  MODvalue  |  name_de     |  Ivishak River                             |  Ivishak
Q930455    |  MODvalue  |  name_en     |  Ivishak River                             |  Ivishak
Q930455    |  MODvalue  |  name_nl     |  Ivishak River                             |  Ivishak
Q1061725   |  MODvalue  |  name_de     |  Chandler River                            |  Chandler
Q1061725   |  MODvalue  |  name_en     |  Chandler River                            |  Chandler
Q769397    |  MODvalue  |  name_en     |  Utukok River                              |  Utukok
Q769397    |  MODvalue  |  name_nl     |  Utukok River                              |  Utukok
Q3198650   |  MODvalue  |  name_en     |  Kongakut River                            |  Kongakut
Q3198650   |  MODvalue  |  name_nl     |  Kongakut River                            |  Kongakut
Q179117    |  MODvalue  |  name_de     |  Awuna River                               |  Awuna
Q179117    |  MODvalue  |  name_en     |  Awuna River                               |  Awuna
Q179117    |  MODvalue  |  name_nl     |  Awuna River                               |  Awuna
Q484545    |  MODvalue  |  name_de     |  Anaktuvuk River                           |  Anaktuvuk
Q484545    |  MODvalue  |  name_en     |  Anaktuvuk River                           |  Anaktuvuk
Q484545    |  MODvalue  |  name_nl     |  Anaktuvuk River                           |  Anaktuvuk
Q3148442   |  MODvalue  |  name_en     |  Ikpikpuk River                            |  Ikpikpuk
Q3200508   |  MODvalue  |  name_en     |  Kuparuk River                             |  Kuparuk
Q3200508   |  MODvalue  |  name_nl     |  Kuparuk River                             |  Kuparuk
Q3200508   |  MODvalue  |  name_en     |  Kuparuk River                             |  Kuparuk
Q3200508   |  MODvalue  |  name_nl     |  Kuparuk River                             |  Kuparuk
Q3148442   |  MODvalue  |  name_en     |  Ikpikpuk River                            |  Ikpikpuk
Q2873255   |  MODvalue  |  name_en     |  Avalik River                              |  Avalik
Q3200285   |  MODvalue  |  name_en     |  Kuk River                                 |  Kuk
Q3200285   |  MODvalue  |  name_nl     |  Kuk River                                 |  Kuk
Q1074901   |  MODvalue  |  name_de     |  Chitina River                             |  Chitina
Q1074901   |  MODvalue  |  name_en     |  Chitina River                             |  Chitina
Q1074901   |  MODvalue  |  name_nl     |  Chitina River                             |  Chitina
Q1624702   |  MODvalue  |  name_de     |  Holitna River                             |  Holitna
Q1624702   |  MODvalue  |  name_en     |  Holitna River                             |  Holitna
Q1624702   |  MODvalue  |  name_nl     |  Holitna River                             |  Holitna
Q3342312   |  MODvalue  |  name_de     |  Nizina River                              |  Nizina
Q3342312   |  MODvalue  |  name_en     |  Nizina River                              |  Nizina
Q1882935   |  MODvalue  |  name_de     |  Maclaren River                            |  Maclaren
Q1919701   |  MODvalue  |  name_de     |  Melozitna River                           |  Melozitna
Q1919701   |  MODvalue  |  name_en     |  Melozitna River                           |  Melozitna
Q1919701   |  MODvalue  |  name_nl     |  Melozitna River                           |  Melozitna
Q1556789   |  MODvalue  |  name_de     |  Kandik River                              |  Kandik
Q1556789   |  MODvalue  |  name_en     |  Kandik River                              |  Kandik
Q1556789   |  MODvalue  |  name_nl     |  Kandik River                              |  Kandik
Q968950    |  MODvalue  |  name_de     |  Killik River                              |  Killik
Q968950    |  MODvalue  |  name_en     |  Killik River                              |  Killik
Q968950    |  MODvalue  |  name_nl     |  Killik River                              |  Killik
Q574703    |  MODvalue  |  name_de     |  Wind River                                |  Wind
Q574703    |  MODvalue  |  name_en     |  Wind River                                |  Wind
Q574703    |  MODvalue  |  name_nl     |  Wind River                                |  Wind
Q60065     |  MODvalue  |  name_de     |  Susitna River                             |  Susitna
Q60065     |  MODvalue  |  name_en     |  Susitna River                             |  Susitna
Q968475    |  MODvalue  |  name_de     |  Black River                               |  Black
Q968475    |  MODvalue  |  name_en     |  Black River                               |  Black
Q968475    |  MODvalue  |  name_nl     |  Black River                               |  Black
Q2927472   |  MODvalue  |  name_en     |  Buckland River                            |  Buckland
Q2927472   |  MODvalue  |  name_nl     |  Buckland River                            |  Buckland
Q3143457   |  MODvalue  |  name_en     |  Huslia River                              |  Huslia
Q3143457   |  MODvalue  |  name_nl     |  Huslia River                              |  Huslia
Q1033410   |  MODvalue  |  name_de     |  Canning River                             |  Canning
Q1033410   |  MODvalue  |  name_en     |  Canning River                             |  Canning
Q1547693   |  MODvalue  |  name_de     |  Groundhog River                           |  Groundhog
Q1547693   |  MODvalue  |  name_en     |  Groundhog River                           |  Groundhog
Q1547693   |  MODvalue  |  name_fr     |  Groundhog River                           |  Groundhog
Q1547693   |  MODvalue  |  name_nl     |  Groundhog River                           |  Groundhog
Q1547693   |  MODvalue  |  name_sv     |  Groundhog River                           |  Groundhog
Q1485122   |  MODvalue  |  name_de     |  Pigeon River                              |  Pigeon
Q1485122   |  MODvalue  |  name_en     |  Pigeon River                              |  Pigeon
Q534181    |  MODvalue  |  name_de     |  St. Croix River                           |  St. Croix
Q534181    |  MODvalue  |  name_en     |  Saint Croix River                         |  Saint Croix
Q534181    |  MODvalue  |  name_nl     |  Saint Croix River                         |  Saint Croix
Q534181    |  MODvalue  |  name_sv     |  St. Croix River                           |  St. Croix
Q2886123   |  MODvalue  |  name_de     |  St. Marys River                           |  St. Marys
Q2886123   |  MODvalue  |  name_en     |  St. Marys River                           |  St. Marys
Q859238    |  MODvalue  |  name_de     |  Big Sandy River                           |  Big Sandy
Q859238    |  MODvalue  |  name_en     |  Big Sandy River                           |  Big Sandy
Q859238    |  MODvalue  |  name_nl     |  Big Sandy River                           |  Big Sandy
Q4978769   |  MODvalue  |  name_de     |  Brule River                               |  Brule
Q4978769   |  MODvalue  |  name_en     |  Brule River                               |  Brule
Q13130     |  MODvalue  |  name_de     |  Menominee River                           |  Menominee
Q13130     |  MODvalue  |  name_en     |  Menominee River                           |  Menominee
Q1273955   |  MODvalue  |  name_de     |  Saint Louis River                         |  Saint Louis
Q1273955   |  MODvalue  |  name_en     |  Saint Louis River                         |  Saint Louis
Q1273955   |  MODvalue  |  name_nl     |  Saint Louis River                         |  Saint Louis
Q1108022   |  MODvalue  |  name_de     |  Saint Francis River                       |  Saint Francis
Q1108022   |  MODvalue  |  name_en     |  St. Francis River                         |  St. Francis
Q1108022   |  MODvalue  |  name_nl     |  St. Francis River                         |  St. Francis
Q1108022   |  MODvalue  |  name_pl     |  Saint Francis River                       |  Saint Francis
Q60974     |  MODvalue  |  name_de     |  Ottawa River                              |  Ottawa
Q60974     |  MODvalue  |  name_en     |  Ottawa River                              |  Ottawa
Q60974     |  MODvalue  |  name_it     |  Ottawa River                              |  Ottawa
Q860139    |  MODvalue  |  name_en     |  Romaine River                             |  Romaine
Q3433776   |  MODvalue  |  name_en     |  Patapédia River                           |  Patapédia
Q1814459   |  MODvalue  |  name_en     |  Restigouche River                         |  Restigouche
Q1814459   |  MODvalue  |  name_sv     |  Restigouche River                         |  Restigouche
Q71996     |  MODvalue  |  name_en     |  Harricana River                           |  Harricana
Q71996     |  MODvalue  |  name_nl     |  Harricana River                           |  Harricana
Q11880756  |  MODvalue  |  name_de     |  Manigotagan River                         |  Manigotagan
Q11880756  |  MODvalue  |  name_en     |  Manigotagan River                         |  Manigotagan
Q11880756  |  MODvalue  |  name_sv     |  Manigotagan River                         |  Manigotagan
Q7590512   |  MODvalue  |  name_en     |  St. Mary River                            |  St. Mary
Q885244    |  MODvalue  |  name_de     |  Bloodvein River                           |  Bloodvein
Q885244    |  MODvalue  |  name_en     |  Bloodvein River                           |  Bloodvein
Q885244    |  MODvalue  |  name_fr     |  Bloodvein River                           |  Bloodvein
Q885244    |  MODvalue  |  name_nl     |  Bloodvein River                           |  Bloodvein
Q885244    |  MODvalue  |  name_sv     |  Bloodvein River                           |  Bloodvein
Q5364109   |  MODvalue  |  name_en     |  Elk River                                 |  Elk
Q5364109   |  MODvalue  |  name_pl     |  Elk River                                 |  Elk
Q2262      |  MODvalue  |  name_de     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_en     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_nl     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_sv     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_de     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_en     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_nl     |  Kootenay River                            |  Kootenay
Q2262      |  MODvalue  |  name_sv     |  Kootenay River                            |  Kootenay
Q15124841  |  MODvalue  |  name_de     |  Pigeon River                              |  Pigeon
Q1173016   |  MODvalue  |  name_de     |  Dauphin River                             |  Dauphin
Q1173016   |  MODvalue  |  name_en     |  Dauphin River                             |  Dauphin
Q1173016   |  MODvalue  |  name_nl     |  Dauphin River                             |  Dauphin
Q1173016   |  MODvalue  |  name_sv     |  Dauphin River                             |  Dauphin
Q819057    |  MODvalue  |  name_de     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_en     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_fr     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_nl     |  Berens River                              |  Berens
Q2372020   |  MODvalue  |  name_de     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_en     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_sv     |  Swan River                                |  Swan
Q2135928   |  MODvalue  |  name_de     |  Red Deer River                            |  Red Deer
Q270562    |  NEWvalue  |  name_de     |                                            |  Duncan
Q270562    |  MODvalue  |  name_en     |  Duncan River                              |  Duncan
Q270562    |  NEWvalue  |  name_de     |                                            |  Duncan
Q270562    |  MODvalue  |  name_en     |  Duncan River                              |  Duncan
Q1621199   |  MODvalue  |  name_de     |  Poplar River                              |  Poplar
Q1621199   |  MODvalue  |  name_en     |  Poplar River                              |  Poplar
Q1621199   |  MODvalue  |  name_sv     |  Poplar River                              |  Poplar
Q1586288   |  MODvalue  |  name_de     |  Harrison River                            |  Harrison
Q1586288   |  MODvalue  |  name_en     |  Harrison River                            |  Harrison
Q1586288   |  MODvalue  |  name_fr     |  Harrison River                            |  Harrison
Q1586288   |  MODvalue  |  name_nl     |  Harrison River                            |  Harrison
Q1586288   |  MODvalue  |  name_sv     |  Harrison River                            |  Harrison
Q280542    |  MODvalue  |  name_de     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_en     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_fr     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_sv     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_de     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_en     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_fr     |  Shuswap River                             |  Shuswap
Q280542    |  MODvalue  |  name_sv     |  Shuswap River                             |  Shuswap
Q351963    |  MODvalue  |  name_de     |  Adams River                               |  Adams
Q351963    |  MODvalue  |  name_en     |  Adams River                               |  Adams
Q351963    |  MODvalue  |  name_sv     |  Adams River                               |  Adams
Q7396716   |  MODvalue  |  name_de     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_en     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_nl     |  Sachigo River                             |  Sachigo
Q7396716   |  MODvalue  |  name_sv     |  Sachigo River                             |  Sachigo
Q268952    |  MODvalue  |  name_de     |  Lillooet River                            |  Lillooet
Q268952    |  MODvalue  |  name_en     |  Lillooet River                            |  Lillooet
Q268952    |  MODvalue  |  name_nl     |  Lillooet River                            |  Lillooet
Q268952    |  MODvalue  |  name_sv     |  Lillooet River                            |  Lillooet
Q5657056   |  MODvalue  |  name_en     |  Hargrave River                            |  Hargrave
Q3292      |  NEWvalue  |  name_bn     |                                            |  নেলসন নদী
Q3292      |  MODvalue  |  name_de     |  Nelson River                              |  Nelson
Q3292      |  MODvalue  |  name_en     |  Nelson River                              |  Nelson
Q2359245   |  MODvalue  |  name_de     |  Sturgeon-weir River                       |  Sturgeon-weir
Q2359245   |  MODvalue  |  name_en     |  Sturgeon-Weir River                       |  Sturgeon-Weir
Q2359245   |  MODvalue  |  name_sv     |  Sturgeon-weir River                       |  Sturgeon-weir
Q72673     |  MODvalue  |  name_de     |  Hayes River                               |  Hayes
Q72673     |  MODvalue  |  name_en     |  Hayes River                               |  Hayes
Q72673     |  MODvalue  |  name_nl     |  Hayes River                               |  Hayes
Q15128706  |  MODvalue  |  name_de     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_en     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_nl     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_sv     |  Smoothstone River                         |  Smoothstone
Q72673     |  MODvalue  |  name_de     |  Hayes River                               |  Hayes
Q72673     |  MODvalue  |  name_en     |  Hayes River                               |  Hayes
Q72673     |  MODvalue  |  name_nl     |  Hayes River                               |  Hayes
Q7687133   |  MODvalue  |  name_en     |  Taseko River                              |  Taseko
Q7687133   |  MODvalue  |  name_sv     |  Taseko River                              |  Taseko
Q15128706  |  MODvalue  |  name_de     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_en     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_nl     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_sv     |  Smoothstone River                         |  Smoothstone
Q7974133   |  MODvalue  |  name_de     |  Waterhen River                            |  Waterhen
Q7974133   |  MODvalue  |  name_en     |  Waterhen River                            |  Waterhen
Q7974133   |  MODvalue  |  name_nl     |  Waterhen River                            |  Waterhen
Q7974133   |  MODvalue  |  name_sv     |  Waterhen River                            |  Waterhen
Q270485    |  MODvalue  |  name_de     |  Homathko River                            |  Homathko
Q270485    |  MODvalue  |  name_en     |  Homathko River                            |  Homathko
Q270485    |  MODvalue  |  name_fr     |  Homathko River                            |  Homathko
Q270485    |  MODvalue  |  name_nl     |  Homathko River                            |  Homathko
Q270485    |  MODvalue  |  name_sv     |  Homathko River                            |  Homathko
Q7974133   |  MODvalue  |  name_de     |  Waterhen River                            |  Waterhen
Q7974133   |  MODvalue  |  name_en     |  Waterhen River                            |  Waterhen
Q7974133   |  MODvalue  |  name_nl     |  Waterhen River                            |  Waterhen
Q7974133   |  MODvalue  |  name_sv     |  Waterhen River                            |  Waterhen
Q1946435   |  MODvalue  |  name_de     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_en     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_sv     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_de     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_en     |  Montreal River                            |  Montreal
Q1946435   |  MODvalue  |  name_sv     |  Montreal River                            |  Montreal
Q268202    |  MODvalue  |  name_de     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_en     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_fr     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_nl     |  Horsefly River                            |  Horsefly
Q268202    |  MODvalue  |  name_sv     |  Horsefly River                            |  Horsefly
Q15108593  |  MODvalue  |  name_de     |  Canoe River                               |  Canoe
Q2372020   |  MODvalue  |  name_de     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_en     |  Swan River                                |  Swan
Q2372020   |  MODvalue  |  name_sv     |  Swan River                                |  Swan
Q15111285  |  MODvalue  |  name_de     |  Gauer River                               |  Gauer
Q15111285  |  MODvalue  |  name_en     |  Gauer River                               |  Gauer
Q15111285  |  MODvalue  |  name_nl     |  Gauer River                               |  Gauer
Q15111285  |  MODvalue  |  name_sv     |  Gauer River                               |  Gauer
Q616784    |  MODvalue  |  name_de     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_en     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_fr     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_nl     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_sv     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_de     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_en     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_fr     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_nl     |  Wabasca River                             |  Wabasca
Q616784    |  MODvalue  |  name_sv     |  Wabasca River                             |  Wabasca
Q270445    |  MODvalue  |  name_en     |  Kitlope River                             |  Kitlope
Q270445    |  MODvalue  |  name_sv     |  Kitlope River                             |  Kitlope
Q270479    |  MODvalue  |  name_de     |  Parsnip River                             |  Parsnip
Q270479    |  MODvalue  |  name_en     |  Parsnip River                             |  Parsnip
Q270479    |  MODvalue  |  name_fr     |  Parsnip River                             |  Parsnip
Q270479    |  MODvalue  |  name_nl     |  Parsnip River                             |  Parsnip
Q270479    |  MODvalue  |  name_sv     |  Parsnip River                             |  Parsnip
Q553334    |  MODvalue  |  name_de     |  Stuart River                              |  Stuart
Q553334    |  MODvalue  |  name_en     |  Stuart River                              |  Stuart
Q1099559   |  MODvalue  |  name_de     |  Clearwater River                          |  Clearwater
Q1099559   |  MODvalue  |  name_en     |  Clearwater River                          |  Clearwater
Q1099559   |  NEWvalue  |  name_ja     |                                            |  クリアウォーター川
Q1099559   |  MODvalue  |  name_nl     |  Clearwater River                          |  Clearwater
Q1099559   |  MODvalue  |  name_sv     |  Clearwater River                          |  Clearwater
Q15128873  |  MODvalue  |  name_de     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_en     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_it     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_nl     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_de     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_en     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_it     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_nl     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_de     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_en     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_it     |  South Seal River                          |  South Seal
Q15128873  |  MODvalue  |  name_nl     |  South Seal River                          |  South Seal
Q72063     |  MODvalue  |  name_de     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_en     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_it     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_nl     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_sv     |  Seal River                                |  Seal
Q15123008  |  MODvalue  |  name_de     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_en     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_nl     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_sv     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_de     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_en     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_nl     |  North Seal River                          |  North Seal
Q15123008  |  MODvalue  |  name_sv     |  North Seal River                          |  North Seal
Q15842603  |  MODvalue  |  name_en     |  Swampy Bay River                          |  Swampy Bay
Q15842603  |  MODvalue  |  name_en     |  Swampy Bay River                          |  Swampy Bay
Q268946    |  MODvalue  |  name_de     |  Middle River                              |  Middle
Q268946    |  MODvalue  |  name_en     |  Middle River                              |  Middle
Q268946    |  MODvalue  |  name_fr     |  Middle River                              |  Middle
Q268946    |  MODvalue  |  name_nl     |  Middle River                              |  Middle
Q268946    |  MODvalue  |  name_sv     |  Middle River                              |  Middle
Q15107689  |  MODvalue  |  name_de     |  Birch River                               |  Birch
Q15135332  |  MODvalue  |  name_de     |  Wolverine River                           |  Wolverine
Q15135332  |  MODvalue  |  name_en     |  Wolverine River                           |  Wolverine
Q15135332  |  MODvalue  |  name_sv     |  Wolverine River                           |  Wolverine
Q72063     |  MODvalue  |  name_de     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_en     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_it     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_nl     |  Seal River                                |  Seal
Q72063     |  MODvalue  |  name_sv     |  Seal River                                |  Seal
Q15135332  |  MODvalue  |  name_de     |  Wolverine River                           |  Wolverine
Q15135332  |  MODvalue  |  name_en     |  Wolverine River                           |  Wolverine
Q15135332  |  MODvalue  |  name_sv     |  Wolverine River                           |  Wolverine
Q20054135  |  MODvalue  |  name_en     |  Aigneau River                             |  Aigneau
Q20054135  |  MODvalue  |  name_nl     |  Aigneau River                             |  Aigneau
Q20054135  |  NEWvalue  |  name_sv     |                                            |  Rivière Aigneau
Q2216      |  MODvalue  |  name_de     |  Athabasca River                           |  Athabasca
Q2216      |  MODvalue  |  name_en     |  Athabasca River                           |  Athabasca
Q270894    |  MODvalue  |  name_de     |  Omineca River                             |  Omineca
Q270894    |  MODvalue  |  name_en     |  Omineca River                             |  Omineca
Q270894    |  MODvalue  |  name_sv     |  Omineca River                             |  Omineca
Q15120122  |  MODvalue  |  name_de     |  Mesilinka River                           |  Mesilinka
Q15120122  |  MODvalue  |  name_en     |  Mesilinka River                           |  Mesilinka
Q15120122  |  MODvalue  |  name_sv     |  Mesilinka River                           |  Mesilinka
Q270412    |  MODvalue  |  name_de     |  Ospika River                              |  Ospika
Q270412    |  MODvalue  |  name_en     |  Ospika River                              |  Ospika
Q270412    |  MODvalue  |  name_sv     |  Ospika River                              |  Ospika
Q217670    |  MODvalue  |  name_en     |  Kogaluc River                             |  Kogaluc
Q2397964   |  MODvalue  |  name_de     |  Tazin River                               |  Tazin
Q2397964   |  MODvalue  |  name_en     |  Tazin River                               |  Tazin
Q217663    |  MODvalue  |  name_de     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_en     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_nl     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_sv     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_de     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_en     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_nl     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_sv     |  Tha-anne River                            |  Tha-anne
Q2397964   |  MODvalue  |  name_de     |  Tazin River                               |  Tazin
Q2397964   |  MODvalue  |  name_en     |  Tazin River                               |  Tazin
Q321491    |  MODvalue  |  name_de     |  Abitau River                              |  Abitau
Q321491    |  MODvalue  |  name_en     |  Abitau River                              |  Abitau
Q321491    |  MODvalue  |  name_sv     |  Abitau River                              |  Abitau
Q217670    |  MODvalue  |  name_en     |  Kogaluc River                             |  Kogaluc
Q217663    |  MODvalue  |  name_de     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_en     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_nl     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_sv     |  Tha-anne River                            |  Tha-anne
Q15108141  |  MODvalue  |  name_de     |  Buffalo River                             |  Buffalo
Q15108141  |  MODvalue  |  name_en     |  Buffalo River                             |  Buffalo
Q15118712  |  MODvalue  |  name_de     |  Little Buffalo River                      |  Little Buffalo
Q15118712  |  MODvalue  |  name_en     |  Little Buffalo River                      |  Little Buffalo
Q2231      |  MODvalue  |  name_de     |  Hay River                                 |  Hay
Q2231      |  MODvalue  |  name_en     |  Hay River                                 |  Hay
Q2231      |  MODvalue  |  name_it     |  Hay River                                 |  Hay
Q2231      |  MODvalue  |  name_nl     |  Hay River                                 |  Hay
Q2231      |  MODvalue  |  name_sv     |  Hay River                                 |  Hay
Q15132109  |  MODvalue  |  name_de     |  Thoa River                                |  Thoa
Q15132109  |  MODvalue  |  name_en     |  Thoa River                                |  Thoa
Q15132109  |  MODvalue  |  name_nl     |  Thoa River                                |  Thoa
Q15132109  |  MODvalue  |  name_sv     |  Thoa River                                |  Thoa
Q1163523   |  MODvalue  |  name_de     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_en     |  Dubawnt River                             |  Dubawnt
Q94258     |  MODvalue  |  name_en     |  Povungnituk River                         |  Povungnituk
Q2391021   |  MODvalue  |  name_de     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_en     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_nl     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_sv     |  Taltson River                             |  Taltson
Q719436    |  MODvalue  |  name_de     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_en     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_nl     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_sv     |  Kazan River                               |  Kazan
Q2391021   |  MODvalue  |  name_de     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_en     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_nl     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_sv     |  Taltson River                             |  Taltson
Q94258     |  MODvalue  |  name_en     |  Povungnituk River                         |  Povungnituk
Q2391021   |  MODvalue  |  name_de     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_en     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_nl     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_sv     |  Taltson River                             |  Taltson
Q270571    |  MODvalue  |  name_de     |  Petitot River                             |  Petitot
Q270571    |  MODvalue  |  name_en     |  Petitot River                             |  Petitot
Q270571    |  MODvalue  |  name_nl     |  Petitot River                             |  Petitot
Q270571    |  MODvalue  |  name_sv     |  Petitot River                             |  Petitot
Q15108141  |  MODvalue  |  name_de     |  Buffalo River                             |  Buffalo
Q15108141  |  MODvalue  |  name_en     |  Buffalo River                             |  Buffalo
Q94258     |  MODvalue  |  name_en     |  Povungnituk River                         |  Povungnituk
Q1406237   |  MODvalue  |  name_de     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_en     |  Ferguson River                            |  Ferguson
Q15126242  |  MODvalue  |  name_en     |  Lepellé River                             |  Lepellé
Q268328    |  MODvalue  |  name_de     |  Iskut River                               |  Iskut
Q268328    |  MODvalue  |  name_en     |  Iskut River                               |  Iskut
Q268328    |  MODvalue  |  name_fr     |  Iskut River                               |  Iskut
Q268328    |  MODvalue  |  name_nl     |  Iskut River                               |  Iskut
Q268328    |  MODvalue  |  name_sv     |  Iskut River                               |  Iskut
Q2391021   |  MODvalue  |  name_de     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_en     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_nl     |  Taltson River                             |  Taltson
Q2391021   |  MODvalue  |  name_sv     |  Taltson River                             |  Taltson
Q1406237   |  MODvalue  |  name_de     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_en     |  Ferguson River                            |  Ferguson
Q6349481   |  MODvalue  |  name_de     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_en     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_sv     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_de     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_en     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_sv     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_de     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_en     |  Kakisa River                              |  Kakisa
Q6349481   |  MODvalue  |  name_sv     |  Kakisa River                              |  Kakisa
Q1406237   |  MODvalue  |  name_de     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_en     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_de     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_en     |  Ferguson River                            |  Ferguson
Q22629110  |  MODvalue  |  name_en     |  Hoarfrost River                           |  Hoarfrost
Q22629110  |  MODvalue  |  name_nl     |  Hoarfrost River                           |  Hoarfrost
Q22629110  |  MODvalue  |  name_sv     |  Hoarfrost River                           |  Hoarfrost
Q187803    |  MODvalue  |  name_de     |  Yellowknife River                         |  Yellowknife
Q187803    |  MODvalue  |  name_en     |  Yellowknife River                         |  Yellowknife
Q187803    |  MODvalue  |  name_sv     |  Yellowknife River                         |  Yellowknife
Q1867521   |  MODvalue  |  name_de     |  Lockhart River                            |  Lockhart
Q1867521   |  MODvalue  |  name_en     |  Lockhart River                            |  Lockhart
Q1867521   |  MODvalue  |  name_sv     |  Lockhart River                            |  Lockhart
Q22468629  |  MODvalue  |  name_en     |  McCrea River                              |  McCrea
Q22468629  |  MODvalue  |  name_nl     |  McCrea River                              |  McCrea
Q22468629  |  MODvalue  |  name_sv     |  McCrea River                              |  McCrea
Q187803    |  MODvalue  |  name_de     |  Yellowknife River                         |  Yellowknife
Q187803    |  MODvalue  |  name_en     |  Yellowknife River                         |  Yellowknife
Q187803    |  MODvalue  |  name_sv     |  Yellowknife River                         |  Yellowknife
Q15134975  |  MODvalue  |  name_de     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_en     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_nl     |  Willowlake River                          |  Willowlake
Q15134975  |  MODvalue  |  name_sv     |  Willowlake River                          |  Willowlake
Q1867521   |  MODvalue  |  name_de     |  Lockhart River                            |  Lockhart
Q1867521   |  MODvalue  |  name_en     |  Lockhart River                            |  Lockhart
Q1867521   |  MODvalue  |  name_sv     |  Lockhart River                            |  Lockhart
Q1867521   |  MODvalue  |  name_de     |  Lockhart River                            |  Lockhart
Q1867521   |  MODvalue  |  name_en     |  Lockhart River                            |  Lockhart
Q1867521   |  MODvalue  |  name_sv     |  Lockhart River                            |  Lockhart
Q22504785  |  MODvalue  |  name_de     |  Frances River                             |  Frances
Q22504785  |  MODvalue  |  name_en     |  Frances River                             |  Frances
Q22504785  |  MODvalue  |  name_nl     |  Frances River                             |  Frances
Q22504785  |  MODvalue  |  name_sv     |  Frances River                             |  Frances
Q15128716  |  MODvalue  |  name_de     |  Snare River                               |  Snare
Q15128716  |  MODvalue  |  name_de     |  Snare River                               |  Snare
Q1867521   |  MODvalue  |  name_de     |  Lockhart River                            |  Lockhart
Q1867521   |  MODvalue  |  name_en     |  Lockhart River                            |  Lockhart
Q1867521   |  MODvalue  |  name_sv     |  Lockhart River                            |  Lockhart
Q15119414  |  MODvalue  |  name_de     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_en     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_nl     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_sv     |  Marian River                              |  Marian
Q15110333  |  MODvalue  |  name_de     |  Emile River                               |  Emile
Q15110333  |  MODvalue  |  name_en     |  Emile River                               |  Emile
Q15110333  |  MODvalue  |  name_nl     |  Emile River                               |  Emile
Q15110333  |  MODvalue  |  name_sv     |  Emile River                               |  Emile
Q15119414  |  MODvalue  |  name_de     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_en     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_nl     |  Marian River                              |  Marian
Q15119414  |  MODvalue  |  name_sv     |  Marian River                              |  Marian
Q15128716  |  MODvalue  |  name_de     |  Snare River                               |  Snare
Q15128716  |  MODvalue  |  name_de     |  Snare River                               |  Snare
Q15128716  |  MODvalue  |  name_de     |  Snare River                               |  Snare
Q15107756  |  MODvalue  |  name_de     |  Blackwater River                          |  Blackwater
Q15107756  |  MODvalue  |  name_en     |  Blackwater River                          |  Blackwater
Q750009    |  MODvalue  |  name_de     |  Takhini River                             |  Takhini
Q750009    |  MODvalue  |  name_en     |  Takhini River                             |  Takhini
Q750009    |  MODvalue  |  name_pl     |  Takhini River                             |  Takhini
Q750009    |  MODvalue  |  name_sv     |  Takhini River                             |  Takhini
Q22400924  |  MODvalue  |  name_en     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_nl     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_sv     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_en     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_nl     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_sv     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_en     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_nl     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_sv     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_en     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_nl     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_sv     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_en     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_nl     |  Amadjuak River                            |  Amadjuak
Q22400924  |  MODvalue  |  name_sv     |  Amadjuak River                            |  Amadjuak
Q22630419  |  MODvalue  |  name_en     |  Murchison River                           |  Murchison
Q22630419  |  MODvalue  |  name_nl     |  Murchison River                           |  Murchison
Q22630419  |  MODvalue  |  name_sv     |  Murchison River                           |  Murchison
Q22420001  |  MODvalue  |  name_en     |  Kingora River                             |  Kingora
Q22420001  |  MODvalue  |  name_nl     |  Kingora River                             |  Kingora
Q22420001  |  MODvalue  |  name_sv     |  Kingora River                             |  Kingora
Q22596300  |  MODvalue  |  name_en     |  Hantzsch River                            |  Hantzsch
Q22596300  |  MODvalue  |  name_nl     |  Hantzsch River                            |  Hantzsch
Q22596300  |  MODvalue  |  name_sv     |  Hantzsch River                            |  Hantzsch
Q22596300  |  MODvalue  |  name_en     |  Hantzsch River                            |  Hantzsch
Q22596300  |  MODvalue  |  name_nl     |  Hantzsch River                            |  Hantzsch
Q22596300  |  MODvalue  |  name_sv     |  Hantzsch River                            |  Hantzsch
Q5350280   |  MODvalue  |  name_en     |  Ekalluk River                             |  Ekalluk
Q5350280   |  MODvalue  |  name_sv     |  Ekalluk River                             |  Ekalluk
Q5350280   |  MODvalue  |  name_en     |  Ekalluk River                             |  Ekalluk
Q5350280   |  MODvalue  |  name_sv     |  Ekalluk River                             |  Ekalluk
Q22503030  |  MODvalue  |  name_nl     |  Kagloryuak River                          |  Kagloryuak
Q22503030  |  MODvalue  |  name_sv     |  Kagloryuak River                          |  Kagloryuak
Q6964092   |  MODvalue  |  name_en     |  Nanook River                              |  Nanook
Q6964092   |  MODvalue  |  name_sv     |  Nanook River                              |  Nanook
Q22562731  |  MODvalue  |  name_sv     |  Kuuk River                                |  Kuuk
Q22562704  |  MODvalue  |  name_sv     |  Kuujjua River                             |  Kuujjua
Q6872235   |  MODvalue  |  name_en     |  Mira River                                |  Mira
Q490358    |  MODvalue  |  name_de     |  Exploits River                            |  Exploits
Q490358    |  MODvalue  |  name_en     |  Exploits River                            |  Exploits
Q490358    |  MODvalue  |  name_sv     |  Exploits River                            |  Exploits
Q4081164   |  MODvalue  |  name_en     |  Bay du Nord River                         |  Bay du Nord
Q4081164   |  MODvalue  |  name_sv     |  Bay du Nord River                         |  Bay du Nord
Q1636789   |  MODvalue  |  name_de     |  Humber River                              |  Humber
Q1636789   |  MODvalue  |  name_en     |  Humber River                              |  Humber
Q1636789   |  MODvalue  |  name_sv     |  Humber River                              |  Humber
Q1324855   |  MODvalue  |  name_de     |  Gander River                              |  Gander
Q1324855   |  MODvalue  |  name_en     |  Gander River                              |  Gander
Q1324855   |  MODvalue  |  name_nl     |  Gander River                              |  Gander
Q1324855   |  MODvalue  |  name_sv     |  Gander River                              |  Gander
Q3458794   |  MODvalue  |  name_en     |  Sinaloa River                             |  Sinaloa
Q847785    |  MODvalue  |  name_de     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_en     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_nl     |  Colorado River                            |  Colorado
Q2748200   |  MODvalue  |  name_en     |  Kissimmee River                           |  Kissimmee
Q2748200   |  MODvalue  |  name_sv     |  Kissimmee River                           |  Kissimmee
Q2748200   |  MODvalue  |  name_en     |  Kissimmee River                           |  Kissimmee
Q2748200   |  MODvalue  |  name_sv     |  Kissimmee River                           |  Kissimmee
Q7414617   |  MODvalue  |  name_en     |  San Juan River                            |  San Juan
Q1468723   |  MODvalue  |  name_de     |  Nueces River                              |  Nueces
Q1468723   |  MODvalue  |  name_en     |  Nueces River                              |  Nueces
Q1468723   |  MODvalue  |  name_nl     |  Nueces River                              |  Nueces
Q3433689   |  MODvalue  |  name_en     |  Frio River                                |  Frio
Q1552614   |  MODvalue  |  name_de     |  Guadalupe River                           |  Guadalupe
Q1552614   |  MODvalue  |  name_en     |  Guadalupe River                           |  Guadalupe
Q1552614   |  MODvalue  |  name_fr     |  Guadalupe River                           |  Guadalupe
Q847785    |  MODvalue  |  name_de     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_en     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_nl     |  Colorado River                            |  Colorado
Q964437    |  MODvalue  |  name_de     |  Neches River                              |  Neches
Q964437    |  MODvalue  |  name_en     |  Neches River                              |  Neches
Q964437    |  MODvalue  |  name_nl     |  Neches River                              |  Neches
Q3433661   |  MODvalue  |  name_en     |  Calcasieu River                           |  Calcasieu
Q847785    |  MODvalue  |  name_de     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_en     |  Colorado River                            |  Colorado
Q847785    |  MODvalue  |  name_nl     |  Colorado River                            |  Colorado
Q499797    |  MODvalue  |  name_de     |  Trinity River                             |  Trinity
Q499797    |  MODvalue  |  name_en     |  Trinity River                             |  Trinity
Q1428859   |  MODvalue  |  name_de     |  Flint River                               |  Flint
Q1428859   |  MODvalue  |  name_en     |  Flint River                               |  Flint
Q1428859   |  MODvalue  |  name_it     |  Flint River                               |  Flint
Q4762748   |  MODvalue  |  name_en     |  Angelina River                            |  Angelina
Q4762748   |  MODvalue  |  name_en     |  Angelina River                            |  Angelina
Q1424101   |  MODvalue  |  name_de     |  Tallapoosa River                          |  Tallapoosa
Q1424101   |  MODvalue  |  name_en     |  Tallapoosa River                          |  Tallapoosa
Q2041614   |  MODvalue  |  name_de     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_en     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_nl     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_pl     |  Ouachita River                            |  Ouachita
Q6651659   |  MODvalue  |  name_en     |  Little River                              |  Little
Q2599098   |  MODvalue  |  name_de     |  Yalobusha River                           |  Yalobusha
Q2599098   |  MODvalue  |  name_en     |  Yalobusha River                           |  Yalobusha
Q2599098   |  MODvalue  |  name_fr     |  Yalobusha River                           |  Yalobusha
Q2599098   |  MODvalue  |  name_nl     |  Yalobusha River                           |  Yalobusha
Q1341271   |  MODvalue  |  name_de     |  Salt River                                |  Salt
Q1341271   |  MODvalue  |  name_en     |  Salt River                                |  Salt
Q1341271   |  MODvalue  |  name_it     |  Salt River                                |  Salt
Q1341271   |  MODvalue  |  name_nl     |  Salt River                                |  Salt
Q1341271   |  NEWvalue  |  name_pl     |                                            |  Salt
Q6651668   |  MODvalue  |  name_en     |  Little River                              |  Little
Q3566675   |  MODvalue  |  name_en     |  Wateree River                             |  Wateree
Q3566675   |  MODvalue  |  name_nl     |  Wateree River                             |  Wateree
Q6651668   |  MODvalue  |  name_en     |  Little River                              |  Little
Q7406275   |  MODvalue  |  name_en     |  Saluda River                              |  Saluda
Q7406275   |  MODvalue  |  name_nl     |  Saluda River                              |  Saluda
Q7406275   |  MODvalue  |  name_en     |  Saluda River                              |  Saluda
Q7406275   |  MODvalue  |  name_nl     |  Saluda River                              |  Saluda
Q968071    |  MODvalue  |  name_de     |  Etowah River                              |  Etowah
Q968071    |  MODvalue  |  name_en     |  Etowah River                              |  Etowah
Q2993598   |  MODvalue  |  name_de     |  Washita River                             |  Washita
Q2993598   |  MODvalue  |  name_en     |  Washita River                             |  Washita
Q2993598   |  MODvalue  |  name_pl     |  Washita River                             |  Washita
Q1050460   |  MODvalue  |  name_de     |  Catawba River                             |  Catawba
Q1050460   |  MODvalue  |  name_en     |  Catawba River                             |  Catawba
Q1050460   |  MODvalue  |  name_nl     |  Catawba River                             |  Catawba
Q2041614   |  MODvalue  |  name_de     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_en     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_nl     |  Ouachita River                            |  Ouachita
Q2041614   |  MODvalue  |  name_pl     |  Ouachita River                            |  Ouachita
Q5364109   |  MODvalue  |  name_en     |  Elk River                                 |  Elk
Q5364109   |  MODvalue  |  name_pl     |  Elk River                                 |  Elk
Q1606944   |  MODvalue  |  name_de     |  Neuse River                               |  Neuse
Q1606944   |  MODvalue  |  name_en     |  Neuse River                               |  Neuse
Q1606944   |  MODvalue  |  name_fr     |  Neuse River                               |  Neuse
Q1050460   |  MODvalue  |  name_de     |  Catawba River                             |  Catawba
Q1050460   |  MODvalue  |  name_en     |  Catawba River                             |  Catawba
Q1050460   |  MODvalue  |  name_nl     |  Catawba River                             |  Catawba
Q2065465   |  MODvalue  |  name_en     |  North Canadian River                      |  North Canadian
Q2065465   |  MODvalue  |  name_fr     |  North Canadian River                      |  North Canadian
Q2065465   |  MODvalue  |  name_sv     |  North Canadian River                      |  North Canadian
Q2065465   |  MODvalue  |  name_en     |  North Canadian River                      |  North Canadian
Q2065465   |  MODvalue  |  name_fr     |  North Canadian River                      |  North Canadian
Q2065465   |  MODvalue  |  name_sv     |  North Canadian River                      |  North Canadian
Q1126662   |  MODvalue  |  name_de     |  Kern River                                |  Kern
Q1126662   |  MODvalue  |  name_en     |  Kern River                                |  Kern
Q1126662   |  MODvalue  |  name_fr     |  Kern River                                |  Kern
Q1126662   |  MODvalue  |  name_nl     |  Kern River                                |  Kern
Q516393    |  MODvalue  |  name_en     |  Neosho River                              |  Neosho
Q943521    |  MODvalue  |  name_en     |  Verdigris River                           |  Verdigris
Q943521    |  MODvalue  |  name_nl     |  Verdigris River                           |  Verdigris
Q1092055   |  MODvalue  |  name_de     |  Cimarron River                            |  Cimarron
Q1092055   |  MODvalue  |  name_en     |  Cimarron River                            |  Cimarron
Q1092055   |  MODvalue  |  name_nl     |  Cimarron River                            |  Cimarron
Q1101503   |  MODvalue  |  name_de     |  Clinch River                              |  Clinch
Q1101503   |  MODvalue  |  name_en     |  Clinch River                              |  Clinch
Q1101503   |  MODvalue  |  name_nl     |  Clinch River                              |  Clinch
Q1101503   |  MODvalue  |  name_de     |  Clinch River                              |  Clinch
Q1101503   |  MODvalue  |  name_en     |  Clinch River                              |  Clinch
Q1101503   |  MODvalue  |  name_nl     |  Clinch River                              |  Clinch
Q478303    |  MODvalue  |  name_de     |  French Broad River                        |  French Broad
Q478303    |  MODvalue  |  name_en     |  French Broad River                        |  French Broad
Q478303    |  MODvalue  |  name_nl     |  French Broad River                        |  French Broad
Q516393    |  MODvalue  |  name_en     |  Neosho River                              |  Neosho
Q1159151   |  MODvalue  |  name_de     |  Dan River                                 |  Dan
Q1159151   |  MODvalue  |  name_en     |  Dan River                                 |  Dan
Q1159151   |  MODvalue  |  name_fr     |  Dan River                                 |  Dan
Q1159151   |  MODvalue  |  name_hu     |  Dan River                                 |  Dan
Q1159151   |  MODvalue  |  name_nl     |  Dan River                                 |  Dan
Q206710    |  MODvalue  |  name_de     |  Powell River                              |  Powell
Q206710    |  MODvalue  |  name_en     |  Powell River                              |  Powell
Q4878160   |  MODvalue  |  name_en     |  Beaver River                              |  Beaver
Q516393    |  MODvalue  |  name_en     |  Neosho River                              |  Neosho
Q1108022   |  MODvalue  |  name_de     |  Saint Francis River                       |  Saint Francis
Q1108022   |  MODvalue  |  name_en     |  St. Francis River                         |  St. Francis
Q1108022   |  MODvalue  |  name_nl     |  St. Francis River                         |  St. Francis
Q1108022   |  MODvalue  |  name_pl     |  Saint Francis River                       |  Saint Francis
Q1544647   |  MODvalue  |  name_de     |  Green River                               |  Green
Q1544647   |  MODvalue  |  name_en     |  Green River                               |  Green
Q1544647   |  MODvalue  |  name_pl     |  Green River                               |  Green
Q606566    |  MODvalue  |  name_en     |  Licking River                             |  Licking
Q606566    |  MODvalue  |  name_pl     |  Licking River                             |  Licking
Q5175833   |  MODvalue  |  name_en     |  Cottonwood River                          |  Cottonwood
Q558645    |  MODvalue  |  name_de     |  Gunnison River                            |  Gunnison
Q558645    |  MODvalue  |  name_en     |  Gunnison River                            |  Gunnison
Q558645    |  MODvalue  |  name_nl     |  Gunnison River                            |  Gunnison
Q4113728   |  MODvalue  |  name_en     |  Solomon River                             |  Solomon
Q4905162   |  MODvalue  |  name_en     |  Big Blue River                            |  Big Blue
Q3695896   |  MODvalue  |  name_en     |  Chariton River                            |  Chariton
Q21197106  |  MODvalue  |  name_en     |  North Fork Solomon River                  |  North Fork Solomon
Q21197106  |  MODvalue  |  name_en     |  North Fork Solomon River                  |  North Fork Solomon
Q7299385   |  MODvalue  |  name_en     |  Raystown Branch Juniata River             |  Raystown Branch Juniata
Q1852004   |  MODvalue  |  name_de     |  Rock River                                |  Rock
Q1852004   |  MODvalue  |  name_en     |  Rock River                                |  Rock
Q1852004   |  MODvalue  |  name_it     |  Rock River                                |  Rock
Q1852004   |  MODvalue  |  name_nl     |  Rock River                                |  Rock
Q1852004   |  MODvalue  |  name_pl     |  Rock River                                |  Rock
Q1852004   |  MODvalue  |  name_pt     |  Rock River                                |  Rock
Q2042749   |  MODvalue  |  name_de     |  Owyhee River                              |  Owyhee
Q2042749   |  MODvalue  |  name_en     |  Owyhee River                              |  Owyhee
Q2042749   |  MODvalue  |  name_nl     |  Owyhee River                              |  Owyhee
Q1672169   |  MODvalue  |  name_de     |  Iowa River                                |  Iowa
Q1672169   |  MODvalue  |  name_en     |  Iowa River                                |  Iowa
Q1672169   |  MODvalue  |  name_nl     |  Iowa River                                |  Iowa
Q6942769   |  MODvalue  |  name_de     |  Muskegon River                            |  Muskegon
Q6942769   |  MODvalue  |  name_en     |  Muskegon River                            |  Muskegon
Q594295    |  MODvalue  |  name_de     |  Malheur River                             |  Malheur
Q594295    |  MODvalue  |  name_en     |  Malheur River                             |  Malheur
Q1147392   |  MODvalue  |  name_de     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_en     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_fr     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_nl     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_de     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_en     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_fr     |  Fox River                                 |  Fox
Q1147392   |  MODvalue  |  name_nl     |  Fox River                                 |  Fox
Q941928    |  MODvalue  |  name_de     |  Wolf River                                |  Wolf
Q941928    |  MODvalue  |  name_en     |  Wolf River                                |  Wolf
Q941928    |  MODvalue  |  name_nl     |  Wolf River                                |  Wolf
Q941928    |  MODvalue  |  name_de     |  Wolf River                                |  Wolf
Q941928    |  MODvalue  |  name_en     |  Wolf River                                |  Wolf
Q941928    |  MODvalue  |  name_nl     |  Wolf River                                |  Wolf
Q1164787   |  MODvalue  |  name_de     |  Winooski River                            |  Winooski
Q1164787   |  MODvalue  |  name_en     |  Winooski River                            |  Winooski
Q6482141   |  MODvalue  |  name_de     |  Lamoille River                            |  Lamoille
Q6482141   |  MODvalue  |  name_en     |  Lamoille River                            |  Lamoille
Q927116    |  MODvalue  |  name_de     |  Little Missouri River                     |  Little Missouri
Q927116    |  MODvalue  |  name_en     |  Little Missouri River                     |  Little Missouri
Q927116    |  MODvalue  |  name_nl     |  Little Missouri River                     |  Little Missouri
Q7304926   |  MODvalue  |  name_en     |  Red Rock River                            |  Red Rock
Q7304926   |  MODvalue  |  name_nl     |  Red Rock River                            |  Red Rock
Q1367713   |  MODvalue  |  name_de     |  Moreau River                              |  Moreau
Q1367713   |  MODvalue  |  name_en     |  Moreau River                              |  Moreau
Q1367713   |  MODvalue  |  name_fr     |  Moreau River                              |  Moreau
Q1367713   |  MODvalue  |  name_nl     |  Moreau River                              |  Moreau
Q7054245   |  MODvalue  |  name_en     |  North Branch Dead River                   |  North Branch Dead
Q2963877   |  MODvalue  |  name_de     |  Chippewa River                            |  Chippewa
Q2963877   |  MODvalue  |  name_en     |  Chippewa River                            |  Chippewa
Q2963877   |  MODvalue  |  name_pl     |  Chippewa River                            |  Chippewa
Q14715290  |  MODvalue  |  name_en     |  Moose River                               |  Moose
Q7984539   |  MODvalue  |  name_de     |  West Branch Penobscot River               |  West Branch Penobscot
Q7984539   |  MODvalue  |  name_en     |  West Branch Penobscot River               |  West Branch Penobscot
Q1542869   |  MODvalue  |  name_de     |  Grand River                               |  Grand
Q1542869   |  MODvalue  |  name_en     |  Grand River                               |  Grand
Q1542869   |  MODvalue  |  name_fr     |  Grand River                               |  Grand
Q1542869   |  MODvalue  |  name_it     |  Grand River                               |  Grand
Q1542869   |  MODvalue  |  name_nl     |  Grand River                               |  Grand
Q7984539   |  MODvalue  |  name_de     |  West Branch Penobscot River               |  West Branch Penobscot
Q7984539   |  MODvalue  |  name_en     |  West Branch Penobscot River               |  West Branch Penobscot
Q1033473   |  MODvalue  |  name_de     |  Cannonball River                          |  Cannonball
Q1033473   |  MODvalue  |  name_en     |  Cannonball River                          |  Cannonball
Q1033473   |  MODvalue  |  name_nl     |  Cannonball River                          |  Cannonball
Q1033473   |  MODvalue  |  name_sv     |  Cannonball River                          |  Cannonball
Q675651    |  MODvalue  |  name_de     |  Otter Tail River                          |  Otter Tail
Q675651    |  MODvalue  |  name_en     |  Otter Tail River                          |  Otter Tail
Q675651    |  MODvalue  |  name_nl     |  Otter Tail River                          |  Otter Tail
Q1592419   |  MODvalue  |  name_de     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_en     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_fr     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_nl     |  Heart River                               |  Heart
Q1592419   |  MODvalue  |  name_sv     |  Heart River                               |  Heart
Q2196805   |  MODvalue  |  name_en     |  Saint Joe River                           |  Saint Joe
Q2196805   |  MODvalue  |  name_nl     |  Saint Joe River                           |  Saint Joe
Q334544    |  MODvalue  |  name_en     |  South Fork Flathead River                 |  South Fork Flathead
Q5267445   |  MODvalue  |  name_en     |  Devils River                              |  Devils
Q595366    |  MODvalue  |  name_de     |  Marias River                              |  Marias
Q595366    |  MODvalue  |  name_en     |  Marias River                              |  Marias
Q595366    |  MODvalue  |  name_nl     |  Marias River                              |  Marias
Q595366    |  MODvalue  |  name_sv     |  Marias River                              |  Marias
Q217739    |  MODvalue  |  name_de     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_en     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_nl     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_pl     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_de     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_en     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_nl     |  Milk River                                |  Milk
Q217739    |  MODvalue  |  name_pl     |  Milk River                                |  Milk
Q686347    |  MODvalue  |  name_de     |  Selawik River                             |  Selawik
Q686347    |  MODvalue  |  name_en     |  Selawik River                             |  Selawik
Q686347    |  MODvalue  |  name_nl     |  Selawik River                             |  Selawik
Q534181    |  MODvalue  |  name_de     |  St. Croix River                           |  St. Croix
Q534181    |  MODvalue  |  name_en     |  Saint Croix River                         |  Saint Croix
Q534181    |  MODvalue  |  name_nl     |  Saint Croix River                         |  Saint Croix
Q534181    |  MODvalue  |  name_sv     |  St. Croix River                           |  St. Croix
Q1238848   |  MODvalue  |  name_de     |  Gull River                                |  Gull
Q1238848   |  MODvalue  |  name_en     |  Gull River                                |  Gull
Q1238848   |  MODvalue  |  name_fr     |  Gull River                                |  Gull
Q1238848   |  MODvalue  |  name_nl     |  Gull River                                |  Gull
Q1238848   |  MODvalue  |  name_sv     |  Gull River                                |  Gull
Q681048    |  MODvalue  |  name_de     |  Severn River                              |  Severn
Q681048    |  MODvalue  |  name_en     |  Severn River                              |  Severn
Q681048    |  MODvalue  |  name_nl     |  Severn River                              |  Severn
Q1491538   |  MODvalue  |  name_de     |  Wanapitei River                           |  Wanapitei
Q1491538   |  MODvalue  |  name_en     |  Wanapitei River                           |  Wanapitei
Q1491538   |  MODvalue  |  name_fr     |  Wanapitei River                           |  Wanapitei
Q1491538   |  MODvalue  |  name_nl     |  Wanapitei River                           |  Wanapitei
Q1491538   |  MODvalue  |  name_sv     |  Wanapitei River                           |  Wanapitei
Q478249    |  MODvalue  |  name_de     |  Spanish River                             |  Spanish
Q478249    |  MODvalue  |  name_en     |  Spanish River                             |  Spanish
Q478249    |  MODvalue  |  name_pl     |  Spanish River                             |  Spanish
Q2359274   |  MODvalue  |  name_de     |  Sturgeon River                            |  Sturgeon
Q2359274   |  MODvalue  |  name_en     |  Sturgeon River                            |  Sturgeon
Q1939154   |  MODvalue  |  name_de     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_en     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_nl     |  Mississagi River                          |  Mississagi
Q1939154   |  MODvalue  |  name_sv     |  Mississagi River                          |  Mississagi
Q1407181   |  MODvalue  |  name_en     |  Dumoine River                             |  Dumoine
Q6414609   |  MODvalue  |  name_en     |  Kipawa River                              |  Kipawa
Q15122455  |  MODvalue  |  name_de     |  Namakan River                             |  Namakan
Q15122455  |  MODvalue  |  name_en     |  Namakan River                             |  Namakan
Q15122455  |  MODvalue  |  name_nl     |  Namakan River                             |  Namakan
Q15122455  |  MODvalue  |  name_sv     |  Namakan River                             |  Namakan
Q15122455  |  MODvalue  |  name_de     |  Namakan River                             |  Namakan
Q15122455  |  MODvalue  |  name_en     |  Namakan River                             |  Namakan
Q15122455  |  MODvalue  |  name_nl     |  Namakan River                             |  Namakan
Q15122455  |  MODvalue  |  name_sv     |  Namakan River                             |  Namakan
Q5288219   |  MODvalue  |  name_de     |  Dog River                                 |  Dog
Q5288219   |  MODvalue  |  name_en     |  Dog River                                 |  Dog
Q2461680   |  MODvalue  |  name_de     |  Turtle River                              |  Turtle
Q2461680   |  MODvalue  |  name_en     |  Turtle River                              |  Turtle
Q3433693   |  MODvalue  |  name_en     |  Gens de Terre River                       |  Gens de Terre
Q3433693   |  MODvalue  |  name_en     |  Gens de Terre River                       |  Gens de Terre
Q4924881   |  MODvalue  |  name_de     |  Blanche River                             |  Blanche
Q4924881   |  MODvalue  |  name_en     |  Blanche River                             |  Blanche
Q4924881   |  MODvalue  |  name_nl     |  Blanche River                             |  Blanche
Q4924881   |  MODvalue  |  name_sv     |  Blanche River                             |  Blanche
Q2566970   |  MODvalue  |  name_de     |  White River                               |  White
Q2566970   |  MODvalue  |  name_en     |  White River                               |  White
Q2566970   |  NEWvalue  |  name_sv     |                                            |  White
Q391411    |  MODvalue  |  name_en     |  Gatineau River                            |  Gatineau
Q391411    |  MODvalue  |  name_nl     |  Gatineau River                            |  Gatineau
Q391411    |  MODvalue  |  name_sv     |  Rivière Gatineau                          |  Gatineaufloden
Q6344175   |  MODvalue  |  name_de     |  Kabinakagami River                        |  Kabinakagami
Q6344175   |  MODvalue  |  name_en     |  Kabinakagami River                        |  Kabinakagami
Q6344175   |  MODvalue  |  name_sv     |  Kabinakagami River                        |  Kabinakagami
Q60974     |  MODvalue  |  name_de     |  Ottawa River                              |  Ottawa
Q60974     |  MODvalue  |  name_en     |  Ottawa River                              |  Ottawa
Q60974     |  MODvalue  |  name_it     |  Ottawa River                              |  Ottawa
Q7958699   |  MODvalue  |  name_de     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_en     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_nl     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_sv     |  Wabigoon River                            |  Wabigoon
Q1452915   |  MODvalue  |  name_de     |  Frederick House River                     |  Frederick House
Q1452915   |  MODvalue  |  name_en     |  Frederick House River                     |  Frederick House
Q1452915   |  MODvalue  |  name_fr     |  Frederick House River                     |  Frederick House
Q1452915   |  NEWvalue  |  name_ja     |                                            |  フレデリックハウス川
Q1452915   |  MODvalue  |  name_nl     |  Frederick House River                     |  Frederick House
Q1452915   |  MODvalue  |  name_sv     |  Frederick House River                     |  Frederick House
Q22424013  |  MODvalue  |  name_en     |  Kanasuta River                            |  Kanasuta
Q71996     |  MODvalue  |  name_en     |  Harricana River                           |  Harricana
Q71996     |  MODvalue  |  name_nl     |  Harricana River                           |  Harricana
Q22654431  |  MODvalue  |  name_en     |  Namewaminikan River                       |  Namewaminikan
Q22654431  |  MODvalue  |  name_nl     |  Namewaminikan River                       |  Namewaminikan
Q22654431  |  MODvalue  |  name_sv     |  Namewaminikan River                       |  Namewaminikan
Q5617744   |  MODvalue  |  name_de     |  Gull River                                |  Gull
Q5617744   |  MODvalue  |  name_en     |  Gull River                                |  Gull
Q59647     |  MODvalue  |  name_de     |  Abitibi River                             |  Abitibi
Q59647     |  MODvalue  |  name_en     |  Abitibi River                             |  Abitibi
Q59647     |  MODvalue  |  name_nl     |  Abitibi River                             |  Abitibi
Q7958699   |  MODvalue  |  name_de     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_en     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_nl     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_sv     |  Wabigoon River                            |  Wabigoon
Q14506269  |  MODvalue  |  name_en     |  Bell River                                |  Bell
Q14506269  |  NEWvalue  |  name_sv     |                                            |  Rivière Bell
Q7958699   |  MODvalue  |  name_de     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_en     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_nl     |  Wabigoon River                            |  Wabigoon
Q7958699   |  MODvalue  |  name_sv     |  Wabigoon River                            |  Wabigoon
Q22436349  |  MODvalue  |  name_en     |  Saint-Cyr River                           |  Saint-Cyr
Q22440718  |  MODvalue  |  name_en     |  Wetetnagami River                         |  Wetetnagami
Q6648837   |  MODvalue  |  name_de     |  Little Abitibi River                      |  Little Abitibi
Q6648837   |  MODvalue  |  name_en     |  Little Abitibi River                      |  Little Abitibi
Q6648837   |  MODvalue  |  name_sv     |  Little Abitibi River                      |  Little Abitibi
Q15108795  |  MODvalue  |  name_de     |  Chukuni River                             |  Chukuni
Q15108795  |  MODvalue  |  name_en     |  Chukuni River                             |  Chukuni
Q15108795  |  MODvalue  |  name_nl     |  Chukuni River                             |  Chukuni
Q15108795  |  MODvalue  |  name_sv     |  Chukuni River                             |  Chukuni
Q1592361   |  MODvalue  |  name_de     |  Kesagami River                            |  Kesagami
Q1592361   |  MODvalue  |  name_en     |  Kesagami River                            |  Kesagami
Q1592361   |  MODvalue  |  name_nl     |  Kesagami River                            |  Kesagami
Q1592361   |  MODvalue  |  name_sv     |  Kesagami River                            |  Kesagami
Q15132584  |  MODvalue  |  name_de     |  Troutlake River                           |  Troutlake
Q15132584  |  MODvalue  |  name_en     |  Troutlake River                           |  Troutlake
Q15132584  |  MODvalue  |  name_nl     |  Troutlake River                           |  Troutlake
Q15132584  |  MODvalue  |  name_sv     |  Troutlake River                           |  Troutlake
Q15108795  |  MODvalue  |  name_de     |  Chukuni River                             |  Chukuni
Q15108795  |  MODvalue  |  name_en     |  Chukuni River                             |  Chukuni
Q15108795  |  MODvalue  |  name_nl     |  Chukuni River                             |  Chukuni
Q15108795  |  MODvalue  |  name_sv     |  Chukuni River                             |  Chukuni
Q2016217   |  MODvalue  |  name_de     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_en     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_fr     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_nl     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_sv     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_de     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_en     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_fr     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_nl     |  Ogoki River                               |  Ogoki
Q2016217   |  MODvalue  |  name_sv     |  Ogoki River                               |  Ogoki
Q20650477  |  MODvalue  |  name_en     |  O'Sullivan River                          |  O'Sullivan
Q20650477  |  MODvalue  |  name_nl     |  O'Sullivan River                          |  O'Sullivan
Q22461606  |  MODvalue  |  name_en     |  Attwood River                             |  Attwood
Q22461606  |  MODvalue  |  name_nl     |  Attwood River                             |  Attwood
Q22461606  |  MODvalue  |  name_sv     |  Attwood River                             |  Attwood
Q22485701  |  MODvalue  |  name_en     |  Cheepay River                             |  Cheepay
Q22485701  |  MODvalue  |  name_nl     |  Cheepay River                             |  Cheepay
Q22485701  |  MODvalue  |  name_sv     |  Cheepay River                             |  Cheepay
Q1603754   |  MODvalue  |  name_en     |  Opawica river                             |  Opawica
Q1603754   |  MODvalue  |  name_nl     |  Opawica River                             |  Opawica
Q1376034   |  MODvalue  |  name_en     |  Waswanipi River                           |  Waswanipi
Q1376034   |  MODvalue  |  name_en     |  Waswanipi River                           |  Waswanipi
Q1376034   |  MODvalue  |  name_en     |  Waswanipi River                           |  Waswanipi
Q819057    |  MODvalue  |  name_de     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_en     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_fr     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_nl     |  Berens River                              |  Berens
Q20645849  |  MODvalue  |  name_en     |  Maicasagi River                           |  Maicasagi
Q20645849  |  MODvalue  |  name_nl     |  Maicasagi River                           |  Maicasagi
Q1320358   |  MODvalue  |  name_en     |  Obatogamau river                          |  Obatogamau
Q2155662   |  MODvalue  |  name_en     |  Chibougamau River                         |  Chibougamau
Q15124841  |  MODvalue  |  name_de     |  Pigeon River                              |  Pigeon
Q819057    |  MODvalue  |  name_de     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_en     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_fr     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_nl     |  Berens River                              |  Berens
Q15124871  |  MODvalue  |  name_de     |  Pipestone River                           |  Pipestone
Q15124871  |  MODvalue  |  name_en     |  Pipestone River                           |  Pipestone
Q819057    |  MODvalue  |  name_de     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_en     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_fr     |  Berens River                              |  Berens
Q819057    |  MODvalue  |  name_nl     |  Berens River                              |  Berens
Q15123712  |  MODvalue  |  name_de     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_en     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_nl     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_sv     |  Otoskwin River                            |  Otoskwin
Q1621199   |  MODvalue  |  name_de     |  Poplar River                              |  Poplar
Q1621199   |  MODvalue  |  name_en     |  Poplar River                              |  Poplar
Q1621199   |  MODvalue  |  name_sv     |  Poplar River                              |  Poplar
Q757914    |  MODvalue  |  name_de     |  Attawapiskat River                        |  Attawapiskat
Q757914    |  MODvalue  |  name_en     |  Attawapiskat River                        |  Attawapiskat
Q757914    |  MODvalue  |  name_nl     |  Attawapiskat River                        |  Attawapiskat
Q2155694   |  MODvalue  |  name_en     |  Manouane River                            |  Manouane
Q2155694   |  MODvalue  |  name_nl     |  Manouane River                            |  Manouane
Q94368     |  MODvalue  |  name_en     |  Broadback River                           |  Broadback
Q94368     |  MODvalue  |  name_nl     |  Broadback River                           |  Broadback
Q94368     |  MODvalue  |  name_en     |  Broadback River                           |  Broadback
Q94368     |  MODvalue  |  name_nl     |  Broadback River                           |  Broadback
Q601290    |  MODvalue  |  name_en     |  Betsiamites River                         |  Betsiamites
Q601290    |  MODvalue  |  name_fr     |  Betsiamites                               |  rivière Betsiamites
Q15123712  |  MODvalue  |  name_de     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_en     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_nl     |  Otoskwin River                            |  Otoskwin
Q15123712  |  MODvalue  |  name_sv     |  Otoskwin River                            |  Otoskwin
Q94368     |  MODvalue  |  name_en     |  Broadback River                           |  Broadback
Q94368     |  MODvalue  |  name_nl     |  Broadback River                           |  Broadback
Q1621199   |  MODvalue  |  name_de     |  Poplar River                              |  Poplar
Q1621199   |  MODvalue  |  name_en     |  Poplar River                              |  Poplar
Q1621199   |  MODvalue  |  name_sv     |  Poplar River                              |  Poplar
Q15135028  |  MODvalue  |  name_de     |  Windigo River                             |  Windigo
Q15135028  |  MODvalue  |  name_en     |  Windigo River                             |  Windigo
Q15135028  |  MODvalue  |  name_nl     |  Windigo River                             |  Windigo
Q15135028  |  MODvalue  |  name_sv     |  Windigo River                             |  Windigo
Q15126272  |  MODvalue  |  name_en     |  Marte River                               |  Marte
Q15126272  |  NEWvalue  |  name_sv     |                                            |  Rivière à la Marte
Q15126272  |  MODvalue  |  name_en     |  Marte River                               |  Marte
Q15126272  |  NEWvalue  |  name_sv     |                                            |  Rivière à la Marte
Q80350     |  MODvalue  |  name_de     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_en     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_nl     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_sv     |  Winisk River                              |  Winisk
Q14555119  |  MODvalue  |  name_en     |  Nemiscau River                            |  Nemiscau
Q80350     |  MODvalue  |  name_de     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_en     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_nl     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_sv     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_de     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_en     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_nl     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_sv     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_de     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_en     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_nl     |  Winisk River                              |  Winisk
Q80350     |  MODvalue  |  name_sv     |  Winisk River                              |  Winisk
Q15106873  |  MODvalue  |  name_de     |  Asheweig River                            |  Asheweig
Q15106873  |  MODvalue  |  name_en     |  Asheweig River                            |  Asheweig
Q15106873  |  MODvalue  |  name_sv     |  Asheweig River                            |  Asheweig
Q427437    |  MODvalue  |  name_en     |  Rupert River                              |  Rupert
Q427437    |  MODvalue  |  name_nl     |  Rupert River                              |  Rupert
Q2155747   |  MODvalue  |  name_en     |  Toulnustouc River                         |  Toulnustouc
Q2155747   |  MODvalue  |  name_en     |  Toulnustouc River                         |  Toulnustouc
Q2155749   |  MODvalue  |  name_en     |  Temiscanie River                          |  Temiscanie
Q2155749   |  MODvalue  |  name_en     |  Temiscanie River                          |  Temiscanie
Q15842612  |  MODvalue  |  name_en     |  Aux Rochers River                         |  Aux Rochers
Q18168183  |  MODvalue  |  name_en     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_nl     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_sv     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_en     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_nl     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_sv     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_en     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_nl     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_sv     |  Grass River                               |  Grass
Q2155692   |  MODvalue  |  name_en     |  Magpie River                              |  Magpie
Q31308     |  MODvalue  |  name_en     |  Sakami River                              |  Sakami
Q31308     |  MODvalue  |  name_en     |  Sakami River                              |  Sakami
Q2155677   |  MODvalue  |  name_en     |  Hart Jaune river                          |  Hart Jaune
Q2155677   |  MODvalue  |  name_en     |  Hart Jaune river                          |  Hart Jaune
Q18168183  |  MODvalue  |  name_en     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_nl     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_sv     |  Grass River                               |  Grass
Q15842615  |  NEWvalue  |  name_ar     |                                            |  البتولا، إستأصل، ريفير
Q15842615  |  NEWvalue  |  name_bn     |                                            |  বার্চ রুট নদী
Q15842615  |  NEWvalue  |  name_en     |                                            |  Racine de Bouleau
Q15842615  |  NEWvalue  |  name_it     |                                            |  rivière de la Racine de Bouleau
Q601279    |  MODvalue  |  name_en     |  Moisie River                              |  Moisie
Q15128706  |  MODvalue  |  name_de     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_en     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_nl     |  Smoothstone River                         |  Smoothstone
Q15128706  |  MODvalue  |  name_sv     |  Smoothstone River                         |  Smoothstone
Q22434259  |  MODvalue  |  name_en     |  Kississing River                          |  Kississing
Q22434259  |  MODvalue  |  name_nl     |  Kississing River                          |  Kississing
Q22434259  |  MODvalue  |  name_sv     |  Kississing River                          |  Kississing
Q7359388   |  MODvalue  |  name_en     |  Roggan River                              |  Roggan
Q7359388   |  MODvalue  |  name_en     |  Roggan River                              |  Roggan
Q5000261   |  MODvalue  |  name_en     |  Burntwood River                           |  Burntwood
Q5000261   |  MODvalue  |  name_sv     |  Burntwood River                           |  Burntwood
Q5000261   |  MODvalue  |  name_en     |  Burntwood River                           |  Burntwood
Q5000261   |  MODvalue  |  name_sv     |  Burntwood River                           |  Burntwood
Q18168183  |  MODvalue  |  name_en     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_nl     |  Grass River                               |  Grass
Q18168183  |  MODvalue  |  name_sv     |  Grass River                               |  Grass
Q7295398   |  MODvalue  |  name_en     |  Rat River                                 |  Rat
Q7295398   |  NEWvalue  |  name_nl     |                                            |  Rat
Q7295398   |  NEWvalue  |  name_sv     |                                            |  Rat
Q20645412  |  MODvalue  |  name_en     |  Kanaaupscow River                         |  Kanaaupscow
Q20645412  |  MODvalue  |  name_nl     |  Kanaaupscow River                         |  Rivière Kanaaupscow
Q20645412  |  NEWvalue  |  name_sv     |                                            |  Rivière Kanaaupscow
Q31379     |  MODvalue  |  name_en     |  La Grande River                           |  La Grande
Q1412484   |  MODvalue  |  name_en     |  Musquaro River                            |  Musquaro
Q3318      |  MODvalue  |  name_de     |  Churchill River                           |  Churchill
Q3318      |  MODvalue  |  name_en     |  Churchill River                           |  Churchill
Q15842606  |  MODvalue  |  name_en     |  Vauquelin River                           |  Vauquelin
Q22659007  |  MODvalue  |  name_en     |  Loon River                                |  Loon
Q22659007  |  MODvalue  |  name_nl     |  Loon River                                |  Loon
Q22659007  |  MODvalue  |  name_sv     |  Loon River                                |  Loon
Q15111285  |  MODvalue  |  name_de     |  Gauer River                               |  Gauer
Q15111285  |  MODvalue  |  name_en     |  Gauer River                               |  Gauer
Q15111285  |  MODvalue  |  name_nl     |  Gauer River                               |  Gauer
Q15111285  |  MODvalue  |  name_sv     |  Gauer River                               |  Gauer
Q22649147  |  MODvalue  |  name_en     |  Hughes River                              |  Hughes
Q22649147  |  MODvalue  |  name_nl     |  Hughes River                              |  Hughes
Q22649147  |  MODvalue  |  name_sv     |  Hughes River                              |  Hughes
Q22457456  |  MODvalue  |  name_en     |  Ashuanipi River                           |  Ashuanipi
Q22457456  |  MODvalue  |  name_nl     |  Ashuanipi River                           |  Ashuanipi
Q22457456  |  MODvalue  |  name_sv     |  Ashuanipi River                           |  Ashuanipi
Q22499146  |  MODvalue  |  name_en     |  Metchin River                             |  Metchin
Q22499146  |  MODvalue  |  name_nl     |  Metchin River                             |  Metchin
Q22499146  |  MODvalue  |  name_sv     |  Metchin River                             |  Metchin
Q18150029  |  MODvalue  |  name_de     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_en     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_de     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_en     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_de     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_en     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_de     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_en     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_de     |  Cochrane River                            |  Cochrane
Q18150029  |  MODvalue  |  name_en     |  Cochrane River                            |  Cochrane
Q1276816   |  MODvalue  |  name_de     |  Eagle River                               |  Eagle
Q1276816   |  MODvalue  |  name_en     |  Eagle River                               |  Eagle
Q2155722   |  MODvalue  |  name_en     |  George River                              |  George
Q1139466   |  MODvalue  |  name_de     |  Cree River                                |  Cree
Q1139466   |  MODvalue  |  name_en     |  Cree River                                |  Cree
Q1139466   |  NEWvalue  |  name_ja     |                                            |  クリー川
Q15391863  |  MODvalue  |  name_de     |  Kanairiktok River                         |  Kanairiktok
Q72075     |  MODvalue  |  name_de     |  Thlewiaza River                           |  Thlewiaza
Q72075     |  NEWvalue  |  name_en     |                                            |  Thlewiaza
Q1074554   |  MODvalue  |  name_de     |  Chipman River                             |  Chipman
Q1074554   |  MODvalue  |  name_en     |  Chipman River                             |  Chipman
Q1074554   |  MODvalue  |  name_nl     |  Chipman River                             |  Chipman
Q1074554   |  MODvalue  |  name_sv     |  Chipman River                             |  Chipman
Q1074554   |  MODvalue  |  name_de     |  Chipman River                             |  Chipman
Q1074554   |  MODvalue  |  name_en     |  Chipman River                             |  Chipman
Q1074554   |  MODvalue  |  name_nl     |  Chipman River                             |  Chipman
Q1074554   |  MODvalue  |  name_sv     |  Chipman River                             |  Chipman
Q2155693   |  MODvalue  |  name_en     |  Marralik River                            |  Marralik
Q1163523   |  MODvalue  |  name_de     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_en     |  Dubawnt River                             |  Dubawnt
Q217663    |  MODvalue  |  name_de     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_en     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_nl     |  Tha-anne River                            |  Tha-anne
Q217663    |  MODvalue  |  name_sv     |  Tha-anne River                            |  Tha-anne
Q1163523   |  MODvalue  |  name_de     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_en     |  Dubawnt River                             |  Dubawnt
Q1690616   |  MODvalue  |  name_en     |  Qurlutuq River                            |  Qurlutuq
Q719436    |  MODvalue  |  name_de     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_en     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_nl     |  Kazan River                               |  Kazan
Q719436    |  MODvalue  |  name_sv     |  Kazan River                               |  Kazan
Q1406237   |  MODvalue  |  name_de     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_en     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_de     |  Ferguson River                            |  Ferguson
Q1406237   |  MODvalue  |  name_en     |  Ferguson River                            |  Ferguson
Q1163523   |  MODvalue  |  name_de     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_en     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_de     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_en     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_de     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_en     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_de     |  Dubawnt River                             |  Dubawnt
Q1163523   |  MODvalue  |  name_en     |  Dubawnt River                             |  Dubawnt
Q1031730   |  MODvalue  |  name_de     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_en     |  Camsell river                             |  Camsell
Q1031730   |  MODvalue  |  name_nl     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_sv     |  Camsell River                             |  Camsell
Q15115769  |  MODvalue  |  name_de     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_en     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_nl     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_sv     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_de     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_en     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_nl     |  Johnny Hoe River                          |  Johnny Hoe
Q15115769  |  MODvalue  |  name_sv     |  Johnny Hoe River                          |  Johnny Hoe
Q1031730   |  MODvalue  |  name_de     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_en     |  Camsell river                             |  Camsell
Q1031730   |  MODvalue  |  name_nl     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_sv     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_de     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_en     |  Camsell river                             |  Camsell
Q1031730   |  MODvalue  |  name_nl     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_sv     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_de     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_en     |  Camsell river                             |  Camsell
Q1031730   |  MODvalue  |  name_nl     |  Camsell River                             |  Camsell
Q1031730   |  MODvalue  |  name_sv     |  Camsell River                             |  Camsell
Q7837560   |  MODvalue  |  name_de     |  Tree River                                |  Tree
Q7837560   |  MODvalue  |  name_en     |  Tree River                                |  Tree
Q7837560   |  MODvalue  |  name_sv     |  Tree River                                |  Tree
Q7837560   |  MODvalue  |  name_de     |  Tree River                                |  Tree
Q7837560   |  MODvalue  |  name_en     |  Tree River                                |  Tree
Q7837560   |  MODvalue  |  name_sv     |  Tree River                                |  Tree
Q14658488  |  MODvalue  |  name_de     |  Whitefish River                           |  Whitefish
Q14658488  |  MODvalue  |  name_en     |  Whitefish River                           |  Whitefish
Q15109230  |  MODvalue  |  name_de     |  Dease River                               |  Dease
Q16209683  |  MODvalue  |  name_en     |  Bloody River                              |  Bloody
Q16209683  |  MODvalue  |  name_sv     |  Bloody River                              |  Bloody
Q15112077  |  MODvalue  |  name_de     |  Haldane River                             |  Haldane
Q15112077  |  MODvalue  |  name_en     |  Haldane River                             |  Haldane
Q15112077  |  MODvalue  |  name_nl     |  Haldane River                             |  Haldane
Q15112077  |  MODvalue  |  name_sv     |  Haldane River                             |  Haldane
Q14874728  |  MODvalue  |  name_en     |  Nimpkish River                            |  Nimpkish
Q14874728  |  MODvalue  |  name_sv     |  Nimpkish River                            |  Nimpkish
Q862650    |  MODvalue  |  name_de     |  Bill Williams River                       |  Bill Williams
Q862650    |  MODvalue  |  name_en     |  Bill Williams River                       |  Bill Williams
Q862650    |  MODvalue  |  name_nl     |  Bill Williams River                       |  Bill Williams
Q1676970   |  MODvalue  |  name_de     |  Virgin River                              |  Virgin
Q1676970   |  MODvalue  |  name_en     |  Virgin River                              |  Virgin
Q1676970   |  MODvalue  |  name_it     |  Virgin River                              |  Virgin
Q1676970   |  MODvalue  |  name_nl     |  Virgin River                              |  Virgin
Q499797    |  MODvalue  |  name_de     |  Trinity River                             |  Trinity
Q499797    |  MODvalue  |  name_en     |  Trinity River                             |  Trinity
Q1955484   |  MODvalue  |  name_de     |  Musselshell River                         |  Musselshell
Q1955484   |  MODvalue  |  name_en     |  Musselshell River                         |  Musselshell
Q1955484   |  MODvalue  |  name_nl     |  Musselshell River                         |  Musselshell
Q3339115   |  MODvalue  |  name_en     |  Newhalen River                            |  Newhalen
Q3339115   |  MODvalue  |  name_nl     |  Newhalen River                            |  Newhalen
Q2005786   |  MODvalue  |  name_de     |  Nuyakuk River                             |  Nuyakuk
Q2005786   |  MODvalue  |  name_en     |  Nuyakuk River                             |  Nuyakuk
Q2005786   |  MODvalue  |  name_nl     |  Nuyakuk River                             |  Nuyakuk
Q860139    |  MODvalue  |  name_en     |  Romaine River                             |  Romaine
Q5019586   |  MODvalue  |  name_en     |  Calfpasture River                         |  Calfpasture
Q5019586   |  MODvalue  |  name_nl     |  Calfpasture River                         |  Calfpasture
